#!/usr/bin/env python3
"""Générateur et installateur de tâches planifiées (cron / Windows Task Scheduler) per section 11.1."""
import argparse
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from src.tools.scheduler import generate_scheduler_command, install_cron

def main():
    parser = argparse.ArgumentParser(description="Installation du planificateur hebdomadaire (Lundi 9h)")
    parser.add_argument("--mode", default="A", choices=["A", "B"], help="Mode à exécuter (défaut: A)")
    parser.add_argument("--hour", type=int, default=9, help="Heure d'exécution (0-23, défaut: 9)")
    parser.add_argument("--weekday", type=int, default=1, help="Jour de la semaine (1=Lundi ... 7=Dimanche, défaut: 1)")
    parser.add_argument("--install", action="store_true", help="Tenter l'installation automatique dans crontab ou schtasks")
    args = parser.parse_args()

    cmd = generate_scheduler_command(mode=args.mode, hour=args.hour, weekday=args.weekday)
    print("=" * 60)
    print("⏰ PLANIFICATEUR DE TÂCHES PROSPECTION DAF GIRONDE")
    print("=" * 60)
    print(f"Commande générée pour votre OS :\n")
    print(f"  {cmd}\n")

    if args.install:
        success = install_cron(mode=args.mode, hour=args.hour, weekday=args.weekday)
        if success:
            print("✅ Tâche planifiée installée avec succès sur le système !")
        else:
            print("⚠️ Impossible d'écrire automatiquement dans le planificateur de l'OS. Veuillez copier-coller la commande ci-dessus manuellement.")
    else:
        print("💡 Pour l'installer automatiquement, relancez avec l'option --install :")
        print("   python install_scheduler.py --install")

if __name__ == "__main__":
    main()
