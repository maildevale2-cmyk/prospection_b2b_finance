# Agent de Prospection DAF / Finance Gironde (LLM Gemma 3)

Agent logiciel autonome d'enrichissement et de prospection B2B ciblant les décideurs Finance (DAF, CFO, Credit Managers) en Gironde (33), orchestré avec le modèle open source **Gemma 3**, l'**API Lusha**, et un mécanisme strict de **validation humaine (HITL)**.

---

## 📋 Table des matières

1. [Fonctionnalités clés](#fonctionnalités-clés)
2. [Architecture technique](#architecture-technique)
3. [Prérequis](#prérequis)
4. [Installation pas-à-pas](#installation-pas-à-pas)
5. [Configuration (.env et config.yaml)](#configuration)
6. [Modes d'utilisation (CLI & Web)](#modes-dutilisation)
7. [Validation Humaine (HITL)](#validation-humaine-hitl)
8. [Conformité RGPD](#conformité-rgpd)
9. [Tests unitaires et de recette](#tests-unitaires-et-de-recette)
10. [Planification automatique (Cron / Windows Task Scheduler)](#planification-automatique)

---

## 1. Fonctionnalités clés

* **Ciblage ICP Gironde (33)** : Entreprises de 100 à 1000 salariés dans les secteurs de l'industrie et du commerce de gros (Bordeaux, Mérignac, Pessac, Libourne, Bègles, etc.).
* **Raisonnement & Rédaction par Gemma 3** : Priorisation intelligente selon 3 signaux d'affaires (changement de poste récent < 6 mois, poste Finance ouvert chez l'entreprise, profil établi) et rédaction de messages d'approche personnalisés (80-120 mots).
* **Contrôle budgétaire strict** : Plafond infranchissable de **20 révélations de coordonnées par run**.
* **Garantie de non-automatisation LinkedIn** : Zéro action automatisée sur LinkedIn (conformité totale CGU).
* **Validation Humaine Obligatoire (HITL)** : Aucune coordonnée payante n'est révélée sans accord préalable de l'utilisateur.
* **Persistance & Dédoublonnage SQLite** : Base locale `data/prospection.db` avec export CSV compatible Excel (UTF-8 avec BOM, séparateur point-virgule `;`).

---

## 2. Architecture technique

```
prospection-agent/
├── config/
│   ├── config.yaml          # Paramètres ICP, seuils et planificateur
│   └── .env.example         # Gabarit des variables d'environnement
├── prompts/
│   ├── system_main.txt      # Prompt système principal Gemma 3
│   ├── prioritize.txt       # Prompt de priorisation des signaux
│   ├── message.txt          # Prompt de rédaction d'approche B2B
│   └── siren_check.txt      # Prompt d'audit des anomalies SIREN
├── src/
│   ├── __init__.py
│   ├── main.py              # Point d'entrée CLI (Mode A / B)
│   ├── orchestrator.py      # Moteur d'orchestration des flux
│   ├── llm_client.py        # Client Gemma (Google AI Studio ou Ollama)
│   ├── tools/
│   │   ├── lusha.py         # Client API Lusha (Search, Company, Enrich)
│   │   ├── files.py         # Gestion CSV & rapprochement SIREN
│   │   ├── state.py         # Gestionnaire SQLite, exports & logs
│   │   ├── hitl.py          # Module de validation humaine (HITL)
│   │   └── scheduler.py     # Gestionnaire cron / Windows Task Scheduler
│   ├── models.py            # Schémas de données Pydantic/dataclasses
│   ├── prompts.py           # Chargeur dynamique de prompts
│   └── utils.py             # Nettoyage SIREN, masquage RGPD dans les logs
├── data/
│   ├── prospection.db       # Base SQLite locale
│   ├── comptes_exemples.csv # Échantillon de comptes cibles (Mode B)
│   ├── connus_exemples.csv  # Échantillon de comptes déjà connus
│   └── exports/             # Répertoire des exports CSV UTF-8 BOM
├── logs/                    # Journalisation rotative quotidienne
├── tests/
│   ├── test_lusha.py        # Tests unitaires Lusha et backoff 429
│   ├── test_state.py        # Tests SQLite, dédoublonnage et optout
│   └── test_orchestrator.py # Tests d'intégration flux complets Mode A & B
├── optout.py                # Script RGPD d'inscription sur liste noire
├── purge.py                 # Script RGPD de purge à 3 ans
├── install_scheduler.py     # Script d'installation du planificateur
├── install.sh / install.ps1 # Scripts d'installation automatisés
├── Dockerfile               # Conteneurisation de production
└── registre_traitements.md  # Registre de conformité RGPD Art. 30
```

---

## 3. Prérequis

* **Système d'exploitation** : Linux, macOS ou Windows 10/11
* **Python** : Version 3.10 ou 3.11+
* **Mémoire vive (RAM)** :
  * 8 Go si utilisation de l'API Google AI Studio
  * 16 Go si Ollama avec Gemma 3 12B en local
  * 32 Go si Ollama avec Gemma 3 27B en local
* **Clés requises** :
  * Clé API Lusha (pour la prospection réelle)
  * Clé Google AI Studio (ou installation locale d'Ollama : `ollama run gemma3:27b`)

---

## 4. Installation pas-à-pas

### Option A : Via le script automatisé (Linux / macOS)
```bash
chmod +x install.sh
./install.sh
```

### Option B : Via PowerShell (Windows)
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\install.ps1
```

### Option C : Installation manuelle
```bash
# 1. Cloner ou naviguer dans le dossier
cd prospection-agent

# 2. Créer l'environnement virtuel
python3 -m venv venv
source venv/bin/activate  # ou .\venv\Scripts\activate sous Windows

# 3. Installer les dépendances
pip install -r requirements.txt

# 4. Configurer les variables d'environnement
cp config/.env.example .env
```

---

## 5. Configuration

Éditez le fichier `.env` :
```env
LUSHA_API_KEY=votre_cle_lusha
GEMINI_API_KEY=votre_cle_google_ai_studio
LLM_PROVIDER=gemma_studio # ou "ollama"
GEMMA_MODEL=gemma-3-27b-it
MAX_REVEALS_PER_RUN=20
```

---

## 6. Modes d'utilisation

### Mode A : Recherche autonome (Chaque lundi 9h)
```bash
# Exécution réelle :
python src/main.py --mode A

# Exécution en simulation (sans consommer de crédits) :
python src/main.py --mode A --dry-run
```

### Mode B : Liste de comptes fournie
```bash
# Traitement de fichiers CSV :
python src/main.py --mode B --accounts data/comptes_exemples.csv --known data/connus_exemples.csv --dry-run
```

---

## 7. Validation Humaine (HITL)

L'agent applique une règle stricte : **aucune coordonnée n'est achetée sans confirmation humaine explicite**.
La liste des contacts éligibles (nom, poste, entreprise, ville, signal) est présentée à l'écran :
```
🔒 CONFIRMATION HUMAINE REQUISE (HITL)
Valider la révélation payante de ces contacts ? (o/n) :
```
Si vous tapez `n`, le processus s'arrête proprement et aucune dépense n'est engagée.

---

## 8. Conformité RGPD

* **Droit d'opposition immédiat** :
  ```bash
  python optout.py --email prospect@entreprise.fr
  ```
* **Purge automatique triennale (rétention 3 ans)** :
  ```bash
  python purge.py --years 3
  ```
* **Masquage systématique des coordonnées dans les journaux** : Les fichiers `logs/run_*.log` ne contiennent aucun email ni téléphone en clair.

---

## 9. Tests unitaires et de recette

Pour vérifier le bon fonctionnement de l'ensemble du système :
```bash
python3 -m unittest discover -s tests -p "test_*.py"
```

---

## 10. Planification automatique

Générer et installer la tâche planifiée (hebdomadaire, lundi 9h00) :
```bash
python install_scheduler.py --install
```
