# Registre des Activités de Traitement RGPD

Conformément à l'Article 30 du Règlement Général sur la Protection des Données (RGPD - Règlement UE 2016/679).

---

## 1. Responsable du Traitement

* **Entité** : Direction Commerciale / Prospection B2B
* **Contact DPO / Référent RGPD** : commercial@entreprise.fr
* **Date de création du registre** : 28/09/2026
* **Dernière révision** : 28/09/2026

---

## 2. Finalité du Traitement

* **Finalité principale** : Prospection commerciale interentreprises (B2B) auprès de décideurs des fonctions Finance, Comptabilité et Recouvrement (DAF, CFO, Credit Managers) en Gironde (33).
* **Finalités secondaires** :
  * Qualification et priorisation des opportunités d'affaires ;
  * Enrichissement vérifié des coordonnées professionnelles ;
  * Gestion du droit d'opposition et tenue d'une liste noire d'exclusion ;
  * Traçabilité technique des opérations d'enrichissement payant.

---

## 3. Base Légale du Traitement

* **Base légale retenue** : **Intérêt légitime** (Article 6.1.f du RGPD) tel qu'admis par la CNIL pour la prospection B2B lorsque le message d'approche est en rapport direct avec la fonction ou profession du destinataire.
* **Mise en œuvre du droit d'opposition** : Chaque prise de contact offre un moyen direct, simple et sans frais pour le destinataire de s'opposer à toute sollicitation future (Article 21 du RGPD).

---

## 4. Catégories de Personnes Concernées

* Décideurs de directions financières, administratives et comptables d'entreprises de 100 à 1000 salariés situées en Gironde (33) dans les secteurs de l'industrie et du commerce de gros.

---

## 5. Données Personnelles Collectées (Principe de Minimisation)

Seules les données strictement nécessaires à l'exercice de la prospection B2B sont collectées :
* **Identité** : Nom, prénom.
* **Professionnel** : Poste/titre exact, entreprise employeur, SIREN, ville du siège.
* **Coordonnées professionnelles directes** : Email professionnel nominatif, numéro de téléphone professionnel, URL du profil LinkedIn public.
* **Données techniques et de suivi** : Statut d'approche, date d'ajout, date de dernière action.

> **Données formellement interdites et exclues** : Aucune donnée sensible (santé, opinions politiques, croyances, infractions), aucune donnée relative à la vie privée, aucune donnée relative aux mineurs.

---

## 6. Destinataires et Sous-traitants (DPA)

| Destinataire / Sous-traitant | Rôle | Localisation | Garanties de transfert |
|---|---|---|---|
| **Lusha Inc.** | Fourniture de données professionnelles B2B et enrichissement | États-Unis / UE | Data Processing Agreement (DPA) signé, clauses contractuelles types (CCT), certification DPF |
| **Google Cloud / AI Studio** | Inférence du modèle Gemma 3 (si option API activée) | UE / USA | Conditions d'utilisation Google Cloud, non-utilisation des prompts pour l'entraînement modèle |
| **Ollama (Local)** | Inférence locale open source hors-ligne (option recommandée) | Local / Sur site | Aucune donnée ne quitte le serveur ou la machine de l'utilisateur |

---

## 7. Durées de Conservation et Purge

* **Durée de conservation active** : **3 ans maximum** à compter de la date du dernier contact ou de la dernière interaction commerciale.
* **Procédure de purge automatique** : Script automatisé `purge.py --years 3` supprimant de manière irréversible les enregistrements échus.
* **Données d'opposition** : Les adresses email inscrites sur liste noire (`optouts`) sont conservées sans limite de durée afin de garantir que ces personnes ne seront jamais réimportées lors des campagnes ultérieures.

---

## 8. Procédure d'Exercice des Droits (Droit d'Opposition)

Toute personne souhaitant ne plus être contactée peut faire valoir son droit d'opposition :
1. Réception de la demande par retour d'email ou notification ;
2. Exécution immédiate de la commande :
   ```bash
   python optout.py --email nom.prenom@entreprise.fr
   ```
3. Effacement automatique de la fiche contact dans `contacts` ;
4. Inscription irréversible sur la table `optouts` avec horodatage.

---

## 9. Mesures de Sécurité Organisationnelles et Techniques

* **Journalisation sécurisée (Anti-Leaking)** : Masquage systématique des emails (`[EMAIL_MASQUÉ]`) et téléphones (`[TEL_MASQUÉ]`) dans les logs applicatifs (`logs/run_*.log`).
* **Validation Humaine Obligatoire (HITL)** : Aucune révélation ni dépense de crédit sans approbation visuelle explicite.
* **Plafond strict de volume** : Maximum 20 contacts révélés par run hebdomadaire pour éviter tout spam ou sollicitation de masse.
* **Dédoublonnage déterministe** : Empêche la répétition ou le sur-ciblage d'un même interlocuteur.
* **Chiffrement du stockage** : Recommandation d'activer BitLocker / FileVault / LUKS sur les partitions hébergeant `data/prospection.db`.
