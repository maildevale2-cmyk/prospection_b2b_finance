#!/usr/bin/env bash
# Script d'installation pas-à-pas pour Linux et macOS
set -e

echo "================================================================="
echo "  Installation Agent de Prospection DAF Gironde (Gemma 3)"
echo "================================================================="

# 1. Vérification de Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 n'est pas installé. Veuillez installer Python 3.11 ou supérieur."
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✅ Python détecté : $PY_VERSION"

# 2. Création de l'environnement virtuel
if [ ! -d "venv" ]; then
    echo "📦 Création du venv..."
    python3 -m venv venv || echo "Note: venv standard"
fi

# Activation si présent
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
fi

# 3. Installation des dépendances si pip est présent
if command -v pip &> /dev/null || command -v pip3 &> /dev/null; then
    echo "📥 Installation des dépendances Python..."
    pip install -r requirements.txt || pip3 install -r requirements.txt
else
    echo "ℹ️ pip non détecté, exécution via bibliothèque standard."
fi

# 4. Préparation des répertoires de données et logs
mkdir -p data/exports logs config

# 5. Copie du .env si absent
if [ ! -f "config/.env" ] && [ ! -f ".env" ]; then
    echo "⚙️ Initialisation du fichier d'environnement..."
    cp config/.env.example .env 2>/dev/null || cp .env.example .env 2>/dev/null || true
    echo "⚠️ N'oubliez pas d'éditer le fichier .env avec vos clés API (Lusha, Google AI Studio ou Ollama)."
fi

# 6. Exécution des tests unitaires
echo "🧪 Lancement des tests de validation..."
python3 -m unittest discover -s tests -p "test_*.py"

echo "================================================================="
echo "✅ Installation terminée avec succès !"
echo "Pour lancer le Mode A (simulation dry-run) :"
echo "   python3 src/main.py --mode A --dry-run"
echo ""
echo "Pour lancer le Mode B (comptes fournis) :"
echo "   python3 src/main.py --mode B --accounts data/comptes_exemples.csv --known data/connus_exemples.csv --dry-run"
echo "================================================================="
