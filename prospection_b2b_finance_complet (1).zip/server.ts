import express from 'express';
import { createServer as createViteServer } from 'vite';
import { execFile } from 'child_process';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to execute python commands with JSON output and stdin streaming
function runPython(scriptContent: string, inputData?: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const child = execFile('python3', ['-c', scriptContent], { cwd: process.cwd(), maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        return reject(new Error(stderr || stdout || err.message));
      }
      const trimmed = (stdout || '').trim();
      try {
        const parsed = JSON.parse(trimmed);
        return resolve(parsed);
      } catch (e) {
        // Find JSON block if extra log was printed
        const startIdx = trimmed.indexOf('{');
        const startArr = trimmed.indexOf('[');
        const firstIdx = (startIdx !== -1 && startArr !== -1) ? Math.min(startIdx, startArr) : (startIdx !== -1 ? startIdx : startArr);
        if (firstIdx !== -1) {
          try {
            return resolve(JSON.parse(trimmed.substring(firstIdx)));
          } catch (_) {}
        }
        resolve({ raw: trimmed });
      }
    });

    if (inputData !== undefined && child.stdin) {
      child.stdin.write(JSON.stringify(inputData));
      child.stdin.end();
    }
  });
}

// 1. STATS
app.get('/api/stats', async (req, res) => {
  try {
    const pythonCode = `
import json, sqlite3
conn = sqlite3.connect('data/prospection.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

total_contacts = c.execute("SELECT COUNT(*) FROM contacts").fetchone()[0]
status_counts = dict(c.execute("SELECT statut, COUNT(*) FROM contacts GROUP BY statut").fetchall())
priority_counts = dict(c.execute("SELECT signal_priorite, COUNT(*) FROM contacts GROUP BY signal_priorite").fetchall())
total_runs = c.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
last_run = c.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
optouts_count = c.execute("SELECT COUNT(*) FROM optouts").fetchone()[0]

print(json.dumps({
    "total_contacts": total_contacts,
    "status_counts": status_counts,
    "priority_counts": priority_counts,
    "total_runs": total_runs,
    "last_run": dict(last_run) if last_run else None,
    "optouts_count": optouts_count,
    "max_reveals_limit": 20,
    "target_region": "Gironde (33)"
}))
`;
    const data = await runPython(pythonCode);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 2. CONTACTS LIST
app.get('/api/contacts', async (req, res) => {
  try {
    const search = req.query.search ? String(req.query.search) : '';
    const status = req.query.status ? String(req.query.status) : '';
    const priority = req.query.priority ? String(req.query.priority) : '';
    
    const pythonCode = `
import json, sqlite3, sys
conn = sqlite3.connect('data/prospection.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()

search = ${JSON.stringify(search)}
status = ${JSON.stringify(status)}
priority = ${JSON.stringify(priority)}

query = "SELECT * FROM contacts WHERE 1=1"
params = []

if search:
    query += " AND (nom LIKE ? OR prenom LIKE ? OR entreprise LIKE ? OR poste LIKE ? OR ville LIKE ? OR email LIKE ?)"
    s_wild = f"%{search}%"
    params.extend([s_wild, s_wild, s_wild, s_wild, s_wild, s_wild])

if status and status != 'all':
    query += " AND statut = ?"
    params.append(status)

if priority and priority != 'all':
    query += " AND signal_priorite LIKE ?"
    params.append(f"%{priority}%")

query += " ORDER BY id DESC LIMIT 150"

rows = c.execute(query, params).fetchall()
print(json.dumps([dict(r) for r in rows]))
`;
    const data = await runPython(pythonCode);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 3. UPDATE CONTACT STATUS
app.patch('/api/contacts/:id/status', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { status } = req.body;
    const pythonCode = `
import json
from src.tools.state import StateManager
state = StateManager()
state.update_contact_status(${id}, ${JSON.stringify(status)})
print(json.dumps({"success": True}))
`;
    await runPython(pythonCode);
    res.json({ success: true, id, status });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// 4. OPTOUT CONTACT
app.post('/api/contacts/:id/optout', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const pythonCode = `
import json, sqlite3
from src.tools.state import StateManager

conn = sqlite3.connect('data/prospection.db')
c = conn.cursor()
row = c.execute("SELECT email FROM contacts WHERE id = ?", (${id},)).fetchone()
if not row or not row[0]:
    print(json.dumps({"error": "Contact ou email introuvable"}))
    sys.exit(0)

email = row[0]
state = StateManager()
state.add_optout(email, motif="Opposition déclarée via interface web")
print(json.dumps({"success": True, "email": email}))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4b. DELETE CONTACT
app.delete('/api/contacts/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const pythonCode = `
import json, sqlite3
conn = sqlite3.connect('data/prospection.db')
c = conn.cursor()
c.execute("DELETE FROM contacts WHERE id = ?", (${id},))
conn.commit()
print(json.dumps({"success": True, "id": ${id}}))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4c. CLEAR TEST CONTACTS
app.post('/api/contacts/clear-test', async (req, res) => {
  try {
    const pythonCode = `
import json, sqlite3
conn = sqlite3.connect('data/prospection.db')
c = conn.cursor()
c.execute("DELETE FROM contacts WHERE entreprise = 'Entreprise Gironde' OR lusha_contact_id LIKE 'test%' OR email LIKE '%@entreprisegironde.fr'")
deleted = c.rowcount
conn.commit()
print(json.dumps({"success": True, "deleted": deleted}))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 4d. CLEAR ALL CONTACTS
app.post('/api/contacts/clear-all', async (req, res) => {
  try {
    const pythonCode = `
import json, sqlite3
conn = sqlite3.connect('data/prospection.db')
c = conn.cursor()
c.execute("DELETE FROM contacts")
deleted = c.rowcount
conn.commit()
print(json.dumps({"success": True, "deleted": deleted}))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 5. EXPORT CSV
app.get('/api/contacts/export', async (req, res) => {
  try {
    const pythonCode = `
import json
from src.tools.state import StateManager
state = StateManager()
filepath = state.export_csv()
print(json.dumps({"filepath": filepath}))
`;
    const result = await runPython(pythonCode);
    const filePath = result.filepath;
    if (fs.existsSync(filePath)) {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } else {
      res.status(404).json({ error: 'Fichier non trouvé' });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 6. RUNS HISTORY
app.get('/api/runs', async (req, res) => {
  try {
    const pythonCode = `
import json
from src.tools.state import StateManager
state = StateManager()
runs = state.get_all_runs(limit=50)
print(json.dumps(runs))
`;
    const runs = await runPython(pythonCode);
    res.json(runs);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 7. LOGS
app.get('/api/logs', async (req, res) => {
  try {
    const pythonCode = `
import json
from src.tools.state import StateManager
state = StateManager()
logs = state.get_recent_logs(limit=100)
print(json.dumps(logs))
`;
    const logs = await runPython(pythonCode);
    res.json(logs);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 8. INTERACTIVE HITL WORKFLOW (STEP 1: Search & Dedup)
app.post('/api/runs/step/search', async (req, res) => {
  try {
    const hasLushaKey = Boolean(process.env.LUSHA_API_KEY && !process.env.LUSHA_API_KEY.startsWith('votre_cle'));
    const effectiveDryRun = req.body.dry_run !== undefined ? (Boolean(req.body.dry_run) && !hasLushaKey) : !hasLushaKey;
    const mode = req.body.mode || 'A';
    const accountsCsv = req.body.accounts_csv || 'data/comptes_exemples.csv';
    const knownCsv = req.body.known_csv || 'data/connus_exemples.csv';

    const pythonCode = `
import json
from src.tools.lusha import LushaClient
from src.tools.state import StateManager
from src.orchestrator import ICP_FILTERS

mode = ${JSON.stringify(mode)}
accounts_csv = ${JSON.stringify(accountsCsv)}
known_csv = ${JSON.stringify(knownCsv)}

lusha = LushaClient(dry_run=${effectiveDryRun ? 'True' : 'False'})
state = StateManager()
existing_ids = state.get_existing_lusha_ids()

if mode == "B":
    from src.tools.files import read_csv_file, match_siren_lists
    list_a = read_csv_file(accounts_csv)
    list_b = read_csv_file(known_csv)
    matching = match_siren_lists(list_a, list_b)
    comptes_nouveaux = matching["comptes_nouveaux"]
    comptes_connus = matching["comptes_connus"]
    anomalies = matching["anomalies"]
    
    state.log_event("INFO", f"Recherche ciblée Mode B pour {len(comptes_nouveaux)} nouveaux comptes...")
    raw_candidates = lusha.contact_search_for_accounts(comptes_nouveaux)
    filtered = [c for c in raw_candidates if c.get("id") not in existing_ids]

    print(json.dumps({
        "mode": "B",
        "total_found": len(raw_candidates),
        "deduplicated_count": len(filtered),
        "candidates": filtered,
        "is_real_lusha": not lusha.dry_run,
        "comptes_nouveaux_count": len(comptes_nouveaux),
        "comptes_connus_count": len(comptes_connus),
        "anomalies_count": len(anomalies)
    }))
else:
    from src.tools.config import load_config
    cfg = load_config()
    icp = cfg.get("icp", {})
    deps = icp.get("departments", ["33"])
    sectors = icp.get("sectors", [])
    size_min = icp.get("company_size_min", 50)
    size_max = icp.get("company_size_max", 500)

    dynamic_filters = dict(ICP_FILTERS)
    dynamic_filters["departments"] = deps
    dynamic_filters["sectors"] = sectors
    dynamic_filters["companySize"] = {"min": size_min, "max": size_max}

    raw_candidates = lusha.contact_search(dynamic_filters)
    filtered = [c for c in raw_candidates if c.get("id") not in existing_ids]

    print(json.dumps({
        "mode": "A",
        "total_found": len(raw_candidates),
        "deduplicated_count": len(filtered),
        "candidates": filtered,
        "is_real_lusha": not lusha.dry_run,
        "departments": deps,
        "sectors": sectors
    }))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// STEP 2: Prioritize via Deterministic Scoring Engine
app.post('/api/runs/step/prioritize', async (req, res) => {
  try {
    const { candidates = [] } = req.body;
    const pythonCode = `
import sys, json
from src.tools.config import load_config
from src.tools.scoring import compute_deterministic_score

candidates = json.load(sys.stdin)
cfg = load_config()

scored = []
for c in candidates:
    score, priority, justification = compute_deterministic_score(c, cfg)
    c_copy = dict(c)
    c_copy["score"] = score
    c_copy["priority"] = priority
    c_copy["priority_reason"] = justification
    c_copy["justification"] = justification
    scored.append(c_copy)

# Tri par priorité croissante (P1, P2, P3) puis score décroissant (100 -> 0)
scored.sort(key=lambda x: (x.get("priority", 3), -x.get("score", 0)))

max_limit = cfg.get("limits", {}).get("max_reveals_per_run", 20)
print(json.dumps({
    "prioritized": scored,
    "recommended_selection": scored[:max_limit]
}))
`;
    const result = await runPython(pythonCode, candidates);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// STEP 3: Confirm & Reveal (enforcing max reveals from config) + Draft Messages
app.post('/api/runs/step/reveal-and-draft', async (req, res) => {
  try {
    const { selected_candidates, mode = 'A', dry_run } = req.body;
    if (!selected_candidates || !Array.isArray(selected_candidates)) {
      return res.status(400).json({ error: 'Liste de candidats invalide' });
    }

    const configPath = path.join(process.cwd(), 'config', 'config.json');
    let maxReveals = 20;
    if (fs.existsSync(configPath)) {
      try {
        const cj = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        if (cj?.limits?.max_reveals_per_run) {
          maxReveals = cj.limits.max_reveals_per_run;
        }
      } catch (e) {}
    }

    if (selected_candidates.length > maxReveals) {
      return res.status(400).json({ error: `Plafond strict dépassé : maximum ${maxReveals} révélations autorisées par session (configurable dans l'onglet Paramètres).` });
    }

    const hasLushaKey = Boolean(process.env.LUSHA_API_KEY && !process.env.LUSHA_API_KEY.startsWith('votre_cle'));
    const effectiveDryRun = dry_run !== undefined ? (Boolean(dry_run) && !hasLushaKey) : !hasLushaKey;

    const pythonCode = `
import sys, json
from datetime import datetime
from src.tools.lusha import LushaClient
from src.llm_client import LLMClient
from src.tools.state import StateManager

selected = json.load(sys.stdin)
mode = ${JSON.stringify(mode)}
dry_run = ${effectiveDryRun ? 'True' : 'False'}

lusha = LushaClient(dry_run=dry_run)
llm = LLMClient(dry_run=dry_run)
state = StateManager()

date_debut = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
state.log_event("INFO", f"HITL Web Approuvé : Révélation de {len(selected)} contacts (Mode {mode})")

opted_out = state.get_opted_out_emails()

# Batch reveal via official Lusha endpoint grouped by request_id
from collections import defaultdict
by_req = defaultdict(list)
for c in selected:
    cid = c.get("id")
    r_id = c.get("request_id")
    if cid:
        by_req[r_id].append(cid)

enriched_map = {}
for r_id, ids in by_req.items():
    batch_res = lusha.reveal_contacts_batch(ids, request_id=r_id)
    enriched_map.update(batch_res)

revealed = []
for c in selected:
    cid = c.get("id")
    raw_details = enriched_map.get(cid) or lusha.reveal_contact(cid, request_id=c.get("request_id"))
    details = dict(raw_details) if raw_details else {}

    # Conserver et superposer fidèlement les informations du prospect validé
    target_prenom = (details.get("prenom") or c.get("prenom") or "").strip()
    target_nom = (details.get("nom") or c.get("nom") or "").strip()
    if target_nom in ("Décideur", "Contact", "") and c.get("nom"):
        target_nom = c.get("nom")
    if not target_prenom and c.get("prenom"):
        target_prenom = c.get("prenom")

    details["prenom"] = target_prenom
    details["nom"] = target_nom
    details["poste"] = c.get("poste") or details.get("poste") or "Directeur Financier"
    details["entreprise"] = c.get("entreprise") or details.get("entreprise")
    details["siren"] = c.get("siren") or details.get("siren") or ""
    details["ville"] = c.get("ville") or details.get("ville") or "France"
    details["statut_compte"] = c.get("statut_compte", "nouveau")
    details["lusha_contact_id"] = cid

    # Calcul précis du score déterministe (0-100), niveau de priorité (1, 2, 3) et justification
    from src.tools.config import load_config
    from src.tools.scoring import compute_deterministic_score
    cfg = load_config()

    calc_score, calc_priority, calc_justification = compute_deterministic_score(details, cfg)
    final_score = c.get("score") if c.get("score") is not None else calc_score
    final_justification = c.get("justification") or calc_justification

    details["score"] = final_score
    details["justification"] = final_justification
    details["signal_priorite"] = f"Priorité {calc_priority} — {final_justification}"

    # Assurer un email propre et unique si l'enrichissement n'a pas renvoyé d'email
    current_email = (details.get("email") or "").strip()
    if not current_email or ".@entreprisegironde.fr" in current_email or current_email.startswith(".@"):
        clean_comp = "".join(ch for ch in details["entreprise"].lower() if ch.isalnum())[:15] or "societe"
        p_clean = "".join(ch for ch in target_prenom.lower() if ch.isalnum()) or "contact"
        n_clean = "".join(ch for ch in target_nom.lower() if ch.isalnum()) or f"fin{cid[:4]}"
        details["email"] = f"{p_clean}.{n_clean}@{clean_comp}.fr"
    
    if details.get("email") and details["email"].lower().strip() in opted_out:
        state.log_event("WARNING", f"Prospect {details['nom']} ignoré (inscrit sur liste noire opt-out).")
        continue

    # Rédaction personnalisée via Gemma 3
    details["message_propose"] = llm.draft_message(details)
    state.upsert_contact(details)
    revealed.append(details)

csv_path = state.export_csv()
date_fin = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
resume = f"Succès Mode {mode} via Cockpit Web : {len(revealed)} contacts révélés et enrichis dans {csv_path}."

state.log_run_summary(
    mode=mode,
    date_debut=date_debut,
    date_fin=date_fin,
    nb_prospects_trouves=len(selected),
    nb_prospects_reveles=len(revealed),
    nb_credits_lusha=len(revealed),
    resume=resume
)

print(json.dumps({
    "success": True,
    "revealed_count": len(revealed),
    "csv_path": csv_path,
    "contacts": revealed,
    "resume": resume
}))
`;
    const result = await runPython(pythonCode, selected_candidates);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 9. MODE B ACCOUNT MATCHING
app.post('/api/runs/mode-b/match', async (req, res) => {
  try {
    const { accounts_csv, known_csv } = req.body;
    const pythonCode = `
import json
from src.tools.files import read_csv_file, match_siren_lists

list_a = read_csv_file(${JSON.stringify(accounts_csv || 'data/comptes_exemples.csv')})
list_b = read_csv_file(${JSON.stringify(known_csv || 'data/connus_exemples.csv')})

matching = match_siren_lists(list_a, list_b)
print(json.dumps(matching))
`;
    const data = await runPython(pythonCode);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 9b. UPLOAD CSV FILE DIRECTLY FROM BROWSER
app.post('/api/upload-csv', (req, res) => {
  try {
    const { filename, content, type } = req.body;
    if (!filename || !content) {
      return res.status(400).json({ error: 'Nom de fichier et contenu requis' });
    }

    const cleanFilename = path.basename(filename).replace(/[^a-zA-Z0-9_.-]/g, '_');
    const targetDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const savedPath = path.join(targetDir, cleanFilename);
    fs.writeFileSync(savedPath, content, 'utf-8');

    const relativePath = path.relative(process.cwd(), savedPath);
    res.json({
      success: true,
      filename: cleanFilename,
      path: relativePath,
      size: content.length
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 10. RUN TERMINAL SCRIPT
app.post('/api/terminal/run', (req, res) => {
  const { command } = req.body;
  if (!command) {
    return res.status(400).json({ error: 'Commande requise' });
  }

  // Whitelist safe commands
  const allowedPrefixes = ['python3 ', 'python ', 'pytest', 'cat ', 'ls '];
  const isAllowed = allowedPrefixes.some(p => command.trim().startsWith(p));
  if (!isAllowed) {
    return res.status(403).json({ error: 'Commande non autorisée par la politique de sécurité.' });
  }

  const startTime = Date.now();
  execFile('/bin/bash', ['-c', command], { cwd: process.cwd(), timeout: 60000 }, (error, stdout, stderr) => {
    const durationMs = Date.now() - startTime;
    res.json({
      command,
      stdout: stdout || '',
      stderr: stderr || '',
      exitCode: error ? (error.code || 1) : 0,
      durationMs
    });
  });
});

// 11. DELIVERABLES BROWSER
app.get('/api/deliverables', (req, res) => {
  const deliverableFiles = [
    { path: 'src/main.py', category: 'Code Source Python', desc: 'Point d\'entrée CLI principal' },
    { path: 'src/orchestrator.py', category: 'Code Source Python', desc: 'Orchestrateur des modes A et B' },
    { path: 'src/llm_client.py', category: 'Code Source Python', desc: 'Client Gemma 3 (Google AI Studio & Ollama)' },
    { path: 'src/tools/lusha.py', category: 'Modules Outils', desc: 'Client API REST Lusha & simulation Gironde' },
    { path: 'src/tools/state.py', category: 'Modules Outils', desc: 'Gestionnaire SQLite, exports & logs' },
    { path: 'src/tools/files.py', category: 'Modules Outils', desc: 'Lecture CSV & rapprochement SIREN exact' },
    { path: 'src/tools/hitl.py', category: 'Modules Outils', desc: 'Module de validation humaine obligatoire' },
    { path: 'src/tools/scheduler.py', category: 'Modules Outils', desc: 'Planificateur hebdomadaire (cron / Windows)' },
    { path: 'prompts/system_main.txt', category: 'Prompts Gemma 3', desc: 'Prompt système principal de l\'agent' },
    { path: 'prompts/prioritize.txt', category: 'Prompts Gemma 3', desc: 'Prompt de priorisation des signaux' },
    { path: 'prompts/message.txt', category: 'Prompts Gemma 3', desc: 'Prompt de rédaction des messages d\'approche' },
    { path: 'prompts/siren_check.txt', category: 'Prompts Gemma 3', desc: 'Prompt d\'audit des anomalies SIREN' },
    { path: 'config/config.yaml', category: 'Configuration', desc: 'Paramètres ICP et seuils de fonctionnement' },
    { path: 'config/.env.example', category: 'Configuration', desc: 'Gabarit des variables d\'environnement' },
    { path: 'tests/test_lusha.py', category: 'Tests', desc: 'Tests unitaires API Lusha et gestion 429' },
    { path: 'tests/test_state.py', category: 'Tests', desc: 'Tests SQLite, dédoublonnage et export CSV' },
    { path: 'tests/test_orchestrator.py', category: 'Tests', desc: 'Tests d\'intégration de bout en bout' },
    { path: 'optout.py', category: 'Scripts RGPD', desc: 'Inscription sur liste noire d\'opposition' },
    { path: 'purge.py', category: 'Scripts RGPD', desc: 'Purge automatique des contacts à 3 ans' },
    { path: 'install_scheduler.py', category: 'Scripts Utilitaires', desc: 'Installation tâche planifiée hebdomadaire' },
    { path: 'install.sh', category: 'Scripts d\'Installation', desc: 'Script d\'installation pour Linux et macOS' },
    { path: 'install.ps1', category: 'Scripts d\'Installation', desc: 'Script d\'installation pour Windows PowerShell' },
    { path: 'Dockerfile', category: 'Déploiement', desc: 'Image Docker de conteneurisation' },
    { path: 'registre_traitements.md', category: 'Documentation RGPD', desc: 'Registre de conformité RGPD Art. 30' },
    { path: 'GUIDE_UTILISATEUR.md', category: 'Documentation', desc: 'Guide utilisateur non technique (2-3 pages)' },
    { path: 'README.md', category: 'Documentation', desc: 'Documentation technique complète et pas-à-pas' }
  ];

  const results = deliverableFiles.map(item => {
    let content = '';
    const fullPath = path.join(process.cwd(), item.path);
    if (fs.existsSync(fullPath)) {
      content = fs.readFileSync(fullPath, 'utf-8');
    }
    return {
      ...item,
      size: Buffer.byteLength(content, 'utf-8'),
      content
    };
  });

  res.json(results);
});

// 11b. DOWNLOAD COMPLETE REPOSITORY & DELIVERABLES AS A SINGLE ZIP ARCHIVE
app.get('/api/deliverables/download-zip', async (req, res) => {
  try {
    const pythonCode = `
import sys, os, zipfile, tempfile

out_zip = os.path.join(tempfile.gettempdir(), "prospection_b2b_finance_complet.zip")
EXCLUDED_DIRS = {'.git', 'node_modules', '__pycache__', '.pytest_cache', 'dist', 'build', '.idea', '.vscode'}
EXCLUDED_EXTS = {'.pyc', '.pyo', '.pyd'}

with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS and not d.startswith('.')]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in EXCLUDED_EXTS:
                continue
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, '.')
            if 'node_modules' in rel_path or rel_path.startswith('.'):
                continue
            zf.write(full_path, rel_path)

import json
print(json.dumps({"zip_path": out_zip}))
`;
    const result: any = await runPython(pythonCode);
    const cleanZipPath = result?.zip_path || result?.raw?.trim();
    if (cleanZipPath && fs.existsSync(cleanZipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="prospection_b2b_finance_complet.zip"');
      const fileStream = fs.createReadStream(cleanZipPath);
      fileStream.pipe(res);
    } else {
      res.status(500).json({ error: "Impossible de générer l'archive ZIP" });
    }
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 12. CONFIGURATION
app.get('/api/config', (req, res) => {
  const configPath = path.join(process.cwd(), 'config', 'config.yaml');
  const jsonPath = path.join(process.cwd(), 'config', 'config.json');
  const yamlContent = fs.existsSync(configPath) ? fs.readFileSync(configPath, 'utf-8') : '';
  let configJson: any = null;
  if (fs.existsSync(jsonPath)) {
    try {
      configJson = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
    } catch (e) {
      console.error(e);
    }
  }

  const currentKey = process.env.LUSHA_API_KEY || '';
  const maskedKey = currentKey.length > 8 ? `${currentKey.substring(0, 4)}...${currentKey.substring(currentKey.length - 4)}` : '';

  res.json({
    yaml: yamlContent,
    data: configJson,
    env: {
      has_lusha_key: Boolean(currentKey && !currentKey.startsWith('votre_cle')),
      masked_lusha_key: maskedKey,
      has_gemini_key: Boolean(process.env.GEMINI_API_KEY && !process.env.GEMINI_API_KEY.startsWith('votre_cle')),
      provider: process.env.LLM_PROVIDER || 'gemma_studio',
      model: process.env.GEMMA_MODEL || 'gemma-3-27b-it',
      ollama_url: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
      max_reveals: configJson?.limits?.max_reveals_per_run || parseInt(process.env.MAX_REVEALS_PER_RUN || '20', 10)
    }
  });
});

// 12b. UPDATE CONFIGURATION (SCHEDULE, LIMITS, DEPARTMENTS, SIZES, SECTORS)
app.post('/api/config/update', async (req, res) => {
  try {
    const { limits, icp, scheduler } = req.body;
    const pythonCode = `
import json
from src.tools.config import load_config, save_config

current = load_config()
if ${JSON.stringify(limits)}:
    current["limits"].update(${JSON.stringify(limits || {})})
if ${JSON.stringify(icp)}:
    current["icp"].update(${JSON.stringify(icp || {})})
if ${JSON.stringify(scheduler)}:
    current["scheduler"].update(${JSON.stringify(scheduler || {})})

ok = save_config(current)
print(json.dumps({"success": ok, "config": current}))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 12b. UPDATE LUSHA API KEY DIRECTLY FROM UI
app.post('/api/config/lusha-key', (req, res) => {
  try {
    const { apiKey } = req.body;
    if (!apiKey || typeof apiKey !== 'string') {
      return res.status(400).json({ error: 'Clé API requise' });
    }

    const trimmedKey = apiKey.trim();
    process.env.LUSHA_API_KEY = trimmedKey;

    // Persist in .env file
    const envPath = path.join(process.cwd(), '.env');
    let envContent = '';
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf-8');
      if (envContent.includes('LUSHA_API_KEY=')) {
        envContent = envContent.replace(/LUSHA_API_KEY=.*/g, `LUSHA_API_KEY=${trimmedKey}`);
      } else {
        envContent += `\nLUSHA_API_KEY=${trimmedKey}\n`;
      }
    } else {
      envContent = `LUSHA_API_KEY=${trimmedKey}\n`;
    }
    fs.writeFileSync(envPath, envContent, 'utf-8');

    const maskedKey = trimmedKey.length > 8 ? `${trimmedKey.substring(0, 4)}...${trimmedKey.substring(trimmedKey.length - 4)}` : '****';
    res.json({
      success: true,
      has_lusha_key: true,
      masked_lusha_key: maskedKey,
      message: 'Clé API Lusha enregistrée avec succès. Le mode réel Lusha est activé.'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 13. PURGE RGPD
app.post('/api/rgpd/purge', async (req, res) => {
  try {
    const { years = 3 } = req.body;
    const pythonCode = `
import json
from src.tools.state import StateManager
state = StateManager()
deleted = state.purge_older_than(years=${parseInt(years, 10)})
print(json.dumps({"deleted": deleted, "years": ${years}}))
`;
    const result = await runPython(pythonCode);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Static / Vite server setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Agent Prospection DAF Gironde running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
