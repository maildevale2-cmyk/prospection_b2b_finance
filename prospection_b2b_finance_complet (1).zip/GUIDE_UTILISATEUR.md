# Guide Utilisateur — Agent de Prospection DAF Gironde

Ce guide est destiné au commercial B2B. Il explique pas-à-pas comment utiliser l'agent au quotidien, sans compétences informatiques poussées.

---

## 1. Vue d'ensemble de l'outil

L'agent a pour mission de trouver chaque semaine les meilleurs contacts financiers en Gironde (DAF, CFO, Credit Managers) et de préparer des messages d'approche personnalisés, tout en vous laissant le contrôle total sur vos crédits et vos envois.

### Les 4 règles d'or :
1. **Vous gardez toujours le contrôle** : Aucun contact n'est acheté/révélé sans votre validation visuelle.
2. **Plafond de 20 contacts par run** : Maîtrise absolue du budget crédits.
3. **Zéro action LinkedIn automatisée** : Respect strict des conditions d'utilisation de LinkedIn (pas de risque de bannissement).
4. **Pas de spam** : Messages sur-mesure (80 à 120 mots) ciblés sur les signaux récents.

---

## 2. Vos deux modes de prospection

### Mode A : La recherche autonome (Recommandé chaque lundi matin)
L'agent scrute automatiquement la Gironde selon votre profil idéal :
* Entreprises de 100 à 1000 salariés (secteurs Industrie & Commerce de gros)
* Villes prioritaires : Bordeaux, Mérignac, Pessac, Libourne, Bègles, etc.
* Priorité n°1 : Prise de poste récente (< 6 mois)
* Priorité n°2 : Recrutement en cours dans le pôle Finance
* Priorité n°3 : Décideur en place

**Comment le lancer ?**
```bash
python src/main.py --mode A
```
*(Ou en mode essai sans dépenser de crédit : `python src/main.py --mode A --dry-run`)*

---

### Mode B : La liste de comptes fournie
Vous avez une liste d'entreprises cibles (ex: salon professionnel, prospection ciblée) :
1. Préparez un fichier `comptes.csv` avec deux colonnes : `nom;siren`
2. Munissez-vous du fichier de vos clients/prospects déjà connus `connus.csv` : `nom;siren`
3. Lancez l'agent :
```bash
python src/main.py --mode B --accounts mes_comptes.csv --known mes_connus.csv
```
L'agent identifie les nouveaux comptes, recherche les décideurs Finance, et vous soumet la liste à valider.

---

## 3. L'étape de validation humaine (HITL)

Lorsque l'agent a terminé la recherche, il affiche un récapitulatif dans votre console ou votre tableau de bord :
* Nom et prénom du prospect
* Poste exact
* Nom de l'entreprise et ville
* Signal détecté (ex: *Changement de poste récent il y a 3 mois*)

Il vous pose la question :
```
Valider la révélation payante de ces contacts ? (o/n) :
```
* Tapez **o** (ou *oui*) : L'agent enrichit les numéros et emails, rédige les messages personnalisés et enregistre tout dans le fichier de suivi.
* Tapez **n** : L'opération s'arrête immédiatement sans consommer le moindre crédit Lusha.

---

## 4. Exploiter les résultats (Fichier Excel / CSV)

Dès la fin de l'exécution, vos résultats sont automatiquement exportés dans le dossier :
`data/exports/prospects_gironde_AAAAMMJJ_HHMMSS.csv`

Ce fichier est encodé au format français standard (séparateur point-virgule `;` avec encodage UTF-8 BOM). Il s'ouvre en un double-clic directement dans Microsoft Excel avec des colonnes propres :
* `nom`, `prenom`
* `poste`, `entreprise`, `ville`
* `email`, `telephone`, `linkedin`
* `signal_priorite`
* `message_propose` (message prêt à être copié-collé)
* `statut` (initialisé à `à contacter`)

---

## 5. Gestion des demandes d'opposition (RGPD)

Si un prospect répond par email en demandant de ne plus être contacté :
1. Ouvrez votre terminal
2. Tapez la commande suivante :
```bash
python optout.py --email prenom.nom@societe.com
```
Le contact est immédiatement effacé de votre base de prospection active et inscrit sur liste noire pour ne jamais réapparaître dans les futurs runs.

---

## 6. Programmation hebdomadaire automatique

Pour que l'agent se prépare automatiquement chaque lundi à 9h00 :
```bash
python install_scheduler.py --install
```
L'agent s'exécutera automatiquement en tâche de fond.
