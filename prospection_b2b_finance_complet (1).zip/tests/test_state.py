"""Unit tests for SQLite state manager and CSV export per section 12.1."""
import os
import unittest
import tempfile
from pathlib import Path
from src.tools.state import StateManager

class TestStateManager(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_prospection.db"
        self.state = StateManager(db_path=str(self.db_path))

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_upsert_contact_and_deduplication(self):
        contact_data = {
            "lusha_contact_id": "c_999",
            "nom": "Dupont",
            "prenom": "Alain",
            "poste": "DAF",
            "entreprise": "Gironde Logistique",
            "siren": "123456789",
            "ville": "Bordeaux",
            "email": "a.dupont@gironde-log.fr",
            "telephone": "+33 5 56 11 22 33",
            "linkedin": "https://linkedin.com/in/alaindupont",
            "signal_priorite": "Changement de poste récent (< 6 mois)",
            "message_propose": "Bonjour Alain...",
            "statut": "à contacter",
            "statut_compte": "nouveau"
        }

        # 1. Insertion
        cid1 = self.state.upsert_contact(contact_data)
        self.assertGreater(cid1, 0)

        # Vérifier que le lusha_contact_id est bien répertorié
        existing_ids = self.state.get_existing_lusha_ids()
        self.assertIn("c_999", existing_ids)

        # 2. Mise à jour (dédoublonnage strict sans réinsertion)
        contact_update = dict(contact_data)
        contact_update["poste"] = "Directeur Administratif et Financier Groupe"
        cid2 = self.state.upsert_contact(contact_update)
        self.assertEqual(cid1, cid2)

        contacts = self.state.get_all_contacts()
        self.assertEqual(len(contacts), 1)
        self.assertEqual(contacts[0]["poste"], "Directeur Administratif et Financier Groupe")

    def test_optout_and_blacklist_rgpd(self):
        email = "rgpd.optout@example.com"
        self.state.upsert_contact({
            "lusha_contact_id": "c_opt",
            "nom": "Opposition",
            "prenom": "Jean",
            "email": email,
            "statut": "à contacter"
        })

        self.assertFalse(self.state.is_opted_out(email))
        
        # Enregistrer l'opt-out
        self.state.add_optout(email, motif="Demande par email")
        self.assertTrue(self.state.is_opted_out(email))

        # Le contact doit être effacé de la base active
        contacts = self.state.get_all_contacts()
        emails = [c["email"] for c in contacts]
        self.assertNotIn(email, emails)

        # Une tentative d'upsert future doit être bloquée
        cid = self.state.upsert_contact({
            "lusha_contact_id": "c_opt_new",
            "email": email,
            "nom": "Test"
        })
        self.assertEqual(cid, 0)

    def test_export_csv_utf8_bom(self):
        self.state.upsert_contact({
            "lusha_contact_id": "c_export",
            "nom": "Éléonore",
            "prenom": "Jérôme",
            "poste": "Responsable Recouvrement",
            "entreprise": "Castel Vins",
            "ville": "Blanquefort",
            "email": "j.eleonore@castel.fr",
            "statut": "à contacter"
        })

        export_file = Path(self.temp_dir.name) / "export_test.csv"
        self.state.export_csv(str(export_file))
        self.assertTrue(export_file.exists())

        # Vérifier encodage UTF-8 BOM
        with open(export_file, "rb") as f:
            header_bytes = f.read(3)
            self.assertEqual(header_bytes, b'\xef\xbb\xbf')

if __name__ == "__main__":
    unittest.main()
