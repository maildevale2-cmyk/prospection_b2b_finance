"""Unit tests for Lusha client per section 12.1."""
import unittest
from unittest.mock import patch, MagicMock
import urllib.error
from src.tools.lusha import LushaClient

class TestLushaClient(unittest.TestCase):
    def setUp(self):
        self.client = LushaClient(api_key="test_key_123", dry_run=False)

    def test_search_contacts_dry_run(self):
        dry_client = LushaClient(dry_run=True)
        results = dry_client.contact_search({"location": "33"})
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 0)
        self.assertIn("poste", results[0])
        self.assertIn("entreprise", results[0])

    def test_reveal_contact_dry_run(self):
        dry_client = LushaClient(dry_run=True)
        contact = dry_client.reveal_contact("lusha_c_3301")
        self.assertEqual(contact["nom"], "Dubois")
        self.assertEqual(contact["entreprise"], "Castel Frères")
        self.assertIn("@", contact["email"])

    @patch("subprocess.run")
    def test_rate_limit_backoff_and_retry(self, mock_subproc):
        # Simuler un 429 au premier appel puis un 200 au deuxième
        proc_429 = MagicMock(returncode=0, stdout='{"code": 429, "error": "rate limit"}', stderr="")
        proc_200 = MagicMock(returncode=0, stdout='{"data": {"lastName": "Test", "firstName": "Jean"}}', stderr="")

        mock_subproc.side_effect = [proc_429, proc_200]

        res = self.client._post("/v2/contact/enrich", {"contactId": "123"}, max_retries=2)
        self.assertEqual(res["data"]["lastName"], "Test")
        self.assertEqual(mock_subproc.call_count, 2)

if __name__ == "__main__":
    unittest.main()
