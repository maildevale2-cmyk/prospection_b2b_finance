"""Integration tests for Orchestrator Mode A and Mode B per section 12.1 & 12.2."""
import unittest
import tempfile
from pathlib import Path
from src.orchestrator import Orchestrator

class TestOrchestrator(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = str(Path(self.temp_dir.name) / "test_orch.db")

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_run_mode_a_dry_run(self):
        orch = Orchestrator(dry_run=True, auto_approve=True, db_path=self.db_path)
        res = orch.run_mode_a()

        self.assertEqual(res["status"], "success")
        self.assertGreater(res["revealed_count"], 0)
        self.assertLessEqual(res["revealed_count"], 20, "Ne doit jamais dépasser 20 révélations")
        self.assertTrue(Path(res["csv_path"]).exists())

        # Vérifier que les contacts ont été persistés dans SQLite
        contacts = orch.state.get_all_contacts()
        self.assertGreater(len(contacts), 0)
        for c in contacts:
            self.assertIsNotNone(c["lusha_contact_id"])
            self.assertIn("Bonjour", c["message_propose"])

    def test_run_mode_a_user_declined(self):
        # Tester l'arrêt propre si l'utilisateur refuse la confirmation HITL
        orch = Orchestrator(dry_run=True, auto_approve=False, db_path=self.db_path)
        # Mock ask_user_confirmation to return False
        with unittest.mock.patch("src.orchestrator.ask_user_confirmation", return_value=False):
            res = orch.run_mode_a()
            self.assertEqual(res["status"], "cancelled")
            self.assertEqual(res["revealed_count"], 0)

    def test_run_mode_b_dry_run(self):
        orch = Orchestrator(dry_run=True, auto_approve=True, db_path=self.db_path)
        accounts_csv = "data/comptes_exemples.csv"
        known_csv = "data/connus_exemples.csv"

        res = orch.run_mode_b(accounts_csv, known_csv)
        self.assertEqual(res["status"], "success")
        self.assertGreater(res["revealed_count"], 0)
        self.assertIn("anomalies", res)
        # Vérifier qu'une anomalie a été détectée pour le SIREN invalide '99999'
        anomalies_sirens = [a["siren"] for a in res["anomalies"]]
        self.assertIn("99999", anomalies_sirens)

if __name__ == "__main__":
    unittest.main()
