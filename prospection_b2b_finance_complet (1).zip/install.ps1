# Script d'installation PowerShell pour Windows
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "  Installation Agent de Prospection DAF Gironde (Gemma 3) - Windows" -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan

# 1. Vérification de Python
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Python n'a pas été trouvé dans le PATH. Veuillez installer Python 3.11+ depuis python.org." -ForegroundColor Red
    Exit 1
}

$pyVersion = python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'
Write-Host "✅ Python détecté : $pyVersion" -ForegroundColor Green

# 2. Création de l'environnement virtuel
if (-not (Test-Path "venv")) {
    Write-Host "📦 Création de l'environnement virtuel venv..."
    python -m venv venv
}

if (Test-Path "venv\Scripts\Activate.ps1") {
    & ".\venv\Scripts\Activate.ps1"
}

# 3. Installation des dépendances
Write-Host "📥 Installation des modules requis (requirements.txt)..."
pip install -r requirements.txt

# 4. Préparation des dossiers
New-Item -ItemType Directory -Force -Path "data\exports", "logs", "config" | Out-Null

# 5. Configuration .env
if (-not (Test-Path ".env")) {
    Copy-Item "config\.env.example" ".env"
    Write-Host "⚙️ Fichier .env créé. Pensez à y renseigner vos clés LUSHA_API_KEY et GEMINI_API_KEY." -ForegroundColor Yellow
}

# 6. Tests de recette
Write-Host "🧪 Exécution des tests unitaires et d'intégration..."
python -m unittest discover -s tests -p "test_*.py"

Write-Host "=================================================================" -ForegroundColor Green
Write-Host "✅ Installation Windows terminée avec succès !" -ForegroundColor Green
Write-Host "Pour lancer le Mode A :" -ForegroundColor White
Write-Host "   python src\main.py --mode A --dry-run" -ForegroundColor Gray
Write-Host "=================================================================" -ForegroundColor Green
