/**
 * Moteur de calcul déterministe des priorités et scores (0-100) pour prospects B2B Finance.
 * Aucun appel LLM - Calcul 100% pur JavaScript / TypeScript en temps réel.
 */

export interface ScoringConfig {
  departments: string[];       // Ex: ['33'] ou ['33', '40', '64']
  company_size_min: number;    // Ex: 50
  company_size_max: number;    // Ex: 500
  sectors: string[];           // Ex: ['Commerce de gros', 'Industrie', 'Agroalimentaire']
}

export interface ScoringResult {
  score: number;               // 0 à 100
  priority: 1 | 2 | 3;
  priorityLabel: 'Priorité 1' | 'Priorité 2' | 'Priorité 3';
  isEliminated: boolean;
  eliminationReason?: string;
  justification: string;
  breakdown: {
    poste: number;       // max 50
    entreprise: number;  // max 30
    signaux: number;     // max 20
  };
  details: {
    posteLabel: string;
    locationLabel: string;
    sectorLabel: string;
    signalsLabels: string[];
  };
  badgeClass: string;
  dotClass: string;
}

const NOUVELLE_AQUITAINE_DEPTS = ['33', '40', '47', '64', '24', '17', '16', '19', '23', '87', '79', '86'];
const NOUVELLE_AQUITAINE_CITIES = [
  'bordeaux', 'merignac', 'pessac', 'libourne', 'begles', 'talence', 'villenave', 'gradignan',
  'angouleme', 'cognac', 'la rochelle', 'rochefort', 'saintes', 'perigueux', 'bergerac',
  'mont-de-marsan', 'dax', 'agen', 'villeneuve-sur-lot', 'marmande', 'pau', 'bayonne',
  'anglet', 'biarritz', 'limoges', 'poitiers', 'niort'
];

function normalizeText(str: string | undefined | null): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

/**
 * Calcule le score (0 à 100) et la priorité (1, 2 ou 3) d'un contact de façon déterministe.
 */
export function calculateContactScore(
  contact: {
    poste?: string;
    entreprise?: string;
    ville?: string;
    pays?: string;
    country?: string;
    mois_en_poste?: number;
    poste_finance_ouvert?: boolean;
    has_company_intent?: boolean;
    effectif?: number;
    employees_count?: number;
    secteur?: string;
    industry?: string;
    statut_compte?: string;
    signal_priorite?: string;
  },
  config: ScoringConfig
): ScoringResult {
  const jobNorm = normalizeText(contact.poste);
  const cityNorm = normalizeText(contact.ville);
  const countryNorm = normalizeText(contact.pays || contact.country || 'France');
  const sectorNorm = normalizeText(contact.secteur || contact.industry);
  const employees = contact.effectif || contact.employees_count;
  const tenure = contact.mois_en_poste;
  const hasJobIntent = Boolean(contact.poste_finance_ouvert || contact.has_company_intent);

  // -------------------------------------------------------------
  // ÉTAPE 1 : FILTRES ÉLIMINATOIRES (Score 0, Priorité 3)
  // -------------------------------------------------------------
  // 1.1 Pays différent de la France
  if (countryNorm && !countryNorm.includes('france') && !countryNorm.includes('fr')) {
    return {
      score: 0,
      priority: 3,
      priorityLabel: 'Priorité 3',
      isEliminated: true,
      eliminationReason: 'Pays hors France',
      justification: 'Contact écarté : localisation en dehors du territoire français.',
      breakdown: { poste: 0, entreprise: 0, signaux: 0 },
      details: { posteLabel: 'Hors cible', locationLabel: countryNorm, sectorLabel: sectorNorm, signalsLabels: [] },
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
      dotClass: 'bg-slate-400'
    };
  }

  // 1.2 Effectif hors intervalle
  if (employees !== undefined && employees !== null && employees > 0) {
    if (employees < config.company_size_min || employees > config.company_size_max) {
      return {
        score: 0,
        priority: 3,
        priorityLabel: 'Priorité 3',
        isEliminated: true,
        eliminationReason: `Effectif (${employees} sal.) hors bornes [${config.company_size_min} - ${config.company_size_max}]`,
        justification: `Contact écarté : effectif entreprise (${employees} sal.) hors de la cible [${config.company_size_min} - ${config.company_size_max}].`,
        breakdown: { poste: 0, entreprise: 0, signaux: 0 },
        details: { posteLabel: contact.poste || '', locationLabel: contact.ville || '', sectorLabel: sectorNorm, signalsLabels: [] },
        badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
        dotClass: 'bg-slate-400'
      };
    }
  }

  // 1.3 Poste sans aucun rapport avec Finance / Compta / Crédit
  const forbiddenKeywords = [
    'marketing', 'achats', 'purchasing', 'buyer', 'logistique', 'logistics', 'supply chain',
    'informatique', 'developer', 'software', 'it manager', 'commercial', 'sales', 'business developer',
    'communication', 'ressources humaines', 'human resources', 'recruiter', 'technicien', 'juriste'
  ];
  const isForbidden = forbiddenKeywords.some(kw => jobNorm.includes(kw));
  // S'assurer qu'il ne s'agit pas d'un DAF ou contrôleur dans un de ces domaines
  const hasFinanceKeyword = ['daf', 'financ', 'cfo', 'comptab', 'credit', 'recouv', 'tresor', 'bfr'].some(k => jobNorm.includes(k));

  if (isForbidden && !hasFinanceKeyword) {
    return {
      score: 0,
      priority: 3,
      priorityLabel: 'Priorité 3',
      isEliminated: true,
      eliminationReason: 'Poste hors fonctions Finance / Crédit',
      justification: 'Contact écarté : intitulé de poste sans rapport avec la gestion financière ou le crédit.',
      breakdown: { poste: 0, entreprise: 0, signaux: 0 },
      details: { posteLabel: contact.poste || '', locationLabel: contact.ville || '', sectorLabel: sectorNorm, signalsLabels: [] },
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
      dotClass: 'bg-slate-400'
    };
  }

  // -------------------------------------------------------------
  // ÉTAPE 2 : SCORE DU POSTE (sur 50 points)
  // -------------------------------------------------------------
  let scorePoste = 0;
  let posteLabel = '';

  const tier50 = [
    'daf', 'directeur administratif et financier', 'directrice administrative et financiere',
    'directeur financier', 'directrice financiere', 'cfo', 'chief financial officer',
    'administrative and financial director', 'director of administration and finance',
    'finance director', 'financial director', 'head of finance', 'vp finance',
    'credit manager', 'responsable credit clients', 'responsable credit client',
    'responsable credit', 'responsable recouvrement', 'head of credit', 'credit & collection manager'
  ];

  const tier35 = [
    'responsable comptabilite clients', 'responsable comptabilite client',
    'responsable comptable', 'chef comptable', 'cheffe comptable',
    'responsable administratif', 'directeur comptable', 'directrice comptable',
    'director of accounting', 'head of accounting', 'accounting manager', 'chief accountant',
    'responsable de gestion financiere'
  ];

  const tier20 = [
    'comptable clients', 'comptable client', 'gestionnaire recouvrement',
    'adjoint au daf', 'adjointe au daf', 'adjoint daf', 'deputy cfo',
    'controleur de gestion', 'controleuse de gestion', 'financial controller',
    'management controller', 'head of management control', 'director of management control', 'controller',
    'tresorier', 'tresoriere', 'treasury manager', 'director of treasury', 'charge de recouvrement', 'credit analyst'
  ];

  if (tier50.some(k => jobNorm.includes(k))) {
    scorePoste = 50;
    posteLabel = 'Cible Principale (DAF / CFO / Credit Manager)';
  } else if (tier35.some(k => jobNorm.includes(k))) {
    scorePoste = 35;
    posteLabel = 'Management Comptable / Trésorerie';
  } else if (tier20.some(k => jobNorm.includes(k))) {
    scorePoste = 20;
    posteLabel = 'Opérationnel Finance / Contrôle de gestion';
  } else if (hasFinanceKeyword) {
    scorePoste = 15;
    posteLabel = 'Autre fonction Finance';
  } else {
    // Contact hors cible
    return {
      score: 0,
      priority: 3,
      priorityLabel: 'Priorité 3',
      isEliminated: true,
      eliminationReason: 'Poste non ciblé',
      justification: 'Contact écarté : fonction financière trop éloignée du pilotage du BFR ou du crédit.',
      breakdown: { poste: 0, entreprise: 0, signaux: 0 },
      details: { posteLabel: contact.poste || '', locationLabel: contact.ville || '', sectorLabel: sectorNorm, signalsLabels: [] },
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-300',
      dotClass: 'bg-slate-400'
    };
  }

  // -------------------------------------------------------------
  // ÉTAPE 3 : SCORE DE L'ENTREPRISE (sur 30 points)
  // -------------------------------------------------------------
  let scoreEntreprise = 0;
  let locationLabel = '';
  let sectorLabel = '';

  // 3.1 Localisation géographique
  const targetDepts = config.departments && config.departments.length > 0 ? config.departments : ['33'];
  const isInTargetDept = targetDepts.some(d => {
    const dStr = String(d).trim();
    if (dStr === '33' && (cityNorm.includes('33') || cityNorm.includes('bordeaux') || cityNorm.includes('merignac') || cityNorm.includes('pessac') || cityNorm.includes('libourne') || cityNorm.includes('gironde'))) {
      return true;
    }
    return cityNorm.includes(dStr);
  });

  const isInNouvelleAquitaine = NOUVELLE_AQUITAINE_DEPTS.some(d => cityNorm.includes(d)) ||
    NOUVELLE_AQUITAINE_CITIES.some(c => cityNorm.includes(c)) ||
    cityNorm.includes('aquitaine');

  if (isInTargetDept) {
    scoreEntreprise += 17;
    locationLabel = `Département cible (${targetDepts.join(', ')})`;
  } else if (isInNouvelleAquitaine) {
    scoreEntreprise += 12;
    locationLabel = 'Région Nouvelle-Aquitaine';
  } else {
    scoreEntreprise += 4;
    locationLabel = 'Autre région France';
  }

  // 3.2 Effectif conforme
  scoreEntreprise += 7;

  // 3.3 Secteur d'activité
  const targetSectorKeywords = [
    'commerce de gros', 'negoce', 'wholesale', 'industrie', 'manufacturing',
    'agroalimentaire', 'food', 'agri', 'distribution', 'btp', 'construction', 'transport', 'logist'
  ];
  const isTargetSector = targetSectorKeywords.some(sk => sectorNorm.includes(sk)) ||
    config.sectors.some(s => sectorNorm.includes(normalizeText(s)));

  if (isTargetSector) {
    scoreEntreprise += 7;
    sectorLabel = 'Secteur prioritaire (Négoce/Industrie/Agro)';
  } else {
    scoreEntreprise += 1;
    sectorLabel = 'Autre secteur d\'activité';
  }

  // Plafond étape 3 à 30 points
  scoreEntreprise = Math.min(scoreEntreprise, 30);

  // -------------------------------------------------------------
  // ÉTAPE 4 : SCORE DES SIGNAUX (sur 20 points)
  // -------------------------------------------------------------
  let scoreSignaux = 0;
  const signalsLabels: string[] = [];

  // 4.1 Offre d'emploi ouverte en Finance / Crédit (+10 pts)
  if (hasJobIntent || (contact.signal_priorite && contact.signal_priorite.toLowerCase().includes('ouvert'))) {
    scoreSignaux += 10;
    signalsLabels.push('Recrutement Finance ouvert (+10)');
  }

  // 4.2 Contact en poste depuis moins de 12 mois (+5 pts)
  if (tenure !== undefined && tenure !== null && tenure <= 12) {
    scoreSignaux += 5;
    signalsLabels.push(`Prise de poste < 12 mois (${tenure} m.) (+5)`);
  } else if (contact.signal_priorite && (contact.signal_priorite.toLowerCase().includes('récent') || contact.signal_priorite.toLowerCase().includes('< 6'))) {
    scoreSignaux += 5;
    signalsLabels.push('Prise de poste récente (+5)');
  }

  // 4.3 Actualité / Compte cible prioritaire (+5 pts)
  if (contact.statut_compte === 'nouveau' || (contact.signal_priorite && contact.signal_priorite.toLowerCase().includes('croissance'))) {
    scoreSignaux += 5;
    signalsLabels.push('Compte cible prioritaire (+5)');
  }

  // Plafond étape 4 à 20 points
  scoreSignaux = Math.min(scoreSignaux, 20);

  // -------------------------------------------------------------
  // ÉTAPE 5 : CLASSEMENT FINAL
  // -------------------------------------------------------------
  const totalScore = Math.min(scorePoste + scoreEntreprise + scoreSignaux, 100);

  let priority: 1 | 2 | 3;
  let priorityLabel: 'Priorité 1' | 'Priorité 2' | 'Priorité 3';
  let badgeClass: string;
  let dotClass: string;

  if (totalScore >= 70) {
    priority = 1;
    priorityLabel = 'Priorité 1';
    badgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-300';
    dotClass = 'bg-emerald-500';
  } else if (totalScore >= 40) {
    priority = 2;
    priorityLabel = 'Priorité 2';
    badgeClass = 'bg-amber-50 text-amber-800 border-amber-300';
    dotClass = 'bg-amber-500';
  } else {
    priority = 3;
    priorityLabel = 'Priorité 3';
    badgeClass = 'bg-slate-100 text-slate-700 border-slate-300';
    dotClass = 'bg-slate-400';
  }

  // Génération de la phrase de justification synthétique
  const parts: string[] = [];
  parts.push(`${contact.poste || 'Poste'} (${scorePoste} pts)`);
  parts.push(`${locationLabel} (+${scoreEntreprise >= 24 ? '17' : scoreEntreprise >= 19 ? '12' : '4'})`);
  if (isTargetSector) parts.push('secteur prioritaire (+7)');
  if (signalsLabels.length > 0) {
    parts.push(signalsLabels.join(', '));
  }

  const actionText = priority === 1
    ? 'À contacter en premier'
    : priority === 2
    ? 'Séquence standard'
    : 'À surveiller';

  const justification = `${parts.join(' · ')} -> Score ${totalScore}/100 (${actionText}).`;

  return {
    score: totalScore,
    priority,
    priorityLabel,
    isEliminated: false,
    justification,
    breakdown: {
      poste: scorePoste,
      entreprise: scoreEntreprise,
      signaux: scoreSignaux
    },
    details: {
      posteLabel,
      locationLabel,
      sectorLabel,
      signalsLabels
    },
    badgeClass,
    dotClass
  };
}
