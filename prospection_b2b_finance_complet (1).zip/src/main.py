#!/usr/bin/env python3
"""Point d'entrée principal de l'agent de prospection DAF Gironde."""
import argparse
import sys
import os

# Ajouter le répertoire parent au PYTHONPATH
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.orchestrator import Orchestrator

def main():
    parser = argparse.ArgumentParser(
        description="Agent de prospection DAF/Finance Gironde (LLM open source Gemma)"
    )
    parser.add_argument(
        "--mode",
        choices=["A", "B"],
        required=True,
        help="Mode A (Recherche autonome hebdomadaire) ou Mode B (Fichier de comptes fourni)"
    )
    parser.add_argument(
        "--accounts",
        help="Chemin vers le fichier CSV des comptes à traiter (obligatoire en Mode B)"
    )
    parser.add_argument(
        "--known",
        help="Chemin vers le fichier CSV des comptes déjà connus (obligatoire en Mode B)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Mode simulation sans consommation de crédits Lusha réels"
    )
    parser.add_argument(
        "--auto-approve",
        action="store_true",
        help="Valider automatiquement l'étape de confirmation humaine (pour tâches cron ou tests)"
    )

    args = parser.parse_args()

    print("=" * 60)
    print("🚀 AGENT DE PROSPECTION DAF / FINANCE GIRONDE (33)")
    print(f"Mode : {args.mode} | Simulation dry-run : {args.dry_run}")
    print("=" * 60)

    orch = Orchestrator(dry_run=args.dry_run, auto_approve=args.auto_approve)

    if args.mode == "A":
        res = orch.run_mode_a()
    else:
        if not args.accounts or not args.known:
            print("❌ Erreur : En Mode B, les options --accounts et --known sont obligatoires.")
            sys.exit(1)
        res = orch.run_mode_b(args.accounts, args.known)

    print("\n" + "=" * 60)
    print("🏁 RÉSULTAT DU RUN :")
    print(f"Statut : {res.get('status')}")
    print(f"Contacts révélés : {res.get('revealed_count', 0)}")
    if res.get("csv_path"):
        print(f"Fichier exporté : {res.get('csv_path')}")
    print(f"Résumé : {res.get('resume') or res.get('message')}")
    print("=" * 60)

if __name__ == "__main__":
    main()
