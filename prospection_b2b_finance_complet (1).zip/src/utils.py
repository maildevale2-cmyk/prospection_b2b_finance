"""Utility helpers for SIREN cleaning, JSON parsing and RGPD safe logging."""
import re
import json
from typing import Optional, Dict, Any

def clean_siren(raw_siren: Any) -> Optional[str]:
    """Clean and validate a 9-digit SIREN number."""
    if raw_siren is None:
        return None
    val = str(raw_siren).strip()
    digits = re.sub(r"\D", "", val)
    if len(digits) == 9:
        return digits
    return None

def is_valid_siren(siren: str) -> bool:
    """Check if string is exactly 9 numeric digits."""
    return bool(siren and len(siren) == 9 and siren.isdigit())

def parse_llm_json(raw_text: str) -> Dict[str, Any]:
    """Safely extract and parse JSON from LLM response text, stripping markdown blocks."""
    if not raw_text:
        return {}
    cleaned = raw_text.strip()
    # Strip markdown code blocks
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    cleaned = cleaned.strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Fallback regex to find first JSON object {...} or array [...]
        match = re.search(r"(\{.*\}|\[.*\])", cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except Exception:
                pass
        raise ValueError(f"Impossible de parser la réponse JSON du LLM: {raw_text[:120]}")

def mask_personal_data(text: str) -> str:
    """Mask email addresses and phone numbers for safe logging."""
    if not text:
        return ""
    # Mask emails
    text = re.sub(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", "[EMAIL_MASQUÉ]", text)
    # Mask french phone numbers
    text = re.sub(r"(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}", "[TEL_MASQUÉ]", text)
    return text
