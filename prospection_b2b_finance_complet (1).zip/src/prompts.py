"""Prompts loader and registry for Gemma 3."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
PROMPTS_DIR = BASE_DIR / "prompts"

def load_prompt(filename: str, default_text: str = "") -> str:
    path = PROMPTS_DIR / filename
    if path.exists():
        try:
            return path.read_text(encoding="utf-8").strip()
        except Exception:
            pass
    return default_text.strip()

SYSTEM_MAIN_PROMPT = load_prompt(
    "system_main.txt",
    """Tu es le moteur de raisonnement d'un agent de prospection B2B.
Tu ne réalises AUCUNE action directement. Tu appelles uniquement les outils exposés.
Si un outil est absent, tu t'arrêtes et tu signales l'erreur.
Tu n'inventes JAMAIS de coordonnées, d'email, de téléphone ou de nom.
Tu réponds TOUJOURS en JSON valide, sans texte autour."""
)

PRIORITIZE_PROMPT = load_prompt(
    "prioritize.txt",
    """Tu reçois une liste de contacts au format JSON.
Pour chaque contact, attribue une priorité :
- priorité 1 si changement de poste < 6 mois
- priorité 2 si poste Finance ouvert chez l'entreprise
- priorité 3 sinon
Trie par priorité croissante, puis par ancienneté de poste décroissante.
Réponds uniquement en JSON :
{"prioritized": [{"contact_id": "...", "priority": 1, "reason": "..."}]}"""
)

MESSAGE_PROMPT = load_prompt(
    "message.txt",
    """Tu rédiges un message d'approche B2B personnalisé.
Contraintes :
- Ton professionnel, direct, concis, sobre.
- Aucun superlatif, aucune formule creuse.
- Longueur : 80 à 120 mots.
- Commence par "Bonjour [Prénom],".
- Intègre : poste exact, entreprise, secteur, signal de priorisation s'il existe.
- Termine par une question ouverte simple.
- Ne mentionne jamais Lusha, LinkedIn ou un outil d'automatisation.
Réponds uniquement en JSON :
{"message": "...", "subject": "..."}"""
)

SIREN_CHECK_PROMPT = load_prompt(
    "siren_check.txt",
    """Tu reçois deux listes de comptes (liste A = à traiter, liste B = connus).
Le rapprochement a déjà été fait par le code Python par SIREN exact.
Tu ne fais que vérifier la cohérence et signaler les anomalies.
Réponds uniquement en JSON :
{"anomalies": [{"type": "...", "siren": "...", "detail": "..."}]}"""
)
