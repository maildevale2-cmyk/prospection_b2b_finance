"""Orchestrator engine executing Mode A and Mode B workflows per sections 5.1, 5.2 & 9.3."""
import os
from datetime import datetime
from typing import List, Dict, Any, Optional
from pathlib import Path

from src.llm_client import LLMClient
from src.tools.lusha import LushaClient
from src.tools.state import StateManager
from src.tools.files import read_csv_file, match_siren_lists
from src.tools.hitl import ask_user_confirmation

ICP_FILTERS = {
    "jobTitles": [
        "Directeur Administratif et Financier",
        "DAF",
        "Chief Financial Officer",
        "CFO",
        "Credit Manager",
        "Responsable Recouvrement",
        "Responsable Comptable"
    ],
    "companySize": {"min": 100, "max": 1000},
    "sectors": ["Commerce de gros", "Industrie", "Manufacturing"],
    "location": {
        "department": "33",
        "country": "FR",
        "cities": [
            "Bordeaux", "Mérignac", "Pessac", "Libourne", "Bègles",
            "Talence", "Gradignan", "Arcachon", "Blanquefort", "Langon"
        ]
    }
}

class Orchestrator:
    MAX_REVEALS_LIMIT = 20

    def __init__(self, dry_run: bool = False, auto_approve: bool = False, db_path: str = "data/prospection.db"):
        self.dry_run = dry_run
        self.auto_approve = auto_approve
        self.state = StateManager(db_path=db_path)
        self.lusha = LushaClient(dry_run=dry_run)
        self.llm = LLMClient(dry_run=dry_run)

    def run_mode_a(self) -> Dict[str, Any]:
        """Mode A — Recherche autonome selon l'ICP Gironde."""
        date_debut = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.state.log_event("INFO", "Démarrage du Mode A (Recherche autonome ICP Gironde)")

        # 1. Chargement état & dédoublonnage
        existing_lusha_ids = self.state.get_existing_lusha_ids()
        opted_out_emails = self.state.get_opted_out_emails()
        self.state.log_event("DEBUG", f"{len(existing_lusha_ids)} contacts déjà enregistrés dans la base locale.")

        # 2. Recherche Lusha avec filtres ICP
        candidates = self.lusha.contact_search(ICP_FILTERS)
        nb_trouves_total = len(candidates)
        self.state.log_event("INFO", f"{nb_trouves_total} contacts identifiés via les filtres ICP Gironde.")

        # 3. Filtrage dédoublonnage
        filtered_candidates = [c for c in candidates if c.get("id") not in existing_lusha_ids]
        nb_nouveaux = len(filtered_candidates)
        self.state.log_event("INFO", f"{nb_nouveaux} nouveaux contacts éligibles après dédoublonnage.")

        if not filtered_candidates:
            msg = "Aucun nouveau prospect identifié pour ce run (tous déjà présents en base)."
            self.state.log_event("INFO", msg)
            date_fin = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.state.log_run_summary(
                mode="A",
                date_debut=date_debut,
                date_fin=date_fin,
                nb_prospects_trouves=nb_trouves_total,
                nb_prospects_reveles=0,
                nb_credits_lusha=0,
                resume=msg
            )
            return {"status": "success", "revealed_count": 0, "message": msg}

        # 4. Priorisation via Gemma 3
        self.state.log_event("INFO", "Priorisation intelligente des prospects par Gemma 3...")
        prioritized = self.llm.prioritize(filtered_candidates)

        # 5. Sélection avec plafond strict de 20
        selected = prioritized[:self.MAX_REVEALS_LIMIT]

        # 6. Demande de confirmation humaine explicite (HITL)
        question = f"Révéler les coordonnées de {len(selected)} décideurs Finance en Gironde (consommation : {len(selected)} crédits Lusha) ?"
        approved = ask_user_confirmation(question, selected, auto_approve=self.auto_approve)

        if not approved:
            self.state.log_event("WARNING", "Révélation annulée par validation humaine.")
            date_fin = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.state.log_run_summary(
                mode="A",
                date_debut=date_debut,
                date_fin=date_fin,
                nb_prospects_trouves=nb_trouves_total,
                nb_prospects_reveles=0,
                nb_credits_lusha=0,
                resume="Annulé par confirmation humaine"
            )
            return {"status": "cancelled", "revealed_count": 0, "message": "Annulation par l'opérateur"}

        # 7. Révélation payante des coordonnées (uniquement les validés, max 20)
        self.state.log_event("INFO", f"Révélation Lusha en cours pour {len(selected)} contacts...")
        revealed_details = []
        for c in selected:
            details = self.lusha.reveal_contact(c["id"])
            details["signal_priorite"] = c.get("priority_reason") or c.get("signal_priorite")
            details["statut_compte"] = "nouveau"
            
            # Vérification anti-liste noire RGPD
            if details.get("email") and details["email"].lower().strip() in opted_out_emails:
                self.state.log_event("WARNING", f"Prospect ignoré (email sur liste noire d'opposition).")
                continue

            revealed_details.append(details)

        # 8. Rédaction personnalisée des messages d'approche via Gemma 3
        self.state.log_event("INFO", "Génération des messages d'approche personnalisés par Gemma 3...")
        for d in revealed_details:
            d["message_propose"] = self.llm.draft_message(d)
            self.state.upsert_contact(d)

        # 9. Export CSV avec UTF-8 BOM
        csv_path = self.state.export_csv()
        date_fin = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        resume = f"Succès Mode A : {len(revealed_details)} contacts révélés et enrichis dans {csv_path}."
        self.state.log_event("INFO", resume)

        # 10. Enregistrement du résumé de run
        self.state.log_run_summary(
            mode="A",
            date_debut=date_debut,
            date_fin=date_fin,
            nb_prospects_trouves=nb_trouves_total,
            nb_prospects_reveles=len(revealed_details),
            nb_credits_lusha=len(revealed_details),
            resume=resume
        )

        return {
            "status": "success",
            "revealed_count": len(revealed_details),
            "csv_path": csv_path,
            "contacts": revealed_details,
            "resume": resume
        }

    def run_mode_b(self, accounts_csv: str, known_csv: str) -> Dict[str, Any]:
        """Mode B — Traitement à partir d'une liste de comptes fournie."""
        date_debut = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.state.log_event("INFO", f"Démarrage du Mode B avec {accounts_csv} et {known_csv}")

        # 1. Chargement des CSV
        try:
            list_a = read_csv_file(accounts_csv)
            list_b = read_csv_file(known_csv)
        except Exception as e:
            err_msg = f"Erreur de lecture des fichiers CSV : {e}"
            self.state.log_event("ERROR", err_msg)
            return {"status": "error", "message": err_msg}

        # 2. Rapprochement par SIREN déterministe
        matching = match_siren_lists(list_a, list_b)
        comptes_connus = matching["comptes_connus"]
        comptes_nouveaux = matching["comptes_nouveaux"]
        anomalies = matching["anomalies"]

        self.state.log_event("INFO", f"Rapprochement SIREN : {len(comptes_connus)} connus, {len(comptes_nouveaux)} nouveaux.")
        for ano in anomalies:
            self.state.log_event("WARNING", f"Anomalie SIREN ({ano['type']}) : {ano['detail']}")

        # 3. Recherche ciblée des décideurs Finance pour les comptes cibles
        existing_lusha_ids = self.state.get_existing_lusha_ids()
        all_accounts = comptes_connus + comptes_nouveaux
        self.state.log_event("INFO", f"Recherche de décideurs Finance pour {len(all_accounts)} comptes dans Lusha...")
        
        raw_candidates = self.lusha.contact_search_for_accounts(all_accounts)
        all_candidates = [c for c in raw_candidates if c.get("id") not in existing_lusha_ids]

        # Comptes ayant des décideurs identifiés
        matched_companies = set(c.get("entreprise", "").lower() for c in all_candidates)
        sans_decideurs_count = sum(1 for a in all_accounts if a.get("nom", "").lower() not in matched_companies)
        self.state.log_event("INFO", f"{len(all_candidates)} décideurs Finance trouvés pour les comptes cibles ({sans_decideurs_count} comptes sans décideur Lusha répertorié).")

        if not all_candidates:
            msg = "Aucun nouveau décideur finance trouvé pour les comptes fournis."
            self.state.log_event("INFO", msg)
            date_fin = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.state.log_run_summary(
                mode="B",
                date_debut=date_debut,
                date_fin=date_fin,
                nb_prospects_trouves=0,
                nb_prospects_reveles=0,
                nb_credits_lusha=0,
                nb_comptes_connus=len(comptes_connus),
                nb_comptes_nouveaux=len(comptes_nouveaux),
                nb_sans_decideur=sans_decideurs_count,
                resume=msg
            )
            return {"status": "success", "revealed_count": 0, "message": msg}

        # 4. Priorisation via Gemma 3
        self.state.log_event("INFO", f"Priorisation de {len(all_candidates)} décideurs Finance par Gemma 3...")
        prioritized = self.llm.prioritize(all_candidates)
        selected = prioritized[:self.MAX_REVEALS_LIMIT]

        # 5. Validation humaine HITL
        question = f"Révéler les coordonnées de {len(selected)} décideurs Finance des comptes fournis ?"
        approved = ask_user_confirmation(question, selected, auto_approve=self.auto_approve)

        if not approved:
            self.state.log_event("WARNING", "Révélation Mode B annulée par l'utilisateur.")
            return {"status": "cancelled", "revealed_count": 0, "message": "Annulation par l'opérateur"}

        # 6. Révélation et rédaction
        revealed_details = []
        for c in selected:
            details = self.lusha.reveal_contact(c["id"])
            details["signal_priorite"] = c.get("priority_reason") or c.get("signal_priorite")
            details["statut_compte"] = c.get("statut_compte", "nouveau")
            details["siren"] = c.get("siren") or details.get("siren")
            revealed_details.append(details)

        for d in revealed_details:
            d["message_propose"] = self.llm.draft_message(d)
            self.state.upsert_contact(d)

        csv_path = self.state.export_csv()
        date_fin = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        resume = f"Succès Mode B : {len(revealed_details)} contacts révélés pour {len(all_accounts)} comptes traités."

        self.state.log_run_summary(
            mode="B",
            date_debut=date_debut,
            date_fin=date_fin,
            nb_prospects_trouves=len(all_candidates),
            nb_prospects_reveles=len(revealed_details),
            nb_credits_lusha=len(revealed_details),
            nb_comptes_connus=len(comptes_connus),
            nb_comptes_nouveaux=len(comptes_nouveaux),
            nb_sans_decideur=sans_decideurs_count,
            resume=resume
        )

        return {
            "status": "success",
            "revealed_count": len(revealed_details),
            "csv_path": csv_path,
            "contacts": revealed_details,
            "resume": resume,
            "anomalies": anomalies
        }
