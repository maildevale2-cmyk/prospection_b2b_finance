import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { CockpitTab } from './components/CockpitTab';
import { CrmTab } from './components/CrmTab';
import { ModeBTab } from './components/ModeBTab';
import { TerminalTab } from './components/TerminalTab';
import { DeliverablesTab } from './components/DeliverablesTab';
import { RgpdConfigTab } from './components/RgpdConfigTab';
import { HitlModal } from './components/HitlModal';
import { MessageModal } from './components/MessageModal';
import { AppStats, Contact, RunHistoryItem, Candidate } from './types';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('cockpit');
  const [stats, setStats] = useState<AppStats | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [runs, setRuns] = useState<RunHistoryItem[]>([]);
  const [selectedMessageContact, setSelectedMessageContact] = useState<Contact | null>(null);

  // HITL Workflow State
  const [isHitlOpen, setIsHitlOpen] = useState(false);
  const [hitlCandidates, setHitlCandidates] = useState<Candidate[]>([]);
  const [hitlMode, setHitlMode] = useState<'A' | 'B'>('A');
  const [isStartingRun, setIsStartingRun] = useState(false);
  const [isProcessingHitl, setIsProcessingHitl] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Notification Banner
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [config, setConfig] = useState<any>(null);

  const fetchConfig = async () => {
    try {
      const res = await fetch('/api/config');
      const data = await res.json();
      setConfig(data);
    } catch (e) {
      console.error('Error fetching config:', e);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      setStats(data);
    } catch (e) {
      console.error('Error fetching stats:', e);
    }
  };

  const fetchContacts = async () => {
    try {
      const res = await fetch('/api/contacts');
      const data = await res.json();
      if (Array.isArray(data)) {
        setContacts(data);
      }
    } catch (e) {
      console.error('Error fetching contacts:', e);
    }
  };

  const fetchRuns = async () => {
    try {
      const res = await fetch('/api/runs');
      const data = await res.json();
      if (Array.isArray(data)) {
        setRuns(data);
      }
    } catch (e) {
      console.error('Error fetching runs:', e);
    }
  };

  useEffect(() => {
    fetchConfig();
    fetchStats();
    fetchContacts();
    fetchRuns();
  }, []);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  // STEP 1 & 2 OF MODE A WORKFLOW
  const handleStartModeA = async () => {
    setIsStartingRun(true);
    setHitlMode('A');
    try {
      // Step 1: Lusha search & deduplication
      const searchRes = await fetch('/api/runs/step/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const searchData = await searchRes.json();
      const candidates = searchData.candidates || [];

      if (candidates.length === 0) {
        showNotification('success', 'Tous les prospects identifiés sont déjà présents en base de données (dédoublonnage 100%).');
        setIsStartingRun(false);
        return;
      }

      // Step 2: Prioritization with Gemma 3
      const prioRes = await fetch('/api/runs/step/prioritize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ candidates })
      });
      const prioData = await prioRes.json();
      const prioritized = prioData.prioritized || candidates;

      // Step 3: Open HITL confirmation modal
      setHitlCandidates(prioritized);
      setIsHitlOpen(true);
    } catch (err: any) {
      showNotification('error', `Erreur lors de la recherche : ${err.message}`);
    } finally {
      setIsStartingRun(false);
    }
  };

  // MODE B WORKFLOW
  const handleStartModeBRun = async (accountsCsv: string, knownCsv: string) => {
    setIsStartingRun(true);
    setHitlMode('B');
    try {
      // 1. Recherche ciblée des décideurs Finance pour les entreprises du fichier CSV
      const searchRes = await fetch('/api/runs/step/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'B',
          accounts_csv: accountsCsv,
          known_csv: knownCsv
        })
      });
      const searchData = await searchRes.json();
      if (searchData.error) {
        throw new Error(searchData.error);
      }

      const candidates = searchData.candidates || [];

      if (candidates.length === 0) {
        showNotification('success', 'Aucun nouveau décideur finance non encore en base trouvé pour les comptes du fichier.');
        setIsStartingRun(false);
        return;
      }

      // 2. Prioritize via Gemma 3
      const prioRes = await fetch('/api/runs/step/prioritize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ candidates })
      });
      const prioData = await prioRes.json();

      setHitlCandidates(prioData.prioritized || candidates);
      setIsHitlOpen(true);
    } catch (err: any) {
      showNotification('error', `Erreur Mode B : ${err.message}`);
    } finally {
      setIsStartingRun(false);
    }
  };

  // STEP 4: REVEAL & DRAFT AFTER HITL CONFIRMATION
  const handleConfirmHitl = async (selected: Candidate[]) => {
    setIsProcessingHitl(true);
    try {
      const res = await fetch('/api/runs/step/reveal-and-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          selected_candidates: selected,
          mode: hitlMode
        })
      });
      const data = await res.json();
      if (data.error) {
        showNotification('error', data.error);
      } else {
        showNotification('success', `Succès : ${data.revealed_count} coordonnées de décideurs Finance révélées et enrichies !`);
        setIsHitlOpen(false);
        fetchStats();
        fetchContacts();
        fetchRuns();
        setActiveTab('crm');
      }
    } catch (err: any) {
      showNotification('error', `Erreur d'enrichissement : ${err.message}`);
    } finally {
      setIsProcessingHitl(false);
    }
  };

  const handleUpdateStatus = async (id: number, status: Contact['statut']) => {
    try {
      await fetch(`/api/contacts/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      setContacts(prev => prev.map(c => c.id === id ? { ...c, statut: status } : c));
      if (selectedMessageContact?.id === id) {
        setSelectedMessageContact(prev => prev ? { ...prev, statut: status } : null);
      }
      fetchStats();
    } catch (err: any) {
      showNotification('error', `Erreur mise à jour statut : ${err.message}`);
    }
  };

  const handleOptOut = async (contact: Contact) => {
    if (!confirm(`Confirmer l'inscription de ${contact.prenom} ${contact.nom} (${contact.email}) sur liste noire d'opposition RGPD ? Le contact sera effacé de votre base active.`)) {
      return;
    }
    try {
      const res = await fetch(`/api/contacts/${contact.id}/optout`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showNotification('success', `Droit d'opposition appliqué : ${contact.email} a été effacé et inscrit sur liste noire.`);
        setContacts(prev => prev.filter(c => c.id !== contact.id));
        fetchStats();
      }
    } catch (err: any) {
      showNotification('error', `Erreur opt-out : ${err.message}`);
    }
  };

  const handleDeleteContact = async (id: number) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer définitivement ce contact de la base locale ?')) {
      return;
    }
    try {
      const res = await fetch(`/api/contacts/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        showNotification('success', 'Contact supprimé de la base locale.');
        setContacts(prev => prev.filter(c => c.id !== id));
        fetchStats();
      }
    } catch (err: any) {
      showNotification('error', `Erreur suppression : ${err.message}`);
    }
  };

  const handleClearTestContacts = async () => {
    if (!confirm('Supprimer les contacts de test résiduels pour ne garder que vos vrais prospects du fichier CSV ?')) {
      return;
    }
    try {
      const res = await fetch('/api/contacts/clear-test', { method: 'POST' });
      const data = await res.json();
      showNotification('success', `Nettoyage terminé : ${data.deleted} contact(s) d'essai supprimé(s).`);
      fetchContacts();
      fetchStats();
    } catch (err: any) {
      showNotification('error', `Erreur nettoyage : ${err.message}`);
    }
  };

  const handleClearAllContacts = async () => {
    if (!confirm('ATTENTION : Voulez-vous vraiment vider entièrement tous les contacts enregistrés dans la base locale ?')) {
      return;
    }
    try {
      const res = await fetch('/api/contacts/clear-all', { method: 'POST' });
      const data = await res.json();
      showNotification('success', 'Base locale réinitialisée à 0.');
      fetchContacts();
      fetchStats();
    } catch (err: any) {
      showNotification('error', `Erreur réinitialisation : ${err.message}`);
    }
  };

  const handleExportCsv = async () => {
    setIsExporting(true);
    try {
      const res = await fetch('/api/contacts/export');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `prospects_gironde_excel_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      showNotification('success', 'Fichier CSV (UTF-8 avec BOM) téléchargé avec succès.');
    } catch (err: any) {
      showNotification('error', `Erreur export CSV : ${err.message}`);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans flex flex-col">
      {/* App Header */}
      <Header
        stats={stats}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onStartModeA={handleStartModeA}
        onExportCsv={handleExportCsv}
        isExporting={isExporting}
        isStartingRun={isStartingRun}
        config={config}
      />

      {/* Global Notification */}
      {notification && (
        <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 w-full`}>
          <div className={`p-3 rounded-md text-xs font-medium flex items-center justify-between shadow-xs ${
            notification.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
              : 'bg-rose-50 border border-rose-200 text-rose-900'
          }`}>
            <div className="flex items-center gap-2">
              {notification.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{notification.message}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Tab Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'cockpit' && (
          <CockpitTab
            stats={stats}
            runs={runs}
            onStartModeA={handleStartModeA}
            onSelectCandidateDetails={(c) => setSelectedMessageContact(c)}
            isStartingRun={isStartingRun}
            config={config}
          />
        )}

        {activeTab === 'crm' && (
          <CrmTab
            contacts={contacts}
            onOpenMessage={(c) => setSelectedMessageContact(c)}
            onUpdateStatus={handleUpdateStatus}
            onOptOut={handleOptOut}
            onDeleteContact={handleDeleteContact}
            onClearTestContacts={handleClearTestContacts}
            onClearAllContacts={handleClearAllContacts}
            onExportCsv={handleExportCsv}
            isExporting={isExporting}
            config={config}
          />
        )}

        {activeTab === 'mode_b' && (
          <ModeBTab
            onStartModeBRun={handleStartModeBRun}
            isStartingRun={isStartingRun}
          />
        )}

        {activeTab === 'terminal' && (
          <TerminalTab />
        )}

        {activeTab === 'deliverables' && (
          <DeliverablesTab />
        )}

        {activeTab === 'rgpd_config' && (
          <RgpdConfigTab
            stats={stats}
            onRefreshStats={() => {
              fetchStats();
              fetchConfig();
            }}
          />
        )}
      </main>

      {/* Human-In-The-Loop Confirmation Modal */}
      <HitlModal
        isOpen={isHitlOpen}
        candidates={hitlCandidates}
        onConfirm={handleConfirmHitl}
        onCancel={() => setIsHitlOpen(false)}
        isProcessing={isProcessingHitl}
        mode={hitlMode}
        maxReveals={config?.data?.limits?.max_reveals_per_run || 20}
        config={config}
      />

      {/* Personalized Message Modal */}
      <MessageModal
        contact={selectedMessageContact}
        onClose={() => setSelectedMessageContact(null)}
        onUpdateStatus={handleUpdateStatus}
      />

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            Agent de Prospection DAF Gironde · Conformité RGPD & Intérêt Légitime B2B
          </div>
          <div className="flex items-center gap-3">
            <span>Raisonnement Gemma 3</span>
            <span aria-hidden="true">·</span>
            <span>API Lusha</span>
            <span aria-hidden="true">·</span>
            <span>SQLite Local</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
