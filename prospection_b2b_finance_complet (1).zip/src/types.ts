export interface Contact {
  id: number;
  lusha_contact_id: string;
  nom: string;
  prenom: string;
  poste: string;
  entreprise: string;
  siren: string;
  ville: string;
  email: string;
  telephone: string;
  linkedin: string;
  signal_priorite: string;
  message_propose: string;
  statut: 'à contacter' | 'contacté' | 'relancé' | 'répondu' | 'refus';
  statut_compte: 'connu' | 'nouveau';
  date_ajout: string;
  date_derniere_action: string;
  score?: number;
  justification?: string;
}

export interface RunHistoryItem {
  id: number;
  mode: 'A' | 'B';
  date_debut: string;
  date_fin: string;
  nb_prospects_trouves: number;
  nb_prospects_reveles: number;
  nb_credits_lusha: number;
  nb_comptes_connus?: number;
  nb_comptes_nouveaux?: number;
  nb_sans_decideur?: number;
  resume: string;
}

export interface AppStats {
  total_contacts: number;
  status_counts: Record<string, number>;
  priority_counts: Record<string, number>;
  total_runs: number;
  last_run: RunHistoryItem | null;
  optouts_count: number;
  max_reveals_limit: number;
  target_region: string;
}

export interface Candidate {
  id: string;
  nom: string;
  prenom: string;
  poste: string;
  entreprise: string;
  siren?: string;
  ville?: string;
  mois_en_poste?: number;
  signal_priorite?: string;
  poste_finance_ouvert?: boolean;
  priority?: number;
  priority_reason?: string;
  statut_compte?: 'connu' | 'nouveau';
  score?: number;
  justification?: string;
  isEliminated?: boolean;
  eliminationReason?: string;
}

export interface DeliverableFile {
  path: string;
  category: string;
  desc: string;
  size: number;
  content: string;
}

export interface SIRENAnomaly {
  type: string;
  siren: string;
  detail: string;
}

export interface LogItem {
  id: number;
  timestamp: string;
  level: string;
  message: string;
}
