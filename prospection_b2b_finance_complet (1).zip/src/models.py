"""Data models for prospection agent."""
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict

try:
    from pydantic import BaseModel, Field
    HAS_PYDANTIC = True
except ImportError:
    HAS_PYDANTIC = False

if HAS_PYDANTIC:
    class ContactCandidate(BaseModel):
        id: str
        nom: str
        prenom: str
        poste: str
        entreprise: str
        siren: Optional[str] = None
        ville: Optional[str] = None
        signal_priorite: Optional[str] = None
        mois_en_poste: Optional[int] = None
        poste_finance_ouvert: bool = False

    class ContactDetails(BaseModel):
        id: str
        lusha_contact_id: str
        nom: str
        prenom: str
        poste: str
        entreprise: str
        siren: Optional[str] = ""
        ville: Optional[str] = ""
        email: Optional[str] = ""
        telephone: Optional[str] = ""
        linkedin: Optional[str] = ""
        signal_priorite: Optional[str] = ""
        message_propose: Optional[str] = ""
        statut: str = "à contacter"
        statut_compte: str = "nouveau"

    class PrioritizedItem(BaseModel):
        contact_id: str
        priority: int
        reason: str

    class MessageResponse(BaseModel):
        subject: str
        message: str

    class SIRENAnomaly(BaseModel):
        type: str
        siren: str
        detail: str

else:
    @dataclass
    class ContactCandidate:
        id: str
        nom: str
        prenom: str
        poste: str
        entreprise: str
        siren: Optional[str] = None
        ville: Optional[str] = None
        signal_priorite: Optional[str] = None
        mois_en_poste: Optional[int] = None
        poste_finance_ouvert: bool = False

        def model_dump(self):
            return asdict(self)

    @dataclass
    class ContactDetails:
        id: str
        lusha_contact_id: str
        nom: str
        prenom: str
        poste: str
        entreprise: str
        siren: Optional[str] = ""
        ville: Optional[str] = ""
        email: Optional[str] = ""
        telephone: Optional[str] = ""
        linkedin: Optional[str] = ""
        signal_priorite: Optional[str] = ""
        message_propose: Optional[str] = ""
        statut: str = "à contacter"
        statut_compte: str = "nouveau"

        def model_dump(self):
            return asdict(self)
