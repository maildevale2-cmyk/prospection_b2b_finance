"""Package agent_prospection_gironde."""
__version__ = "1.0.0"
