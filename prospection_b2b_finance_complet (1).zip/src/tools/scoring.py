"""Deterministic Scoring & Prioritization Engine (0-100) per 5-step rules.
Pure deterministic calculation without AI/LLM calls.
"""
import unicodedata
from typing import Dict, Any, Tuple, List

NOUVELLE_AQUITAINE_DEPTS = ["33", "40", "47", "64", "24", "17", "16", "19", "23", "87", "79", "86"]
NOUVELLE_AQUITAINE_CITIES = [
    "bordeaux", "merignac", "pessac", "libourne", "begles", "talence", "villenave", "gradignan",
    "angouleme", "cognac", "la rochelle", "rochefort", "saintes", "perigueux", "bergerac",
    "mont-de-marsan", "dax", "agen", "villeneuve-sur-lot", "marmande", "pau", "bayonne",
    "anglet", "biarritz", "limoges", "poitiers", "niort"
]

def strip_accents(text: str) -> str:
    if not text:
        return ""
    text = unicodedata.normalize('NFD', text)
    return ''.join(c for c in text if unicodedata.category(c) != 'Mn').lower().strip()

def compute_deterministic_score(contact: Dict[str, Any], config: Dict[str, Any]) -> Tuple[int, int, str]:
    """Computes (score: 0-100, priority: 1-3, justification: str) per the exact 5-step rules."""
    icp = config.get("icp", {})
    target_depts = [str(d).strip() for d in icp.get("departments", ["33"])]
    min_size = icp.get("company_size_min", 50)
    max_size = icp.get("company_size_max", 500)
    sectors = [strip_accents(s) for s in icp.get("sectors", [])]

    job = strip_accents(contact.get("poste") or "")
    city = strip_accents(contact.get("ville") or "")
    country = strip_accents(contact.get("pays") or contact.get("country") or "france")
    sector = strip_accents(contact.get("secteur") or contact.get("industry") or "")
    employees = contact.get("effectif") or contact.get("employees_count")
    tenure = contact.get("mois_en_poste")
    has_job_intent = contact.get("poste_finance_ouvert") or contact.get("hasCompanyIntent")
    raw_sig = strip_accents(contact.get("signal_priorite") or "")
    statut_compte = contact.get("statut_compte") or "nouveau"

    # -------------------------------------------------------------
    # ÉTAPE 1 : FILTRES ÉLIMINATOIRES (Score 0, Priorité 3)
    # -------------------------------------------------------------
    # 1.1 Pays hors France
    if country and "france" not in country and "fr" != country:
        return 0, 3, "Contact écarté : localisation en dehors du territoire français (Score 0/100, Priorité 3)."

    # 1.2 Effectif hors intervalle
    if employees is not None and employees > 0:
        if employees < min_size or employees > max_size:
            return 0, 3, f"Contact écarté : effectif entreprise ({employees} sal.) hors cible [{min_size}-{max_size}] (Score 0/100, Priorité 3)."

    # 1.3 Poste sans rapport avec finance/comptabilité/crédit/recouvrement
    forbidden_keywords = [
        "marketing", "achats", "purchasing", "buyer", "logistique", "logistics", "supply chain",
        "informatique", "developer", "software", "it manager", "commercial", "sales", "business developer",
        "communication", "ressources humaines", "human resources", "recruiter", "technicien", "juriste"
    ]
    is_forbidden = any(kw in job for kw in forbidden_keywords)
    has_finance = any(kw in job for kw in ["daf", "financ", "cfo", "comptab", "credit", "recouv", "tresor", "bfr"])

    if is_forbidden and not has_finance:
        return 0, 3, "Contact écarté : poste sans rapport avec la finance, la comptabilité ou le recouvrement (Score 0/100, Priorité 3)."

    # -------------------------------------------------------------
    # ÉTAPE 2 : SCORE DU POSTE (sur 50 points)
    # -------------------------------------------------------------
    tier50 = [
        "daf", "directeur administratif et financier", "directrice administrative et financiere",
        "directeur financier", "directrice financiere", "cfo", "chief financial officer",
        "administrative and financial director", "director of administration and finance",
        "finance director", "financial director", "head of finance", "vp finance",
        "credit manager", "responsable credit clients", "responsable credit client",
        "responsable credit", "responsable recouvrement", "head of credit", "credit & collection manager"
    ]
    tier35 = [
        "responsable comptabilite clients", "responsable comptabilite client",
        "responsable comptable", "chef comptable", "cheffe comptable",
        "responsable administratif", "directeur comptable", "directrice comptable",
        "director of accounting", "head of accounting", "accounting manager", "chief accountant",
        "responsable de gestion financiere"
    ]
    tier20 = [
        "comptable clients", "comptable client", "gestionnaire recouvrement",
        "adjoint au daf", "adjointe au daf", "adjoint daf", "deputy cfo",
        "controleur de gestion", "controleuse de gestion", "financial controller",
        "management controller", "head of management control", "director of management control", "controller",
        "tresorier", "tresoriere", "treasury manager", "director of treasury", "charge de recouvrement", "credit analyst"
    ]

    score_poste = 0
    poste_desc = contact.get("poste") or "Décideur Finance"

    if any(k in job for k in tier50):
        score_poste = 50
    elif any(k in job for k in tier35):
        score_poste = 35
    elif any(k in job for k in tier20):
        score_poste = 20
    elif has_finance:
        score_poste = 15
    else:
        return 0, 3, "Contact écarté : fonction financière trop éloignée du pilotage du BFR ou du crédit (Score 0/100, Priorité 3)."

    # -------------------------------------------------------------
    # ÉTAPE 3 : SCORE DE L'ENTREPRISE (sur 30 points)
    # -------------------------------------------------------------
    score_entreprise = 0
    loc_desc = "autre région"

    # Localisation
    is_in_target_dept = any(
        (d == "33" and any(k in city for k in ["33", "bordeaux", "merignac", "pessac", "libourne", "gironde"])) or (d in city)
        for d in target_depts
    )
    is_in_na = any(d in city for d in NOUVELLE_AQUITAINE_DEPTS) or any(c in city for c in NOUVELLE_AQUITAINE_CITIES)

    if is_in_target_dept:
        score_entreprise += 17
        loc_desc = f"siège en département cible ({', '.join(target_depts)})"
    elif is_in_na:
        score_entreprise += 12
        loc_desc = "siège en Nouvelle-Aquitaine"
    else:
        score_entreprise += 4
        loc_desc = "siège en France"

    # Effectif
    score_entreprise += 7

    # Secteur
    target_sector_kw = [
        "commerce de gros", "negoce", "wholesale", "industrie", "manufacturing",
        "agroalimentaire", "food", "agri", "distribution", "btp", "construction", "transport", "logist"
    ]
    is_target_sector = any(kw in sector for kw in target_sector_kw) or any(s in sector for s in sectors)
    if is_target_sector:
        score_entreprise += 7
    else:
        score_entreprise += 1

    score_entreprise = min(score_entreprise, 30)

    # -------------------------------------------------------------
    # ÉTAPE 4 : SCORE DES SIGNAUX (sur 20 points)
    # -------------------------------------------------------------
    score_signaux = 0
    signals_list = []

    if has_job_intent or "ouvert" in raw_sig:
        score_signaux += 10
        signals_list.append("offre d'emploi finance ouverte")

    if (tenure is not None and tenure <= 12) or "recent" in raw_sig or "< 6" in raw_sig:
        score_signaux += 5
        signals_list.append(f"en poste depuis < 12 mois ({tenure or '< 6'} m.)")

    if statut_compte == "nouveau" or "croissance" in raw_sig:
        score_signaux += 5
        signals_list.append("compte cible prioritaire")

    score_signaux = min(score_signaux, 20)

    # -------------------------------------------------------------
    # ÉTAPE 5 : CLASSEMENT FINAL
    # -------------------------------------------------------------
    total_score = min(score_poste + score_entreprise + score_signaux, 100)

    if total_score >= 70:
        priority = 1
        action = "À contacter en premier"
    elif total_score >= 40:
        priority = 2
        action = "Séquence standard"
    else:
        priority = 3
        action = "À surveiller uniquement"

    parts = [f"{poste_desc} ({score_poste} pts)", loc_desc]
    if is_target_sector:
        parts.append("secteur prioritaire (+7)")
    if signals_list:
        parts.extend(signals_list)

    justification = f"{' · '.join(parts)} -> Score {total_score}/100 ({action})."
    return total_score, priority, justification
