"""File and CSV utilities with deterministic SIREN matching per section 5.2 & 8.3."""
import csv
from pathlib import Path
from typing import List, Dict, Any, Tuple
from src.utils import clean_siren, is_valid_siren

def read_csv_file(filepath: str) -> List[Dict[str, str]]:
    """Read CSV file with fallback delimiters (';', ',') and encodings."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Fichier introuvable : {filepath}")

    content = None
    for enc in ["utf-8-sig", "utf-8", "latin-1", "cp1252"]:
        try:
            with open(path, "r", encoding=enc) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        raise ValueError(f"Impossible de décoder le fichier {filepath}")

    # Detect delimiter
    first_line = content.splitlines()[0] if content.splitlines() else ""
    delimiter = ";" if ";" in first_line else ","

    reader = csv.DictReader(content.splitlines(), delimiter=delimiter)
    rows = []
    for row in reader:
        # Normalize keys (strip whitespace and lowercase)
        normalized_row = {k.strip().lower() if k else "": (v.strip() if v else "") for k, v in row.items()}
        
        # Tolérance et synonymes automatiques de colonnes
        # Détection du SIREN : 'siren', 'siren_number', 'num_siren', 'n° siren', 'code_siren'
        if "siren" not in normalized_row:
            for candidate in ["siren_number", "num_siren", "n° siren", "code_siren", "siret"]:
                if candidate in normalized_row:
                    val = normalized_row[candidate]
                    # Si c'est un SIRET (14 chiffres), on extrait automatiquement les 9 premiers chiffres (le SIREN)
                    clean_val = val.replace(" ", "").replace(".", "")
                    if len(clean_val) == 14 and candidate == "siret":
                        normalized_row["siren"] = clean_val[:9]
                    else:
                        normalized_row["siren"] = val
                    break

        # Détection du Nom de société : 'nom', 'nom du compte', 'compte', 'societe', 'entreprise', 'company', 'raison_sociale', 'raison sociale', etc.
        if "nom" not in normalized_row or not normalized_row["nom"]:
            for candidate in [
                "nom du compte", "nom_du_compte", "nom compte", "compte", "compte_nom", "nom_societe",
                "societe", "société", "entreprise", "company", "raison_sociale", "raison sociale", 
                "nom_entreprise", "nom entreprise", "client", "customer", "account", "account_name"
            ]:
                if candidate in normalized_row and normalized_row[candidate]:
                    normalized_row["nom"] = normalized_row[candidate]
                    break

        # Si toujours pas trouvé, recherche heuristique par mot-clé
        if "nom" not in normalized_row or not normalized_row["nom"]:
            for k, v in normalized_row.items():
                if any(w in k for w in ["compte", "nom", "societ", "entrep", "client", "raison"]) and v:
                    normalized_row["nom"] = v
                    break

        # Ultime recours : première colonne non-siren / non-siret non vide
        if "nom" not in normalized_row or not normalized_row["nom"]:
            for k, v in normalized_row.items():
                if k not in ["siren", "siret", "num_siren", "siren_number", "id"] and v:
                    normalized_row["nom"] = v
                    break

        rows.append(normalized_row)
    return rows

def write_csv_file(filepath: str, rows: List[Dict[str, Any]], fieldnames: List[str] = None) -> bool:
    """Write rows to CSV with UTF-8 BOM and french ';' separator."""
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows and not fieldnames:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            pass
        return True

    keys = fieldnames or list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=keys, delimiter=";")
        writer.writeheader()
        for r in rows:
            clean_r = {k: r.get(k, "") for k in keys}
            writer.writerow(clean_r)
    return True

def match_siren_lists(
    list_a: List[Dict[str, Any]],
    list_b: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Jointure déterministe par SIREN.
    list_a: Comptes à traiter (Mode B)
    list_b: Comptes déjà connus
    Retourne {
        "comptes_connus": [...],
        "comptes_nouveaux": [...],
        "anomalies": [...]
    }
    """
    known_sirens = set()
    siren_to_known_name = {}
    anomalies = []

    # 1. Indexer la liste B (connus)
    for idx, item in enumerate(list_b):
        raw_siren = item.get("siren")
        nom = item.get("nom", "").strip()
        cleaned = clean_siren(raw_siren)

        if not cleaned or not is_valid_siren(cleaned):
            anomalies.append({
                "type": "SIREN_INVALIDE_CONNUS",
                "siren": str(raw_siren),
                "detail": f"SIREN invalide dans la liste des connus (ligne {idx+2}): '{raw_siren}'"
            })
            continue

        if cleaned in known_sirens:
            anomalies.append({
                "type": "DOUBLON_INTERNE_CONNUS",
                "siren": cleaned,
                "detail": f"SIREN en doublon dans la liste des connus : {cleaned}"
            })
        known_sirens.add(cleaned)
        siren_to_known_name[cleaned] = nom

    comptes_connus = []
    comptes_nouveaux = []
    seen_in_a = set()

    # 2. Classifier la liste A (à traiter)
    for idx, item in enumerate(list_a):
        raw_siren = item.get("siren")
        nom = item.get("nom", "").strip()
        cleaned = clean_siren(raw_siren)

        if not cleaned or not is_valid_siren(cleaned):
            anomalies.append({
                "type": "SIREN_INVALIDE_A_TRAITER",
                "siren": str(raw_siren),
                "detail": f"Compte '{nom}' ignoré : SIREN non conforme '{raw_siren}' (9 chiffres requis)"
            })
            continue

        if cleaned in seen_in_a:
            anomalies.append({
                "type": "DOUBLON_INTERNE_A_TRAITER",
                "siren": cleaned,
                "detail": f"SIREN en doublon dans le fichier à traiter : {cleaned} ('{nom}')"
            })
            continue
        seen_in_a.add(cleaned)

        account_entry = {
            "nom": nom,
            "siren": cleaned,
            "ville": item.get("ville", ""),
            "secteur": item.get("secteur", ""),
            "effectif": item.get("effectif", "")
        }

        if cleaned in known_sirens:
            account_entry["statut_compte"] = "connu"
            known_name = siren_to_known_name.get(cleaned, "")
            if known_name and nom and known_name.lower() != nom.lower():
                anomalies.append({
                    "type": "NOM_DIVERGENT",
                    "siren": cleaned,
                    "detail": f"Différence de nom pour le SIREN {cleaned} : '{nom}' vs connu '{known_name}'"
                })
            comptes_connus.append(account_entry)
        else:
            account_entry["statut_compte"] = "nouveau"
            comptes_nouveaux.append(account_entry)

    return {
        "comptes_connus": comptes_connus,
        "comptes_nouveaux": comptes_nouveaux,
        "anomalies": anomalies
    }
