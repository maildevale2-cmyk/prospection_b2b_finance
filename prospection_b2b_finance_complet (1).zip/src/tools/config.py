"""Configuration manager reading and saving ICP, limits, and schedule."""
import os
import json
from pathlib import Path
from typing import Dict, Any, List

CONFIG_JSON = Path("config/config.json")
CONFIG_YAML = Path("config/config.yaml")

DEFAULT_CONFIG: Dict[str, Any] = {
    "limits": {
        "max_reveals_per_run": 20,
        "timeout_seconds": 60,
        "purge_retention_years": 3
    },
    "icp": {
        "job_titles": [
            "Directeur Administratif et Financier",
            "DAF",
            "Chief Financial Officer",
            "CFO",
            "Credit Manager",
            "Responsable Recouvrement",
            "Responsable Comptable"
        ],
        "company_size_min": 50,
        "company_size_max": 500,
        "sectors": [
            "Commerce de gros & Négoce B2B",
            "Industrie & Manufacturing",
            "Agroalimentaire",
            "BTP & Construction",
            "Transport & Logistique"
        ],
        "departments": ["33"],
        "priority_cities": [
            "Bordeaux", "Mérignac", "Pessac", "Libourne", "Bègles",
            "Talence", "Gradignan", "Arcachon", "Blanquefort", "Langon"
        ],
        "country": "FR"
    },
    "scheduler": {
        "day_of_week": 1,
        "hour": 9,
        "minute": 0
    }
}

DEPARTMENT_CITIES = {
    "33": ["Bordeaux", "Mérignac", "Pessac", "Libourne", "Bègles", "Talence", "Blanquefort", "Langon", "Cestas", "Bruges"],
    "40": ["Mont-de-Marsan", "Dax", "Biscarrosse", "Saint-Paul-lès-Dax", "Tarnos"],
    "47": ["Agen", "Villeneuve-sur-Lot", "Marmande", "Tonneins", "Nérac"],
    "64": ["Pau", "Bayonne", "Anglet", "Biarritz", "Saint-Jean-de-Luz", "Hendaye"],
    "24": ["Périgueux", "Bergerac", "Sarlat-la-Canéda"],
    "17": ["La Rochelle", "Rochefort", "Saintes", "Royan", "Aytré"],
    "16": ["Angoulême", "Cognac", "Soyaux", "Ruelle-sur-Touvre"],
    "75": ["Paris"],
    "69": ["Lyon", "Villeurbanne", "Vénissieux", "Caluire-et-Cuire"],
    "31": ["Toulouse", "Colomiers", "Tournefeuille", "Blagnac"],
    "44": ["Nantes", "Saint-Nazaire", "Saint-Herblain", "Rezé"],
    "59": ["Lille", "Roubaix", "Tourcoing", "Dunkerque", "Villeneuve-d'Ascq"],
    "13": ["Marseille", "Aix-en-Provence", "Arles", "Martigues"]
}

def load_config() -> Dict[str, Any]:
    """Loads configuration from config.json with fallback."""
    if CONFIG_JSON.exists():
        try:
            with open(CONFIG_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {**DEFAULT_CONFIG, **data}
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()

def save_config(cfg: Dict[str, Any]) -> bool:
    """Saves config to config.json and config.yaml."""
    try:
        CONFIG_JSON.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_JSON, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)

        # Also write clean yaml format
        yaml_lines = [
            "# Configuration de l'agent de prospection B2B",
            "app:",
            f'  name: "agent-prospection-daf-b2b"',
            f'  version: "1.2.0"',
            "",
            "limits:",
            f"  max_reveals_per_run: {cfg.get('limits', {}).get('max_reveals_per_run', 20)}",
            f"  timeout_seconds: {cfg.get('limits', {}).get('timeout_seconds', 60)}",
            f"  purge_retention_years: {cfg.get('limits', {}).get('purge_retention_years', 3)}",
            "",
            "icp:",
            "  job_titles:"
        ]
        for jt in cfg.get("icp", {}).get("job_titles", []):
            yaml_lines.append(f'    - "{jt}"')
        
        yaml_lines.append(f"  company_size_min: {cfg.get('icp', {}).get('company_size_min', 50)}")
        yaml_lines.append(f"  company_size_max: {cfg.get('icp', {}).get('company_size_max', 500)}")
        yaml_lines.append("  sectors:")
        for sec in cfg.get("icp", {}).get("sectors", []):
            yaml_lines.append(f'    - "{sec}"')

        yaml_lines.append("  departments:")
        for dep in cfg.get("icp", {}).get("departments", []):
            yaml_lines.append(f'    - "{dep}"')

        yaml_lines.append("")
        yaml_lines.append("scheduler:")
        sched = cfg.get("scheduler", {})
        yaml_lines.append(f"  day_of_week: {sched.get('day_of_week', 1)}")
        yaml_lines.append(f"  hour: {sched.get('hour', 9)}")
        yaml_lines.append(f"  minute: {sched.get('minute', 0)}")
        yaml_lines.append("")

        with open(CONFIG_YAML, "w", encoding="utf-8") as f:
            f.write("\n".join(yaml_lines) + "\n")

        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

def get_target_cities(departments: List[str]) -> List[str]:
    """Returns a list of target cities based on department codes."""
    cities = []
    for d in departments:
        d_clean = str(d).strip()
        if d_clean in DEPARTMENT_CITIES:
            cities.extend(DEPARTMENT_CITIES[d_clean])
    if not cities:
        cities = DEPARTMENT_CITIES["33"]
    return list(dict.fromkeys(cities))
