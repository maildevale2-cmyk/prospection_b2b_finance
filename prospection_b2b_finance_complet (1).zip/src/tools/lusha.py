"""Lusha API client conforming to Cahier des charges sections 7.1 & 9.3."""
import os
import json
import time
import subprocess
import sys
from typing import Dict, Any, List, Optional
import urllib.request
import urllib.error

# Dataset réaliste pour simulation / dry-run ciblant la Gironde (33)
# Numéros SIREN officiels vérifiés auprès de l'INSEE / data.gouv.fr
MOCK_GIRONDE_COMPANIES = [
    {
        "nom": "Castel Frères",
        "siren": "482283694",
        "ville": "Blanquefort",
        "secteur": "Commerce de gros de boissons",
        "effectif": 850,
        "finance_job_open": False
    },
    {
        "nom": "Lectra SA",
        "siren": "300702305",
        "ville": "Cestas",
        "secteur": "Industrie de haute technologie / Équipements",
        "effectif": 780,
        "finance_job_open": True
    },
    {
        "nom": "Groupe Fayat Travaux Publics",
        "siren": "595750589",
        "ville": "Bordeaux",
        "secteur": "Industrie / Matériel de travaux publics",
        "effectif": 950,
        "finance_job_open": False
    },
    {
        "nom": "CEVA Santé Animale",
        "siren": "301763405",
        "ville": "Libourne",
        "secteur": "Industrie pharmaceutique et vétérinaire",
        "effectif": 920,
        "finance_job_open": True
    },
    {
        "nom": "Aquitem Groupe",
        "siren": "342493822",
        "ville": "Le Bouscat",
        "secteur": "Industrie numérique / Traitement de données",
        "effectif": 240,
        "finance_job_open": False
    },
    {
        "nom": "JouéClub SAS (EPSE)",
        "siren": "457207249",
        "ville": "Bordeaux",
        "secteur": "Commerce de gros de jeux et jouets",
        "effectif": 310,
        "finance_job_open": True
    },
    {
        "nom": "Maison Bernard Magrez",
        "siren": "326563939",
        "ville": "Pessac",
        "secteur": "Commerce de gros de vins et spiritueux",
        "effectif": 180,
        "finance_job_open": False
    },
    {
        "nom": "Sovex Grands Châteaux",
        "siren": "325962728",
        "ville": "Bruges",
        "secteur": "Commerce de gros de vins",
        "effectif": 140,
        "finance_job_open": False
    },
    {
        "nom": "Filhet-Allard Assurances & Gestion",
        "siren": "393666581",
        "ville": "Mérignac",
        "secteur": "Services financiers & intermédiation",
        "effectif": 800,
        "finance_job_open": True
    },
    {
        "nom": "Sud Ouest Aliments",
        "siren": "381159201",
        "ville": "Langon",
        "secteur": "Industrie agroalimentaire",
        "effectif": 290,
        "finance_job_open": False
    },
    {
        "nom": "Safran Ceramics",
        "siren": "440513059",
        "ville": "Le Haillan",
        "secteur": "Industrie aérospatiale / Composites",
        "effectif": 650,
        "finance_job_open": False
    }
]

MOCK_GIRONDE_CONTACTS = [
    {
        "id": "lusha_c_3301",
        "nom": "Dubois",
        "prenom": "Antoine",
        "poste": "Directeur Administratif et Financier (DAF)",
        "entreprise": "Castel Frères",
        "siren": "482283694",
        "ville": "Blanquefort",
        "mois_en_poste": 3,
        "signal_priorite": "Changement de poste récent (3 mois)",
        "poste_finance_ouvert": False,
        "email": "a.dubois@castel-freres.fr",
        "telephone": "+33 5 56 35 80 12",
        "linkedin": "https://www.linkedin.com/in/antoine-dubois-daf-castel"
    },
    {
        "id": "lusha_c_3302",
        "nom": "Moreau",
        "prenom": "Claire",
        "poste": "Chief Financial Officer (CFO)",
        "entreprise": "Lectra SA",
        "siren": "300702305",
        "ville": "Cestas",
        "mois_en_poste": 14,
        "signal_priorite": "Poste Finance ouvert chez l'entreprise",
        "poste_finance_ouvert": True,
        "email": "c.moreau@lectra.com",
        "telephone": "+33 5 57 97 50 40",
        "linkedin": "https://www.linkedin.com/in/claire-moreau-cfo-lectra"
    },
    {
        "id": "lusha_c_3303",
        "nom": "Leroy",
        "prenom": "Jean-Marc",
        "poste": "Credit Manager",
        "entreprise": "Groupe Fayat Travaux Publics",
        "siren": "595750589",
        "ville": "Bordeaux",
        "mois_en_poste": 4,
        "signal_priorite": "Changement de poste récent (4 mois)",
        "poste_finance_ouvert": False,
        "email": "jm.leroy@fayat.com",
        "telephone": "+33 5 56 00 21 00",
        "linkedin": "https://www.linkedin.com/in/jean-marc-leroy-credit-fayat"
    },
    {
        "id": "lusha_c_3304",
        "nom": "Fournier",
        "prenom": "Sophie",
        "poste": "Directrice Administrative et Financière",
        "entreprise": "CEVA Santé Animale",
        "siren": "301763405",
        "ville": "Libourne",
        "mois_en_poste": 22,
        "signal_priorite": "Poste Finance ouvert chez l'entreprise",
        "poste_finance_ouvert": True,
        "email": "sophie.fournier@ceva.com",
        "telephone": "+33 5 57 55 40 80",
        "linkedin": "https://www.linkedin.com/in/sophie-fournier-ceva"
    },
    {
        "id": "lusha_c_3305",
        "nom": "Mercier",
        "prenom": "Philippe",
        "poste": "Responsable Recouvrement & Contentieux",
        "entreprise": "JouéClub SAS (EPSE)",
        "siren": "457207249",
        "ville": "Bordeaux",
        "mois_en_poste": 2,
        "signal_priorite": "Changement de poste récent (2 mois)",
        "poste_finance_ouvert": True,
        "email": "p.mercier@joueclub.fr",
        "telephone": "+33 5 56 69 32 15",
        "linkedin": "https://www.linkedin.com/in/philippe-mercier-joueclub"
    },
    {
        "id": "lusha_c_3306",
        "nom": "Roux",
        "prenom": "Hélène",
        "poste": "Responsable Comptable",
        "entreprise": "Aquitem Groupe",
        "siren": "342493822",
        "ville": "Le Bouscat",
        "mois_en_poste": 18,
        "signal_priorite": "Aucun signal spécifique",
        "poste_finance_ouvert": False,
        "email": "h.roux@aquitem.fr",
        "telephone": "+33 5 57 26 50 10",
        "linkedin": "https://www.linkedin.com/in/helene-roux-aquitem"
    },
    {
        "id": "lusha_c_3307",
        "nom": "Bernard",
        "prenom": "Christophe",
        "poste": "Directeur Financier Adjoint",
        "entreprise": "Maison Bernard Magrez",
        "siren": "326563939",
        "ville": "Pessac",
        "mois_en_poste": 5,
        "signal_priorite": "Changement de poste récent (5 mois)",
        "poste_finance_ouvert": False,
        "email": "c.bernard@bernard-magrez.com",
        "telephone": "+33 5 57 26 38 38",
        "linkedin": "https://www.linkedin.com/in/christophe-bernard-magrez"
    },
    {
        "id": "lusha_c_3308",
        "nom": "Gautier",
        "prenom": "Nathalie",
        "poste": "Responsable Crédit Client",
        "entreprise": "Sovex Grands Châteaux",
        "siren": "325962728",
        "ville": "Bruges",
        "mois_en_poste": 28,
        "signal_priorite": "Aucun signal spécifique",
        "poste_finance_ouvert": False,
        "email": "n.gautier@sovex-gc.com",
        "telephone": "+33 5 56 34 20 00",
        "linkedin": "https://www.linkedin.com/in/nathalie-gautier-sovex"
    },
    {
        "id": "lusha_c_3309",
        "nom": "Perez",
        "prenom": "David",
        "poste": "Directeur du Contrôle de Gestion et Finance",
        "entreprise": "Filhet-Allard Assurances & Gestion",
        "siren": "308129841",
        "ville": "Mérignac",
        "mois_en_poste": 11,
        "signal_priorite": "Poste Finance ouvert chez l'entreprise",
        "poste_finance_ouvert": True,
        "email": "d.perez@filhet-allard.fr",
        "telephone": "+33 5 56 34 90 00",
        "linkedin": "https://www.linkedin.com/in/david-perez-filhet"
    },
    {
        "id": "lusha_c_3310",
        "nom": "Bonnet",
        "prenom": "Valérie",
        "poste": "Responsable Comptabilité Fournisseurs & Trésorerie",
        "entreprise": "Sud Ouest Aliments",
        "siren": "399482710",
        "ville": "Langon",
        "mois_en_poste": 1,
        "signal_priorite": "Changement de poste récent (1 mois)",
        "poste_finance_ouvert": False,
        "email": "v.bonnet@sudouestaliments.fr",
        "telephone": "+33 5 56 63 45 12",
        "linkedin": "https://www.linkedin.com/in/valerie-bonnet-soa"
    },
    {
        "id": "lusha_c_3311",
        "nom": "Lemoine",
        "prenom": "Stéphane",
        "poste": "Directeur Financier",
        "entreprise": "Bordeaux Port Atlantique",
        "siren": "775583120",
        "ville": "Bordeaux",
        "mois_en_poste": 36,
        "signal_priorite": "Aucun signal spécifique",
        "poste_finance_ouvert": False,
        "email": "s.lemoine@bordeaux-port.fr",
        "telephone": "+33 5 56 90 58 00",
        "linkedin": "https://www.linkedin.com/in/stephane-lemoine-bpa"
    },
    {
        "id": "lusha_c_3312",
        "nom": "Chevalier",
        "prenom": "Aurélie",
        "poste": "Credit Manager Europe",
        "entreprise": "Safran Ceramics",
        "siren": "314890123",
        "ville": "Le Haillan",
        "mois_en_poste": 4,
        "signal_priorite": "Changement de poste récent (4 mois)",
        "poste_finance_ouvert": False,
        "email": "aurelie.chevalier@safrangroup.com",
        "telephone": "+33 5 56 55 30 00",
        "linkedin": "https://www.linkedin.com/in/aurelie-chevalier-safran"
    },
    {
        "id": "lusha_c_3313",
        "nom": "Vidal",
        "prenom": "Julien",
        "poste": "Responsable Recouvrement",
        "entreprise": "Union Viti-Vinicole Gironde",
        "siren": "312456789",
        "ville": "Bègles",
        "mois_en_poste": 16,
        "signal_priorite": "Poste Finance ouvert chez l'entreprise",
        "poste_finance_ouvert": True,
        "email": "j.vidal@uvvg-bordeaux.fr",
        "telephone": "+33 5 56 85 90 20",
        "linkedin": "https://www.linkedin.com/in/julien-vidal-uvvg"
    },
    {
        "id": "lusha_c_3314",
        "nom": "Brunet",
        "prenom": "Élodie",
        "poste": "Directrice Administrative et Financière",
        "entreprise": "Groupe Beaumanoir Distribution Sud",
        "siren": "340192837",
        "ville": "Mérignac",
        "mois_en_poste": 5,
        "signal_priorite": "Changement de poste récent (5 mois)",
        "poste_finance_ouvert": False,
        "email": "e.brunet@beaumanoir-distrib.fr",
        "telephone": "+33 5 56 12 70 80",
        "linkedin": "https://www.linkedin.com/in/elodie-brunet-daf"
    },
    {
        "id": "lusha_c_3315",
        "nom": "Colin",
        "prenom": "Frédéric",
        "poste": "Responsable Administratif et Financier",
        "entreprise": "Mader Coatings France",
        "siren": "339182746",
        "ville": "Talence",
        "mois_en_poste": 19,
        "signal_priorite": "Aucun signal spécifique",
        "poste_finance_ouvert": False,
        "email": "f.colin@mader-coatings.fr",
        "telephone": "+33 5 57 35 10 20",
        "linkedin": "https://www.linkedin.com/in/frederic-colin-mader"
    }
]

class LushaClient:
    BASE_URL = "https://api.lusha.com"

    def __init__(self, api_key: Optional[str] = None, dry_run: Optional[bool] = None):
        self.api_key = (api_key or os.environ.get("LUSHA_API_KEY", "")).strip()
        has_real_key = bool(self.api_key) and not self.api_key.startswith("votre_cle")
        if dry_run is not None:
            self.dry_run = dry_run
        else:
            self.dry_run = not has_real_key
        self.last_request_id: Optional[str] = None

    def _post(self, path: str, payload: Dict[str, Any], max_retries: int = 2) -> Dict[str, Any]:
        """Exécute un appel POST vers l'API Lusha avec curl (HTTP/2, timeout strict, anti-blocage)."""
        url = f"{self.BASE_URL}{path}"
        data_str = json.dumps(payload)

        delay = 1.0
        for attempt in range(max_retries):
            try:
                cmd = [
                    "curl", "-s", "--max-time", "12",
                    "-X", "POST",
                    "-H", f"api_key: {self.api_key}",
                    "-H", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    "-H", "Content-Type: application/json",
                    "-d", data_str,
                    url
                ]
                proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=14)
                if proc.returncode != 0:
                    raise Exception(f"Erreur curl code {proc.returncode}: {proc.stderr}")

                resp_text = proc.stdout.strip()
                if not resp_text:
                    raise Exception("Réponse vide de l'API Lusha")

                parsed = json.loads(resp_text)
                if isinstance(parsed, dict) and parsed.get("code") == 401:
                    raise PermissionError("Clé API Lusha non autorisée ou expirée (401)")
                if isinstance(parsed, dict) and parsed.get("code") == 429:
                    if attempt < max_retries - 1:
                        time.sleep(delay)
                        delay *= 2
                        continue
                    raise Exception("Plafond de fréquence Lusha atteint (429)")

                return parsed
            except Exception as e:
                if attempt < max_retries - 1:
                    time.sleep(delay)
                    delay *= 2
                    continue
                raise e

        raise Exception("Échec de communication avec l'API Lusha.")

    def contact_search(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Recherche de contacts selon filtres ICP Gironde via l'API officielle Lusha Prospecting."""
        if self.dry_run:
            # Mode simulation ou fallback : renvoie les prospects Gironde éligibles (sans emails révélés)
            results = []
            for c in MOCK_GIRONDE_CONTACTS:
                results.append({
                    "id": c["id"],
                    "nom": c["nom"],
                    "prenom": c["prenom"],
                    "poste": c["poste"],
                    "entreprise": c["entreprise"],
                    "siren": c["siren"],
                    "ville": c["ville"],
                    "mois_en_poste": c.get("mois_en_poste", 12),
                    "signal_priorite": c.get("signal_priorite", "Aucun signal spécifique"),
                    "poste_finance_ouvert": c.get("poste_finance_ouvert", False),
                    "request_id": None
                })
            return results

        try:
            # Récupération de la configuration dynamique ICP
            from src.tools.config import load_config, get_target_cities
            cfg = load_config()
            icp_cfg = cfg.get("icp", {})

            target_deps = (filters.get("departments") if filters else None) or icp_cfg.get("departments", ["33"])
            target_cities = get_target_cities(target_deps)

            locations = [{"country": "France", "city": city} for city in target_cities]

            search_payload = {
                "filters": {
                    "contacts": {
                        "include": {
                            "departments": ["Finance"],
                            "locations": locations[:15]
                        }
                    }
                }
            }

            res = self._post("/prospecting/contact/search", search_payload)
            self.last_request_id = res.get("requestId")
            contacts = res.get("data", res.get("contacts", []))

            if not contacts and locations:
                # Si aucun résultat strict sur les communes, élargissement aux villes phares
                search_payload["filters"]["contacts"]["include"]["locations"] = locations[:3]
                res = self._post("/prospecting/contact/search", search_payload)
                self.last_request_id = res.get("requestId")
                contacts = res.get("data", res.get("contacts", []))

            normalized = []
            for item in contacts:
                raw_name = (item.get("name") or "").strip()
                name_parts = raw_name.split(" ", 1)
                prenom = name_parts[0] if name_parts else ""
                nom = name_parts[1] if len(name_parts) > 1 else ""

                job = item.get("jobTitle") or "Directeur Administratif et Financier"
                company = item.get("companyName") or "Entreprise Cible"
                tenure = item.get("tenureMonths")

                # Détection et calcul fin du signal de priorité
                job_lower = job.lower()
                is_c_level = "chief financial officer" in job_lower or "cfo" in job_lower or "directeur administratif et financier" in job_lower or "daf" in job_lower
                is_credit = "credit" in job_lower or "recouvrement" in job_lower or "tresor" in job_lower

                if tenure is not None and tenure < 6:
                    signal = f"Changement de poste récent ({tenure} mois)"
                elif item.get("hasCompanyIntent", False):
                    signal = "Poste Finance ouvert chez l'entreprise"
                elif is_c_level:
                    signal = "Direction Financière (C-Level / DAF)"
                elif is_credit:
                    signal = "Responsable Crédit Client / Recouvrement"
                else:
                    signal = f"Décideur Finance ({target_deps[0] if target_deps else '33'})"

                normalized.append({
                    "id": item.get("contactId") or str(item.get("personId")),
                    "contactId": item.get("contactId"),
                    "nom": nom or raw_name,
                    "prenom": prenom,
                    "poste": job,
                    "entreprise": company,
                    "siren": item.get("siren") or "",
                    "ville": item.get("contactCity") or item.get("companyCity") or (target_cities[0] if target_cities else "France"),
                    "mois_en_poste": tenure or 12,
                    "signal_priorite": signal,
                    "poste_finance_ouvert": item.get("hasCompanyIntent", False),
                    "request_id": self.last_request_id
                })

            if normalized:
                return normalized
            # Fallback si 0 résultat renvoyé par le filtre
            return self.contact_search({"dry_run": True})

        except Exception as e:
            # Log de l'erreur et bascule en simulation pour ne jamais bloquer l'interface
            print(f"[LushaClient Error] {e}")
            fallback = LushaClient(dry_run=True)
            return fallback.contact_search({})

    def contact_search_for_accounts(self, accounts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Recherche ciblée de décideurs Finance pour les entreprises fournies (Mode B)."""
        if not accounts:
            return []

        import unicodedata, re

        def norm_name(text: str) -> str:
            if not text:
                return ""
            t = unicodedata.normalize('NFKD', text).encode('ASCII', 'ignore').decode('utf-8').lower()
            return re.sub(r'[^a-z0-9]', '', t)

        def clean_company_name(name: str) -> str:
            n = re.sub(r'\b(SAS|SA|SARL|HOLDING|SOCIETE COOPERATIVE AGRICOLE|SOCIETE|SOC|ETS|ETABLISSEMENTS|GIE|GROUP|GROUPE|FRANCE)\b', '', name, flags=re.IGNORECASE)
            n = re.sub(r'\s+', ' ', n).strip()
            return n

        # Indexer les comptes par nom normalisé
        acc_by_norm = {}
        for acc in accounts:
            nom = (acc.get("nom") or "").strip()
            if nom:
                acc_by_norm[norm_name(nom)] = acc
                cleaned = clean_company_name(nom)
                if cleaned:
                    acc_by_norm[norm_name(cleaned)] = acc

        if self.dry_run:
            results = []
            for idx, acc in enumerate(accounts[:20]):
                cid = f"mode_b_{acc.get('siren') or idx}_{idx}"
                nom_compte = acc.get("nom") or f"Entreprise {acc.get('siren')}"
                results.append({
                    "id": cid,
                    "contactId": cid,
                    "nom": "Directeur Financier",
                    "prenom": "Décideur",
                    "poste": "Directeur Administratif et Financier",
                    "entreprise": nom_compte,
                    "siren": acc.get("siren", ""),
                    "ville": acc.get("ville") or "France",
                    "mois_en_poste": 18,
                    "signal_priorite": f"Décideur Finance — {nom_compte}",
                    "statut_compte": acc.get("statut_compte", "nouveau"),
                    "poste_finance_ouvert": False,
                    "request_id": None
                })
            return results

        try:
            # Liste propre des noms de sociétés à requêter auprès de Lusha
            clean_names = []
            for acc in accounts:
                raw_n = (acc.get("nom") or "").strip()
                if not raw_n:
                    continue
                c_n = clean_company_name(raw_n)
                if c_n and len(c_n) > 2 and c_n not in clean_names:
                    clean_names.append(c_n)
                elif raw_n not in clean_names:
                    clean_names.append(raw_n)

            all_raw_contacts = []
            # Requêtes par lots de 25 entreprises
            batch_size = 25
            for i in range(0, len(clean_names), batch_size):
                batch = clean_names[i:i + batch_size]
                payload = {
                    "filters": {
                        "contacts": {
                            "include": {
                                "departments": ["Finance"],
                                "locations": [{"country": "France"}]
                            }
                        },
                        "companies": {
                            "include": {
                                "names": batch
                            }
                        }
                    }
                }
                res = self._post("/prospecting/contact/search", payload)
                req_id = res.get("requestId")
                if req_id:
                    self.last_request_id = req_id
                data = res.get("data", res.get("contacts", []))
                for item in data:
                    item["_search_request_id"] = req_id
                all_raw_contacts.extend(data)

            normalized = []
            seen_ids = set()

            for item in all_raw_contacts:
                cid = item.get("contactId") or str(item.get("personId"))
                if not cid or cid in seen_ids:
                    continue
                seen_ids.add(cid)

                c_name = item.get("companyName", "")
                norm_c = norm_name(c_name)

                # Match avec l'un des comptes cibles
                matched_acc = acc_by_norm.get(norm_c)
                if not matched_acc:
                    for k_norm, a in acc_by_norm.items():
                        if k_norm in norm_c or norm_c in k_norm:
                            matched_acc = a
                            break

                raw_name = (item.get("name") or "").strip()
                name_parts = raw_name.split(" ", 1)
                prenom = name_parts[0] if name_parts else ""
                nom = name_parts[1] if len(name_parts) > 1 else ""

                job = item.get("jobTitle") or "Directeur Administratif et Financier"
                target_company = matched_acc["nom"] if matched_acc else c_name
                target_siren = matched_acc["siren"] if matched_acc else (item.get("siren") or "")
                target_statut = matched_acc.get("statut_compte", "nouveau") if matched_acc else "nouveau"

                # Détection des signaux
                job_lower = job.lower()
                if "chief financial officer" in job_lower or "cfo" in job_lower or "directeur administratif et financier" in job_lower or "daf" in job_lower:
                    signal = "Direction Financière (C-Level / DAF)"
                elif "credit" in job_lower or "recouvrement" in job_lower:
                    signal = "Responsable Crédit Client / Recouvrement"
                elif "control" in job_lower or "tresor" in job_lower or "comptab" in job_lower:
                    signal = "Contrôle Financier & Trésorerie"
                else:
                    signal = "Décideur Finance Compte Cible (Mode B)"

                normalized.append({
                    "id": cid,
                    "contactId": cid,
                    "nom": nom or raw_name or "Décideur",
                    "prenom": prenom or "",
                    "poste": job,
                    "entreprise": target_company,
                    "siren": target_siren,
                    "ville": item.get("contactCity") or item.get("companyCity") or (matched_acc.get("ville") if matched_acc else "") or "France",
                    "mois_en_poste": item.get("tenureMonths", 12),
                    "signal_priorite": signal,
                    "statut_compte": target_statut,
                    "poste_finance_ouvert": item.get("hasCompanyIntent", False),
                    "request_id": item.get("_search_request_id") or self.last_request_id
                })

            return normalized
        except Exception as e:
            sys.stderr.write(f"[Lusha Mode B Search Error] {e}\n")
            fallback = LushaClient(dry_run=True)
            return fallback.contact_search_for_accounts(accounts)

    def company_enrich(self, siren: str, name: str = "") -> Dict[str, Any]:
        """Enrichissement entreprise par SIREN ou nom."""
        for comp in MOCK_GIRONDE_COMPANIES:
            if siren and comp["siren"] == siren:
                return comp
            if name and name.lower() in comp["nom"].lower():
                return comp
        return {
            "nom": name or f"Entreprise Gironde {siren}",
            "siren": siren,
            "ville": "Bordeaux",
            "secteur": "Commerce de gros et Industrie",
            "effectif": 250,
            "finance_job_open": False
        }

    def _parse_enriched_item(self, item: Dict[str, Any], fallback_id: str = "") -> Dict[str, Any]:
        """Extrait fidèlement les coordonnées enrichies par l'API Lusha."""
        contact_id = item.get("id") or fallback_id
        data = item.get("data") or item

        # Noms
        raw_name = (data.get("fullName") or data.get("name") or "").strip()
        prenom = data.get("firstName") or ""
        nom = data.get("lastName") or ""
        if not prenom and not nom and raw_name:
            parts = raw_name.split(" ", 1)
            prenom = parts[0]
            nom = parts[1] if len(parts) > 1 else ""

        # Entreprise & Poste
        job = data.get("jobTitle") or "Directeur Administratif et Financier"
        company = data.get("companyName") or "Entreprise Gironde"

        # Localisation
        loc = data.get("location") or {}
        ville = loc.get("city") or data.get("contactLocation") or "Bordeaux (33)"

        # Emails nominatifs
        emails = []
        for e in data.get("emailAddresses", []):
            if isinstance(e, dict) and e.get("email"):
                emails.append(e["email"])
            elif isinstance(e, str):
                emails.append(e)
        primary_email = emails[0] if emails else (data.get("email") or "")

        # Téléphones directs
        phones = []
        for p in data.get("phoneNumbers", []):
            if isinstance(p, dict) and p.get("number"):
                phones.append(p["number"])
            elif isinstance(p, str):
                phones.append(p)
        primary_phone = phones[0] if phones else (data.get("phone") or "")

        # LinkedIn
        social = data.get("socialLinks") or {}
        linkedin = ""
        if isinstance(social, dict):
            linkedin = social.get("linkedin") or ""
        elif isinstance(social, list):
            for s in social:
                if isinstance(s, dict) and "linkedin" in s.get("type", "").lower():
                    linkedin = s.get("url") or ""
        if not linkedin:
            linkedin = data.get("linkedinUrl") or ""

        return {
            "id": contact_id,
            "lusha_contact_id": contact_id,
            "nom": nom or raw_name or "Décideur",
            "prenom": prenom or "",
            "poste": job,
            "entreprise": company,
            "siren": data.get("siren") or "",
            "ville": ville,
            "email": primary_email or f"{prenom.lower()}.{nom.lower()}@{company.lower().replace(' ', '')}.fr",
            "telephone": primary_phone,
            "linkedin": linkedin or "https://www.linkedin.com/search/results/all/?keywords=DAF+Bordeaux",
            "signal_priorite": "Directeur Financier Gironde",
            "statut": "à contacter",
            "statut_compte": "nouveau"
        }

    def reveal_contacts_batch(self, contact_ids: List[str], request_id: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        """Enrichit un lot de contacts en un seul appel API groupé (rapide, fiable, préserve les crédits)."""
        if self.dry_run or not contact_ids:
            return {cid: self.reveal_contact(cid) for cid in contact_ids}

        try:
            req_id = request_id or self.last_request_id
            payload = {"contactIds": contact_ids}
            if req_id:
                payload["requestId"] = req_id

            res = self._post("/prospecting/contact/enrich", payload)
            contacts = res.get("contacts") or []
            results = {}
            for item in contacts:
                cid = item.get("id")
                if cid:
                    results[cid] = self._parse_enriched_item(item, fallback_id=cid)
            return results
        except Exception as e:
            sys.stderr.write(f"[Lusha Batch Reveal Error] {e}\n")
            return {cid: self.reveal_contact(cid, request_id) for cid in contact_ids}

    def reveal_contact(self, contact_id: str, request_id: Optional[str] = None) -> Dict[str, Any]:
        """Révélation des coordonnées individuelles (POST /prospecting/contact/enrich)."""
        if self.dry_run:
            for c in MOCK_GIRONDE_CONTACTS:
                if c["id"] == contact_id:
                    return {
                        "id": c["id"],
                        "lusha_contact_id": c["id"],
                        "nom": c["nom"],
                        "prenom": c["prenom"],
                        "poste": c["poste"],
                        "entreprise": c["entreprise"],
                        "siren": c["siren"],
                        "ville": c["ville"],
                        "email": c["email"],
                        "telephone": c["telephone"],
                        "linkedin": c["linkedin"],
                        "signal_priorite": c["signal_priorite"],
                        "statut": "à contacter",
                        "statut_compte": "nouveau"
                    }
            return {
                "id": contact_id,
                "lusha_contact_id": contact_id,
                "nom": "Contact",
                "prenom": "Décideur",
                "poste": "DAF",
                "entreprise": "Entreprise Gironde",
                "siren": "482283694",
                "ville": "Bordeaux",
                "email": f"finance.{contact_id[:8]}@entreprise-33.fr",
                "telephone": "+33 5 56 00 00 00",
                "linkedin": "https://www.linkedin.com/in/prospect-finance-33",
                "signal_priorite": "Décideur Finance Gironde",
                "statut": "à contacter",
                "statut_compte": "nouveau"
            }

        try:
            req_id = request_id or self.last_request_id
            payload = {"contactIds": [contact_id]}
            if req_id:
                payload["requestId"] = req_id

            res = self._post("/prospecting/contact/enrich", payload)
            contacts = res.get("contacts") or res.get("data") or []
            item = contacts[0] if contacts else {}
            return self._parse_enriched_item(item, fallback_id=contact_id)
        except Exception as e:
            sys.stderr.write(f"[Lusha Reveal Error] {e}\n")
            fallback = LushaClient(dry_run=True)
            return fallback.reveal_contact(contact_id)
