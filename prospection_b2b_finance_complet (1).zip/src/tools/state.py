"""SQLite State Manager and CSV Exporter conforming to Cahier des charges sections 8 & 10."""
import os
import sqlite3
import csv
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Set, Optional
from src.utils import mask_personal_data

class StateManager:
    def __init__(self, db_path: str = "data/prospection.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def get_connection(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lusha_contact_id TEXT UNIQUE,
                nom TEXT,
                prenom TEXT,
                poste TEXT,
                entreprise TEXT,
                siren TEXT,
                ville TEXT,
                email TEXT,
                telephone TEXT,
                linkedin TEXT,
                signal_priorite TEXT,
                score INTEGER DEFAULT 0,
                justification TEXT DEFAULT '',
                message_propose TEXT,
                statut TEXT CHECK(statut IN ('à contacter','contacté','relancé','répondu','refus')),
                statut_compte TEXT CHECK(statut_compte IN ('connu','nouveau')),
                date_ajout TEXT,
                date_derniere_action TEXT
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mode TEXT CHECK(mode IN ('A','B')),
                date_debut TEXT,
                date_fin TEXT,
                nb_prospects_trouves INTEGER,
                nb_prospects_reveles INTEGER,
                nb_credits_lusha INTEGER,
                nb_comptes_connus INTEGER,
                nb_comptes_nouveaux INTEGER,
                nb_sans_decideur INTEGER,
                resume TEXT
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                level TEXT,
                message TEXT
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS optouts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE,
                date_opposition TEXT,
                motif TEXT
            )
            """)
            conn.commit()

    def get_existing_lusha_ids(self) -> Set[str]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT lusha_contact_id FROM contacts WHERE lusha_contact_id IS NOT NULL").fetchall()
            return {r["lusha_contact_id"] for r in rows if r["lusha_contact_id"]}

    def get_opted_out_emails(self) -> Set[str]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT email FROM optouts").fetchall()
            return {r["email"].lower().strip() for r in rows if r["email"]}

    def add_optout(self, email: str, motif: str = "Opposition prospection") -> bool:
        norm_email = email.lower().strip()
        now = datetime.now().isoformat()
        with self.get_connection() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO optouts (email, date_opposition, motif) VALUES (?, ?, ?)",
                (norm_email, now, motif)
            )
            # Supprimer également des contacts actifs pour respecter le droit à l'effacement
            conn.execute("DELETE FROM contacts WHERE LOWER(email) = ?", (norm_email,))
            conn.commit()
        self.log_event("INFO", f"Opt-out enregistré pour [EMAIL_MASQUÉ]")
        return True

    def is_opted_out(self, email: str) -> bool:
        if not email:
            return False
        with self.get_connection() as conn:
            row = conn.execute("SELECT id FROM optouts WHERE LOWER(email) = ?", (email.lower().strip(),)).fetchone()
            return row is not None

    def upsert_contact(self, contact: Dict[str, Any]) -> int:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        email = contact.get("email") or ""
        
        # Vérification RGPD liste noire
        if email and self.is_opted_out(email):
            self.log_event("WARNING", f"Contact ignoré : email sur liste noire opt-out")
            return 0

        # Vérification dédoublonnage par email/téléphone si déjà révélé
        with self.get_connection() as conn:
            cursor = conn.cursor()
            existing = None
            if contact.get("lusha_contact_id"):
                existing = cursor.execute(
                    "SELECT id FROM contacts WHERE lusha_contact_id = ?",
                    (contact["lusha_contact_id"],)
                ).fetchone()

            if not existing and email:
                existing = cursor.execute(
                    "SELECT id FROM contacts WHERE LOWER(email) = ?",
                    (email.lower(),)
                ).fetchone()

            statut = contact.get("statut") or "à contacter"
            if statut not in ('à contacter', 'contacté', 'relancé', 'répondu', 'refus'):
                statut = 'à contacter'

            statut_compte = contact.get("statut_compte") or "nouveau"
            if statut_compte not in ('connu', 'nouveau'):
                statut_compte = 'nouveau'

            if existing:
                cid = existing["id"]
                cursor.execute("""
                UPDATE contacts SET
                    nom = COALESCE(?, nom),
                    prenom = COALESCE(?, prenom),
                    poste = COALESCE(?, poste),
                    entreprise = COALESCE(?, entreprise),
                    siren = COALESCE(?, siren),
                    ville = COALESCE(?, ville),
                    email = COALESCE(?, email),
                    telephone = COALESCE(?, telephone),
                    linkedin = COALESCE(?, linkedin),
                    signal_priorite = COALESCE(?, signal_priorite),
                    score = COALESCE(?, score),
                    justification = COALESCE(?, justification),
                    message_propose = COALESCE(?, message_propose),
                    date_derniere_action = ?
                WHERE id = ?
                """, (
                    contact.get("nom"),
                    contact.get("prenom"),
                    contact.get("poste"),
                    contact.get("entreprise"),
                    contact.get("siren"),
                    contact.get("ville"),
                    contact.get("email"),
                    contact.get("telephone"),
                    contact.get("linkedin"),
                    contact.get("signal_priorite"),
                    contact.get("score"),
                    contact.get("justification"),
                    contact.get("message_propose"),
                    now,
                    cid
                ))
                conn.commit()
                return cid
            else:
                cursor.execute("""
                INSERT INTO contacts (
                    lusha_contact_id, nom, prenom, poste, entreprise, siren, ville,
                    email, telephone, linkedin, signal_priorite, score, justification,
                    message_propose, statut, statut_compte, date_ajout, date_derniere_action
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    contact.get("lusha_contact_id"),
                    contact.get("nom", ""),
                    contact.get("prenom", ""),
                    contact.get("poste", ""),
                    contact.get("entreprise", ""),
                    contact.get("siren", ""),
                    contact.get("ville", ""),
                    contact.get("email", ""),
                    contact.get("telephone", ""),
                    contact.get("linkedin", ""),
                    contact.get("signal_priorite", ""),
                    contact.get("score", 0),
                    contact.get("justification", ""),
                    contact.get("message_propose", ""),
                    statut,
                    statut_compte,
                    contact.get("date_ajout", now),
                    now
                ))
                conn.commit()
                return cursor.lastrowid

    def update_contact_status(self, contact_id: int, new_status: str) -> bool:
        if new_status not in ('à contacter', 'contacté', 'relancé', 'répondu', 'refus'):
            raise ValueError(f"Statut invalide : {new_status}")
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self.get_connection() as conn:
            conn.execute(
                "UPDATE contacts SET statut = ?, date_derniere_action = ? WHERE id = ?",
                (new_status, now, contact_id)
            )
            conn.commit()
        return True

    def export_csv(self, filepath: Optional[str] = None) -> str:
        """Export contacts in CSV with UTF-8 BOM and french ';' separator per spec section 8.2."""
        if not filepath:
            exports_dir = Path("data/exports")
            exports_dir.mkdir(parents=True, exist_ok=True)
            today_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = str(exports_dir / f"prospects_gironde_{today_str}.csv")

        columns = [
            "nom", "prenom", "poste", "entreprise", "ville", "email",
            "telephone", "linkedin", "signal_priorite", "score", "justification",
            "message_propose", "statut", "statut_compte", "date_ajout"
        ]

        with self.get_connection() as conn:
            cursor = conn.cursor()
            query = f"SELECT {', '.join(columns)} FROM contacts ORDER BY id DESC"
            rows = cursor.execute(query).fetchall()

        with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerow(columns)
            for r in rows:
                writer.writerow([r[col] or "" for col in columns])

        self.log_event("INFO", f"Export CSV généré : {filepath} ({len(rows)} lignes)")
        return filepath

    def log_event(self, level: str, message: str) -> bool:
        """Write to database logs table and to rotating logs file."""
        now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        safe_msg = mask_personal_data(message)

        # Database log
        try:
            with self.get_connection() as conn:
                conn.execute(
                    "INSERT INTO logs (timestamp, level, message) VALUES (?, ?, ?)",
                    (now_iso, level.upper(), safe_msg)
                )
                conn.commit()
        except Exception:
            pass

        # File log
        try:
            logs_dir = Path("logs")
            logs_dir.mkdir(parents=True, exist_ok=True)
            day_file = logs_dir / f"run_{datetime.now().strftime('%Y%m%d')}.log"
            line = f"{now_iso} | {level.upper():<7} | {safe_msg}\n"
            with open(day_file, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass

        return True

    def log_run_summary(
        self,
        mode: str,
        date_debut: str,
        date_fin: str,
        nb_prospects_trouves: int,
        nb_prospects_reveles: int,
        nb_credits_lusha: int,
        nb_comptes_connus: int = 0,
        nb_comptes_nouveaux: int = 0,
        nb_sans_decideur: int = 0,
        resume: str = ""
    ) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO runs (
                mode, date_debut, date_fin, nb_prospects_trouves, nb_prospects_reveles,
                nb_credits_lusha, nb_comptes_connus, nb_comptes_nouveaux, nb_sans_decideur, resume
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                mode, date_debut, date_fin, nb_prospects_trouves, nb_prospects_reveles,
                nb_credits_lusha, nb_comptes_connus, nb_comptes_nouveaux, nb_sans_decideur, resume
            ))
            conn.commit()
            return cursor.lastrowid

    def get_all_contacts(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM contacts ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def get_all_runs(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def get_recent_logs(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def purge_older_than(self, years: int = 3) -> int:
        """RGPD compliance: purge contacts older than N years from last action."""
        cutoff_date = (datetime.now() - timedelta(days=years * 365)).strftime("%Y-%m-%d %H:%M:%S")
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM contacts WHERE date_derniere_action < ?", (cutoff_date,))
            deleted = cursor.rowcount
            conn.commit()
        self.log_event("INFO", f"Purge RGPD ({years} ans) : {deleted} contacts supprimés")
        return deleted
