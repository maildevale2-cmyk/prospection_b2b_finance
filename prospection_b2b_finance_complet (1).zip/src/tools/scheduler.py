"""Task Scheduler installer for Linux/Mac cron and Windows Task Scheduler per section 9.3 & 11.1."""
import os
import platform
import subprocess
from pathlib import Path

def generate_scheduler_command(mode: str = "A", hour: int = 9, weekday: int = 1) -> str:
    """Génère la commande ou ligne crontab adaptée au système d'exploitation."""
    system = platform.system()
    current_dir = os.getcwd()
    python_cmd = "python3" if system != "Windows" else "python.exe"

    if system == "Windows":
        script_path = os.path.join(current_dir, "src", "main.py")
        days_map = {1: "MON", 2: "TUE", 3: "WED", 4: "THU", 5: "FRI", 6: "SAT", 7: "SUN"}
        day_str = days_map.get(weekday, "MON")
        time_str = f"{hour:02d}:00"
        return f'schtasks /create /tn "AgentProspectionDAF" /tr "{python_cmd} {script_path} --mode {mode}" /sc weekly /d {day_str} /st {time_str} /f'
    else:
        # Linux / MacOS cron
        return f"0 {hour} * * {weekday} cd {current_dir} && {python_cmd} src/main.py --mode {mode} >> logs/cron.log 2>&1"

def install_cron(mode: str = "A", hour: int = 9, weekday: int = 1) -> bool:
    """Installe la tâche planifiée sur le système hôte."""
    system = platform.system()
    cmd = generate_scheduler_command(mode, hour, weekday)

    if system == "Windows":
        try:
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return res.returncode == 0
        except Exception:
            return False
    else:
        # Linux / macOS cron install
        try:
            # Lire crontab actuel
            current_cron = subprocess.run(["crontab", "-l"], capture_output=True, text=True).stdout
        except Exception:
            current_cron = ""

        # Éviter les doublons
        cron_marker = "AgentProspectionDAF"
        new_lines = [line for line in current_cron.splitlines() if cron_marker not in line and "src/main.py" not in line]
        new_lines.append(f"{cmd} # AgentProspectionDAF")
        new_cron_text = "\n".join(new_lines) + "\n"

        try:
            proc = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE, text=True)
            proc.communicate(input=new_cron_text)
            return proc.returncode == 0
        except Exception:
            return False
