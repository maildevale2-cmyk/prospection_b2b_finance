import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldAlert, 
  CheckSquare, 
  Square, 
  AlertCircle, 
  Check, 
  X,
  CreditCard,
  Building,
  User,
  Filter,
  Award
} from 'lucide-react';
import { Candidate } from '../types';
import { calculateContactScore, ScoringConfig } from '../services/scoring';

interface HitlModalProps {
  isOpen: boolean;
  candidates: Candidate[];
  onConfirm: (selected: Candidate[]) => void;
  onCancel: () => void;
  isProcessing: boolean;
  mode: 'A' | 'B';
  maxReveals?: number;
  config?: any;
}

export const HitlModal: React.FC<HitlModalProps> = ({
  isOpen,
  candidates,
  onConfirm,
  onCancel,
  isProcessing,
  mode,
  maxReveals = 20,
  config
}) => {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [priorityFilter, setPriorityFilter] = useState<'all' | '1' | '2' | '3'>('all');

  const scoringConfig: ScoringConfig = useMemo(() => {
    const icp = config?.data?.icp || {};
    return {
      departments: icp.departments || ['33'],
      company_size_min: icp.company_size_min || 50,
      company_size_max: icp.company_size_max || 500,
      sectors: icp.sectors || ['Commerce de gros', 'Industrie', 'Agroalimentaire']
    };
  }, [config]);

  // Score and sort candidates deterministically
  const scoredCandidates = useMemo(() => {
    return candidates.map(c => {
      const res = calculateContactScore({
        poste: c.poste,
        entreprise: c.entreprise,
        ville: c.ville,
        mois_en_poste: c.mois_en_poste,
        poste_finance_ouvert: c.poste_finance_ouvert,
        statut_compte: c.statut_compte,
        signal_priorite: c.signal_priorite
      }, scoringConfig);

      return {
        ...c,
        score: c.score !== undefined ? c.score : res.score,
        priority: res.priority,
        priority_reason: res.justification,
        justification: res.justification,
        isEliminated: res.isEliminated,
        eliminationReason: res.eliminationReason,
        badgeClass: res.badgeClass,
        dotClass: res.dotClass
      };
    }).sort((a, b) => {
      // Tri par priorité croissante (1, 2, 3) puis par score décroissant (100 -> 0)
      if (a.priority !== b.priority) {
        return a.priority - b.priority;
      }
      return (b.score || 0) - (a.score || 0);
    });
  }, [candidates, scoringConfig]);

  useEffect(() => {
    if (scoredCandidates.length > 0) {
      // Par défaut, sélectionner les meilleurs candidats jusqu'au plafond strict
      const eligible = scoredCandidates.filter(c => !c.isEliminated);
      const initial = new Set(eligible.slice(0, maxReveals).map(c => c.id));
      setSelectedIds(initial);
    }
  }, [scoredCandidates, maxReveals]);

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      if (next.size >= maxReveals) {
        alert(`Plafond strict : impossible de sélectionner plus de ${maxReveals} contacts par session.`);
        return;
      }
      next.add(id);
    }
    setSelectedIds(next);
  };

  const selectTopPriority = () => {
    const eligible = scoredCandidates.filter(c => !c.isEliminated);
    const next = new Set(eligible.slice(0, maxReveals).map(c => c.id));
    setSelectedIds(next);
  };

  const deselectAll = () => {
    setSelectedIds(new Set());
  };

  const filteredCandidates = scoredCandidates.filter(c => {
    if (priorityFilter === 'all') return true;
    return String(c.priority) === priorityFilter;
  });

  const p1Count = scoredCandidates.filter(c => c.priority === 1).length;
  const p2Count = scoredCandidates.filter(c => c.priority === 2).length;
  const p3Count = scoredCandidates.filter(c => c.priority === 3).length;

  const selectedList = scoredCandidates.filter(c => selectedIds.has(c.id));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-md">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-tight">
                  Classement Déterministe & Confirmation HITL — Mode {mode}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-emerald-400 border border-slate-700">
                  Algorithme 100 pts actif
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Score calculé sur le poste (50 pts), l'entreprise (30 pts) et les signaux (20 pts). Révélation sécurisée contact par contact.
              </p>
            </div>
          </div>
          <button 
            onClick={onCancel}
            disabled={isProcessing}
            className="text-slate-400 hover:text-white p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Control bar */}
        <div className="px-6 py-3 bg-amber-50/80 border-b border-amber-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4 text-slate-800 flex-wrap">
            <span className="flex items-center gap-1.5 font-bold text-amber-950">
              <CreditCard className="w-4 h-4 text-amber-600" />
              <span>Crédits à consommer : <strong className="text-sm font-mono">{selectedIds.size}</strong> / {maxReveals} max</span>
            </span>
            <span aria-hidden="true" className="text-amber-300">|</span>
            <span className="text-slate-700">
              {candidates.length} prospects scorés & triés
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={selectTopPriority}
              className="px-3 py-1 text-slate-800 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors font-semibold shadow-2xs"
            >
              Sélectionner les {Math.min(candidates.length, maxReveals)} prioritaires
            </button>
            <button
              type="button"
              onClick={deselectAll}
              className="px-2.5 py-1 text-slate-600 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors font-medium"
            >
              Désélectionner tout
            </button>
          </div>
        </div>

        {/* Priority Filter Tabs */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="text-slate-500 font-semibold mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filtrer :
            </span>
            <button
              onClick={() => setPriorityFilter('all')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                priorityFilter === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              Tous ({scoredCandidates.length})
            </button>
            <button
              onClick={() => setPriorityFilter('1')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                priorityFilter === '1'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white border border-emerald-200 text-emerald-800 hover:bg-emerald-50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Priorité 1 (Score ≥ 70) : {p1Count}</span>
            </button>
            <button
              onClick={() => setPriorityFilter('2')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                priorityFilter === '2'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white border border-amber-200 text-amber-800 hover:bg-amber-50'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              <span>Priorité 2 (40-69) : {p2Count}</span>
            </button>
            <button
              onClick={() => setPriorityFilter('3')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                priorityFilter === '3'
                  ? 'bg-slate-700 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-slate-400"></span>
              <span>Priorité 3 (&lt; 40) : {p3Count}</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 hidden sm:block">
            Tri automatique : <strong>Priorité décroissante</strong> puis <strong>Score /100</strong>
          </div>
        </div>

        {/* Prospects List Table */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="border border-slate-200 rounded-md overflow-hidden shadow-2xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-3 w-12 text-center">Révéler</th>
                  <th className="py-2.5 px-3">Score & Priorité</th>
                  <th className="py-2.5 px-3">Décideur Finance</th>
                  <th className="py-2.5 px-3">Entreprise & Ville</th>
                  <th className="py-2.5 px-3">Justification du Score (Règles déterministes)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {filteredCandidates.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500">
                      Aucun prospect dans cette catégorie de priorité.
                    </td>
                  </tr>
                ) : (
                  filteredCandidates.map((c) => {
                    const isChecked = selectedIds.has(c.id);
                    const isP1 = c.priority === 1;
                    const isP2 = c.priority === 2;

                    return (
                      <tr 
                        key={c.id} 
                        onClick={() => toggleSelect(c.id)}
                        className={`hover:bg-slate-50 cursor-pointer transition-colors ${
                          isChecked ? 'bg-slate-50/60' : 'opacity-70'
                        }`}
                      >
                        <td className="py-2.5 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleSelect(c.id)}
                            className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 h-4 w-4 cursor-pointer"
                          />
                        </td>

                        {/* Score & Priority */}
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 ${
                              isP1 
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                                : isP2 
                                ? 'bg-amber-50 text-amber-800 border-amber-300' 
                                : 'bg-slate-100 text-slate-700 border-slate-300'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                isP1 ? 'bg-emerald-500' : isP2 ? 'bg-amber-500' : 'bg-slate-400'
                              }`} />
                              Priorité {c.priority}
                            </span>

                            <div className="flex items-center gap-1">
                              <span className="font-mono font-bold text-xs text-slate-900">
                                {c.score ?? 0}
                              </span>
                              <span className="text-[10px] text-slate-400">/100</span>
                            </div>
                          </div>

                          {/* Mini Progress Bar */}
                          <div className="w-20 bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1.5">
                            <div 
                              className={`h-full ${
                                isP1 ? 'bg-emerald-500' : isP2 ? 'bg-amber-500' : 'bg-slate-400'
                              }`}
                              style={{ width: `${Math.min(c.score || 0, 100)}%` }}
                            />
                          </div>
                        </td>

                        {/* Name & Job */}
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-slate-900">
                            {c.prenom} {c.nom}
                          </div>
                          <div className="text-slate-600 text-[11px] font-medium">
                            {c.poste}
                          </div>
                        </td>

                        {/* Company & City */}
                        <td className="py-2.5 px-3">
                          <div className="font-semibold text-slate-800 flex items-center gap-1.5 flex-wrap">
                            <span>{c.entreprise}</span>
                            {mode === 'B' && (
                              <span className="px-1.5 py-0.2 text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded">
                                Compte CSV
                              </span>
                            )}
                          </div>
                          <div className="text-slate-500 text-[11px]">
                            {c.ville || 'France'} {c.siren ? `· SIREN ${c.siren}` : ''}
                          </div>
                        </td>

                        {/* Justification */}
                        <td className="py-2.5 px-3 max-w-md">
                          <div className="text-slate-700 text-[11px] leading-relaxed">
                            {c.justification || c.priority_reason || c.signal_priorite}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-600">
            {selectedIds.size === 0 ? (
              <span className="text-rose-600 font-medium flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Veuillez sélectionner au moins 1 prospect à révéler
              </span>
            ) : (
              <span>
                <strong>{selectedIds.size} coordonnées</strong> prêtes à être révélées (Plafond configuré : {maxReveals} crédits).
              </span>
            )}
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={onCancel}
              disabled={isProcessing}
              className="flex-1 sm:flex-none px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-100 transition-colors disabled:opacity-50"
            >
              Annuler (0 crédit consommé)
            </button>
            <button
              type="button"
              onClick={() => onConfirm(selectedList)}
              disabled={isProcessing || selectedIds.size === 0 || selectedIds.size > maxReveals}
              className="flex-1 sm:flex-none px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 active:bg-black transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-xs"
            >
              {isProcessing ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Révélation & Rédaction en cours...</span>
                </>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Révéler les coordonnées ({selectedIds.size} crédits)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
