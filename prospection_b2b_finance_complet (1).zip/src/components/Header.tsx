import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Download, 
  Play, 
  ShieldCheck, 
  Calendar,
  CreditCard,
  Mail,
  LogOut,
  Send,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { AppStats } from '../types';
import { auth, initAuth, googleSignIn, logout, sendGmailReport } from '../services/googleAuth';
import { User } from 'firebase/auth';

interface HeaderProps {
  stats: AppStats | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onStartModeA: () => void;
  onExportCsv: () => void;
  isExporting: boolean;
  isStartingRun?: boolean;
  config?: any;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  activeTab,
  setActiveTab,
  onStartModeA,
  onExportCsv,
  isExporting,
  isStartingRun = false,
  config
}) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [emailStatus, setEmailStatus] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      (user) => setCurrentUser(user),
      () => setCurrentUser(null)
    );
    return () => unsubscribe();
  }, []);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const res = await googleSignIn();
      if (res?.user) {
        setCurrentUser(res.user);
      }
    } catch (err: any) {
      alert(`Erreur de connexion Google : ${err.message}`);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSendReport = async () => {
    if (!currentUser) {
      await handleGoogleLogin();
      return;
    }

    setIsSendingEmail(true);
    setEmailStatus(null);
    try {
      // 1. Récupérer le dernier export CSV
      const csvRes = await fetch('/api/contacts/export');
      const csvText = await csvRes.text();

      const targetEmail = 'maildevale2@gmail.com';
      const subject = `Rapport Hebdomadaire Prospection DAF Gironde (${stats?.total_contacts || 0} contacts)`;
      const htmlBody = `
        <div style="font-family: Arial, sans-serif; color: #1e293b; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; rounded: 8px;">
          <h2 style="color: #0f172a; margin-top: 0;">📊 Rapport d'Exécution — Prospection DAF Gironde</h2>
          <p>Bonjour,</p>
          <p>Voici le récapitulatif de votre session de prospection ciblée en Gironde (33) :</p>
          <ul>
            <li><strong>Total contacts qualifiés en base :</strong> ${stats?.total_contacts || 0}</li>
            <li><strong>Prospects prêts à contacter :</strong> ${stats?.status_counts?.['à contacter'] || 0}</li>
            <li><strong>Priorité 1 (Prise de poste récente < 6 mois) :</strong> ${stats?.priority_counts?.['Changement de poste récent (< 6 mois)'] || 0}</li>
            <li><strong>Plafond crédits Lusha :</strong> 20 max par run</li>
          </ul>
          <p>Le fichier CSV complet encodé pour Microsoft Excel (UTF-8 avec BOM) est joint à ce message.</p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
          <p style="font-size: 12px; color: #64748b;">
            Message sécurisé envoyé depuis l'Agent DAF Gironde via l'API officielle Google Workspace Gmail (OAuth 2.0).
          </p>
        </div>
      `;

      await sendGmailReport({
        to: targetEmail,
        subject,
        htmlContent: htmlBody,
        csvData: csvText,
        csvFilename: `prospects_gironde_${new Date().toISOString().slice(0, 10)}.csv`
      });

      setEmailStatus(`Rapport envoyé avec succès à ${targetEmail} !`);
      setTimeout(() => setEmailStatus(null), 6000);
    } catch (err: any) {
      alert(`Erreur d'envoi Gmail : ${err.message}`);
    } finally {
      setIsSendingEmail(false);
    }
  };

  const tabs = [
    { id: 'cockpit', label: 'Tableau de Bord & Runs' },
    { id: 'crm', label: 'Fichier de Suivi Contacts' },
    { id: 'mode_b', label: 'Mode B (Comptes CSV)' },
    { id: 'terminal', label: 'Terminal & Tests' },
    { id: 'deliverables', label: 'Livrables & Code' },
    { id: 'rgpd_config', label: 'RGPD & Paramètres' },
  ];

  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30 shadow-xs">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-md bg-slate-900 text-white flex items-center justify-center font-bold text-sm tracking-tight">
                G3
              </div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                Agent Prospection DAF / Finance Gironde
              </h1>
            </div>
            <div className="flex items-center gap-2 mt-1 text-xs text-slate-500 font-medium">
              <span>Moteur LLM Gemma 3 (27B/12B)</span>
              <span aria-hidden="true">·</span>
              <span>API Lusha REST</span>
              <span aria-hidden="true">·</span>
              <span>Cible Gironde (33) : 100 à 1000 sal.</span>
              <span aria-hidden="true">·</span>
              <span>SQLite + Export CSV UTF-8 BOM</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {/* Google Gmail integration buttons */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSendReport}
                  disabled={isSendingEmail}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 rounded-md hover:bg-emerald-100 active:bg-emerald-200 transition-colors disabled:opacity-50"
                  title="Envoyer le rapport avec fichier CSV à maildevale2@gmail.com"
                >
                  <Send className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isSendingEmail ? 'Envoi en cours...' : 'Envoyer à maildevale2@gmail.com'}</span>
                </button>

                <button
                  onClick={logout}
                  className="p-2 text-slate-400 hover:text-slate-700 rounded-md border border-slate-200 hover:bg-slate-50 transition-colors"
                  title={`Connecté en tant que ${currentUser.email}. Cliquez pour vous déconnecter.`}
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleGoogleLogin}
                disabled={isLoggingIn}
                className="gsi-material-button inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 shadow-xs"
                title="Connectez votre compte Google en toute sécurité sans mot de passe"
              >
                <svg className="w-4 h-4" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                </svg>
                <span>{isLoggingIn ? 'Connexion...' : 'Connexion Google (Gmail)'}</span>
              </button>
            )}

            <button
              onClick={onExportCsv}
              disabled={isExporting}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 active:bg-slate-100 transition-colors disabled:opacity-50"
              title="Télécharger le fichier de suivi CSV formaté pour Excel"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>{isExporting ? 'Export en cours...' : 'Exporter CSV'}</span>
            </button>

            <button
              onClick={() => {
                const link = document.createElement('a');
                link.href = '/api/deliverables/download-zip';
                link.download = 'prospection_b2b_finance_complet.zip';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 active:bg-slate-100 transition-colors"
              title="Télécharger l'intégralité du code et des livrables du projet au format ZIP"
            >
              <Download className="w-3.5 h-3.5 text-indigo-600" />
              <span>Télécharger le code (.ZIP)</span>
            </button>

            <button
              onClick={onStartModeA}
              disabled={isStartingRun}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 active:bg-black transition-colors shadow-xs disabled:opacity-60"
            >
              {isStartingRun ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Analyse Lusha...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-white text-white" />
                  <span>Lancer Run Mode A</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Status notification banner for email */}
        {emailStatus && (
          <div className="mt-2.5 p-2 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{emailStatus}</span>
          </div>
        )}

        {/* Operational Context Sub-bar */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-y-1.5">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              <strong className="text-slate-800">{stats?.total_contacts ?? 0}</strong> contacts en base locale
            </span>
            <span aria-hidden="true" className="text-slate-300">|</span>
            <span className="flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              <span>Plafond strict : <strong className="text-slate-800">{config?.data?.limits?.max_reveals_per_run || 20} révélations / session</strong></span>
            </span>
            <span aria-hidden="true" className="text-slate-300">|</span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Planification : <strong className="text-slate-800">{['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'][(config?.data?.scheduler?.day_of_week || 1) - 1] || 'Lundi'} {String(config?.data?.scheduler?.hour ?? 9).padStart(2, '0')}:{String(config?.data?.scheduler?.minute ?? 0).padStart(2, '0')}</strong></span>
            </span>
            <span aria-hidden="true" className="text-slate-300">|</span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
              <span>Cible : <strong className="text-slate-800">Dép. {((config?.data?.icp?.departments || ['33']) as string[]).join(', ')} ({config?.data?.icp?.company_size_min || 50}-{config?.data?.icp?.company_size_max || 500} sal.)</strong></span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Gmail OAuth Actif</span>
          </div>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-1 border-t border-slate-100" aria-label="Tabs">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2.5 px-3.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border-slate-900 text-slate-900 bg-slate-50/50'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
