import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Trash2, 
  UserMinus, 
  FileText, 
  Settings, 
  CheckCircle, 
  AlertCircle, 
  Calendar,
  Cpu,
  Key,
  MapPin,
  Building,
  Briefcase,
  Layers,
  Save,
  Plus
} from 'lucide-react';
import { AppStats } from '../types';

interface RgpdConfigTabProps {
  stats: AppStats | null;
  onRefreshStats: () => void;
}

const ALL_SECTORS_PRESETS = [
  'Commerce de gros & Négoce B2B',
  'Industrie & Manufacturing',
  'Agroalimentaire (Food & Beverages)',
  'BTP, Bâtiment & Construction',
  'Transport, Fret & Logistique',
  'Services aux Entreprises (B2B)',
  'Technologies, IT & Digital',
  'Santé, Pharma & Chimie'
];

const DEPT_NAMES: Record<string, string> = {
  '33': 'Gironde',
  '40': 'Landes',
  '47': 'Lot-et-Garonne',
  '64': 'Pyrénées-Atlantiques',
  '24': 'Dordogne',
  '17': 'Charente-Maritime',
  '16': 'Charente',
  '75': 'Paris',
  '69': 'Rhône (Lyon)',
  '31': 'Haute-Garonne (Toulouse)',
  '44': 'Loire-Atlantique (Nantes)',
  '59': 'Nord (Lille)',
  '13': 'Bouches-du-Rhône (Marseille)'
};

export const RgpdConfigTab: React.FC<RgpdConfigTabProps> = ({ stats, onRefreshStats }) => {
  const [optoutEmail, setOptoutEmail] = useState('');
  const [optoutMotif, setOptoutMotif] = useState('Demande par email');
  const [optoutStatus, setOptoutStatus] = useState<string | null>(null);

  const [purgeYears, setPurgeYears] = useState(3);
  const [purgeStatus, setPurgeStatus] = useState<string | null>(null);
  const [isPurging, setIsPurging] = useState(false);

  const [configData, setConfigData] = useState<any>(null);
  const [lushaInputKey, setLushaInputKey] = useState('');
  const [isSavingKey, setIsSavingKey] = useState(false);
  const [keySaveMsg, setKeySaveMsg] = useState<string | null>(null);

  // Settings State
  const [maxReveals, setMaxReveals] = useState<number>(20);
  const [schedDay, setSchedDay] = useState<number>(1);
  const [schedTime, setSchedTime] = useState<string>('09:00');
  const [departmentsInput, setDepartmentsInput] = useState<string>('33');
  const [sizeMin, setSizeMin] = useState<number>(50);
  const [sizeMax, setSizeMax] = useState<number>(500);
  const [selectedSectors, setSelectedSectors] = useState<string[]>([
    'Commerce de gros & Négoce B2B',
    'Industrie & Manufacturing',
    'Agroalimentaire (Food & Beverages)'
  ]);
  const [newCustomSector, setNewCustomSector] = useState('');
  const [isSavingParams, setIsSavingParams] = useState(false);
  const [paramsSaveMsg, setParamsSaveMsg] = useState<string | null>(null);

  const fetchConfig = () => {
    fetch('/api/config')
      .then(res => res.json())
      .then(data => {
        setConfigData(data);
        if (data.data) {
          const d = data.data;
          if (d.limits?.max_reveals_per_run) setMaxReveals(d.limits.max_reveals_per_run);
          if (d.scheduler) {
            setSchedDay(d.scheduler.day_of_week ?? 1);
            const hh = String(d.scheduler.hour ?? 9).padStart(2, '0');
            const mm = String(d.scheduler.minute ?? 0).padStart(2, '0');
            setSchedTime(`${hh}:${mm}`);
          }
          if (d.icp) {
            if (d.icp.departments) setDepartmentsInput(d.icp.departments.join(', '));
            if (d.icp.company_size_min) setSizeMin(d.icp.company_size_min);
            if (d.icp.company_size_max) setSizeMax(d.icp.company_size_max);
            if (d.icp.sectors) setSelectedSectors(d.icp.sectors);
          }
        }
      })
      .catch(console.error);
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  const handleToggleSector = (sector: string) => {
    if (selectedSectors.includes(sector)) {
      if (selectedSectors.length > 1) {
        setSelectedSectors(selectedSectors.filter(s => s !== sector));
      } else {
        alert('Veuillez conserver au moins un secteur d\'activité.');
      }
    } else {
      setSelectedSectors([...selectedSectors, sector]);
    }
  };

  const handleAddCustomSector = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCustomSector.trim();
    if (trimmed && !selectedSectors.includes(trimmed)) {
      setSelectedSectors([...selectedSectors, trimmed]);
      setNewCustomSector('');
    }
  };

  const handleSaveParams = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingParams(true);
    setParamsSaveMsg(null);

    const [hh, mm] = schedTime.split(':').map(n => parseInt(n, 10) || 0);
    const depsArray = departmentsInput
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    try {
      const res = await fetch('/api/config/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          limits: {
            max_reveals_per_run: Number(maxReveals)
          },
          scheduler: {
            day_of_week: Number(schedDay),
            hour: hh,
            minute: mm
          },
          icp: {
            departments: depsArray.length > 0 ? depsArray : ['33'],
            company_size_min: Number(sizeMin),
            company_size_max: Number(sizeMax),
            sectors: selectedSectors
          }
        })
      });
      const data = await res.json();
      if (data.success) {
        setParamsSaveMsg('Paramètres enregistrés avec succès dans config.yaml et appliqués immédiatement !');
        fetchConfig();
        onRefreshStats();
        setTimeout(() => setParamsSaveMsg(null), 5000);
      } else {
        alert('Erreur lors de l\'enregistrement des paramètres.');
      }
    } catch (err: any) {
      alert(`Erreur : ${err.message}`);
    } finally {
      setIsSavingParams(false);
    }
  };

  const handleSaveLushaKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lushaInputKey.trim()) return;

    setIsSavingKey(true);
    setKeySaveMsg(null);
    try {
      const res = await fetch('/api/config/lusha-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: lushaInputKey.trim() })
      });
      const data = await res.json();
      if (data.success) {
        setKeySaveMsg(data.message || 'Clé API Lusha validée et activée !');
        setLushaInputKey('');
        fetchConfig();
      } else {
        alert(`Erreur : ${data.error}`);
      }
    } catch (err: any) {
      alert(`Erreur de connexion : ${err.message}`);
    } finally {
      setIsSavingKey(false);
    }
  };

  const handleRegisterOptout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!optoutEmail) return;

    try {
      const res = await fetch('/api/terminal/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: `python3 optout.py --email "${optoutEmail}" --motif "${optoutMotif}"` })
      });
      const data = await res.json();
      setOptoutStatus(`Opposition enregistrée pour ${optoutEmail}. Le contact a été radié de la base active.`);
      setOptoutEmail('');
      onRefreshStats();
    } catch (err: any) {
      setOptoutStatus(`Erreur : ${err.message}`);
    }
  };

  const handlePurge = async () => {
    setIsPurging(true);
    setPurgeStatus(null);
    try {
      const res = await fetch('/api/rgpd/purge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ years: purgeYears })
      });
      const data = await res.json();
      setPurgeStatus(`Purge exécutée : ${data.deleted} contact(s) inactif(s) depuis plus de ${purgeYears} ans ont été effacés.`);
      onRefreshStats();
    } catch (err: any) {
      setPurgeStatus(`Erreur : ${err.message}`);
    } finally {
      setIsPurging(false);
    }
  };

  const recognizedDeps = departmentsInput
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

  return (
    <div className="space-y-6">
      {/* 1. NOUVEAU : PARAMÉTRAGE OPÉRATIONNEL & ICP */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-100 pb-4 gap-2">
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Settings className="w-5 h-5 text-indigo-600" />
              <span>Paramètres Opérationnels & Profil de Client Idéal (ICP)</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Ajustez la planification, le plafond strict de crédits, les départements cibles, l'effectif et les secteurs d'activité pour le Mode A.
            </p>
          </div>

          <button
            onClick={handleSaveParams}
            disabled={isSavingParams}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-semibold rounded-md shadow-xs transition-colors disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSavingParams ? 'Enregistrement...' : 'Enregistrer les paramètres'}</span>
          </button>
        </div>

        {paramsSaveMsg && (
          <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-md text-xs flex items-center gap-2 font-medium">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{paramsSaveMsg}</span>
          </div>
        )}

        <form onSubmit={handleSaveParams} className="mt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Plafond strict */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-slate-600" />
                <span>Plafond strict de révélation</span>
              </label>
              <p className="text-[11px] text-slate-500">
                Nombre maximum de crédits Lusha consommables par run (défaut : 20).
              </p>
              <select
                value={maxReveals}
                onChange={(e) => setMaxReveals(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-600"
              >
                <option value={5}>5 crédits max / session</option>
                <option value={10}>10 crédits max / session</option>
                <option value={15}>15 crédits max / session</option>
                <option value={20}>20 crédits max / session (Standard)</option>
                <option value={25}>25 crédits max / session</option>
                <option value={30}>30 crédits max / session</option>
                <option value={50}>50 crédits max / session</option>
              </select>
            </div>

            {/* Planification hebdomadaire */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-600" />
                <span>Planification hebdomadaire</span>
              </label>
              <p className="text-[11px] text-slate-500">
                Jour et heure d'exécution automatique du Mode A (défaut : Lundi 09:00).
              </p>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={schedDay}
                  onChange={(e) => setSchedDay(Number(e.target.value))}
                  className="px-2.5 py-2 bg-white border border-slate-300 rounded text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-600"
                >
                  <option value={1}>Lundi</option>
                  <option value={2}>Mardi</option>
                  <option value={3}>Mercredi</option>
                  <option value={4}>Jeudi</option>
                  <option value={5}>Vendredi</option>
                  <option value={6}>Samedi</option>
                  <option value={7}>Dimanche</option>
                </select>
                <input
                  type="time"
                  value={schedTime}
                  onChange={(e) => setSchedTime(e.target.value)}
                  className="px-2.5 py-2 bg-white border border-slate-300 rounded text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-600 text-center"
                />
              </div>
            </div>

            {/* Cible géographique / Départements */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-slate-600" />
                <span>Départements cibles</span>
              </label>
              <p className="text-[11px] text-slate-500">
                Codes séparés par virgule (ex: <code>33, 40, 47, 64</code>).
              </p>
              <input
                type="text"
                value={departmentsInput}
                onChange={(e) => setDepartmentsInput(e.target.value)}
                placeholder="33, 40, 47, 64"
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded text-xs font-mono font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-600"
              />
              <div className="flex flex-wrap gap-1 mt-1">
                {recognizedDeps.map(d => (
                  <span key={d} className="px-1.5 py-0.5 bg-slate-200/80 text-slate-800 rounded text-[10px] font-medium">
                    {d} {DEPT_NAMES[d] ? `(${DEPT_NAMES[d]})` : ''}
                  </span>
                ))}
              </div>
            </div>

            {/* Taille de l'entreprise */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Building className="w-4 h-4 text-slate-600" />
                <span>Effectif de l'entreprise</span>
              </label>
              <p className="text-[11px] text-slate-500">
                Tranche de salariés pour le ciblage PME / ETI.
              </p>
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <span className="text-[10px] text-slate-400">Min</span>
                  <input
                    type="number"
                    min={1}
                    max={5000}
                    value={sizeMin}
                    onChange={(e) => setSizeMin(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-semibold text-slate-900"
                  />
                </div>
                <span className="text-slate-400 mt-3">à</span>
                <div className="flex-1">
                  <span className="text-[10px] text-slate-400">Max</span>
                  <input
                    type="number"
                    min={10}
                    max={10000}
                    value={sizeMax}
                    onChange={(e) => setSizeMax(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs font-semibold text-slate-900"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Secteurs d'activité (Industries) pour le Mode A */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-indigo-600" />
                  <span>Secteurs d'activité de l'entreprise (Filtre Mode A)</span>
                </label>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Cochez les secteurs ciblés par la prospection. L'agent concentre la recherche et la rédaction sur ces typologies d'activités.
                </p>
              </div>

              <div className="text-[11px] text-slate-600 font-medium">
                {selectedSectors.length} secteur(s) sélectionné(s)
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 pt-2">
              {ALL_SECTORS_PRESETS.map((sector) => {
                const isChecked = selectedSectors.includes(sector);
                return (
                  <button
                    key={sector}
                    type="button"
                    onClick={() => handleToggleSector(sector)}
                    className={`p-2.5 rounded-md border text-left text-xs transition-colors flex items-center gap-2 ${
                      isChecked
                        ? 'bg-indigo-50/80 border-indigo-300 text-indigo-950 font-semibold'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100/50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
                    />
                    <span>{sector}</span>
                  </button>
                );
              })}
            </div>

            {/* Custom sector add */}
            <div className="pt-2 flex items-center gap-2">
              <input
                type="text"
                value={newCustomSector}
                onChange={(e) => setNewCustomSector(e.target.value)}
                placeholder="Ajouter un secteur spécifique (ex: Viticulture, Plasturgie, Aéronautique...)"
                className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-600"
              />
              <button
                type="button"
                onClick={handleAddCustomSector}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded text-xs font-semibold inline-flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Ajouter</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* 2. RGPD Compliance Dashboard */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Conformité RGPD — Prospection B2B & Droits des Personnes</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Conformité totale avec les préconisations CNIL : Intérêt légitime B2B, minimisation, droit d'opposition et purge triennale.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 font-semibold text-slate-800">
              <strong className="text-rose-600">{stats?.optouts_count ?? 0}</strong> emails en liste noire
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="text-slate-600">Rétention max : 3 ans</span>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Droit d'opposition (Opt-out) Form */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <UserMinus className="w-4 h-4 text-slate-600" />
              <span>Droit d'Opposition Immédiat (Art. 21 RGPD)</span>
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              Dès notification d'un refus ou d'une demande de désinscription par un prospect, inscrivez son email ici. Il sera effacé de la base active et bloqué définitivement pour les futurs runs.
            </p>

            <form onSubmit={handleRegisterOptout} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email professionnel à exclure :
                </label>
                <input
                  type="email"
                  required
                  value={optoutEmail}
                  onChange={(e) => setOptoutEmail(e.target.value)}
                  placeholder="daf.contact@entreprise.fr"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Motif de l'opposition :
                </label>
                <input
                  type="text"
                  value={optoutMotif}
                  onChange={(e) => setOptoutMotif(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 px-4 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-semibold rounded transition-colors"
              >
                Inscrire sur liste noire permanente & effacer
              </button>

              {optoutStatus && (
                <div className="p-2.5 bg-white border border-slate-200 rounded text-slate-800 text-[11px] font-medium">
                  {optoutStatus}
                </div>
              )}
            </form>
          </div>

          {/* Purge Triennale Automatique */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                <Trash2 className="w-4 h-4 text-slate-600" />
                <span>Purge Automatique de Conservation (3 Ans)</span>
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                La CNIL impose une suppression automatique des données de prospection inactives après 3 ans sans interaction. Cette procédure supprime définitivement les prospects sans action récente.
              </p>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Seuil de purge (années d'inactivité) :
                  </label>
                  <select
                    value={purgeYears}
                    onChange={(e) => setPurgeYears(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded text-slate-900"
                  >
                    <option value={3}>3 ans (Recommandation CNIL)</option>
                    <option value={2}>2 ans</option>
                    <option value={1}>1 an</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={handlePurge}
                disabled={isPurging}
                className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded transition-colors disabled:opacity-50"
              >
                {isPurging ? 'Purge en cours...' : `Exécuter la purge des contacts (> ${purgeYears} ans)`}
              </button>

              {purgeStatus && (
                <div className="mt-3 p-2.5 bg-white border border-slate-200 rounded text-slate-800 text-[11px] font-medium">
                  {purgeStatus}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Protection des logs (Anti-Leaking) */}
        <div className="mt-6 p-4 bg-emerald-50/50 border border-emerald-200 rounded-lg text-xs flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-emerald-950">
              Protection Active des Données Personnelles dans les Journaux
            </div>
            <div className="text-emerald-900 mt-0.5 leading-relaxed">
              Toutes les adresses emails et numéros de téléphone sont automatiquement masqués (<code>[EMAIL_MASQUÉ]</code>, <code>[TEL_MASQUÉ]</code>) avant écriture dans <code>logs/run_*.log</code> et la table SQLite <code>logs</code>.
            </div>
          </div>
        </div>
      </div>

      {/* 3. Connecteurs API & Services */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2 mb-4">
          <Cpu className="w-5 h-5 text-slate-600" />
          <span>Connecteurs API & Modèles</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md">
            <div className="font-semibold text-slate-700 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-slate-500" />
              <span>Moteur LLM Gemma 3</span>
            </div>
            <div className="mt-2 space-y-1 text-slate-600">
              <div>Modèle cible : <strong className="text-slate-800">{configData?.env?.model || 'gemma-3-27b-it'}</strong></div>
              <div>Fournisseur : <span>Google AI Studio / Ollama</span></div>
              <div>Température : <code>0.2 (Raisonnement sobre)</code></div>
            </div>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md">
            <div className="font-semibold text-slate-700 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Key className="w-4 h-4 text-slate-500" />
                <span>Connecteur Lusha REST</span>
              </span>
              {configData?.env?.has_lusha_key ? (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                  <CheckCircle className="w-3 h-3 text-emerald-600" />
                  Connecté
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800">
                  Mode Simulation
                </span>
              )}
            </div>

            <div className="mt-2 space-y-1 text-slate-600">
              <div>Statut : {configData?.env?.has_lusha_key ? (
                <strong className="text-emerald-700 font-medium">Mode Réel Activé ({configData?.env?.masked_lusha_key || '***'})</strong>
              ) : (
                <strong className="text-amber-700 font-medium">Clé non configurée (Simulation)</strong>
              )}</div>
              <div>Plafond par run : <strong className="text-slate-800">{maxReveals} crédits max</strong></div>
              <div>Backoff exponentiel : <code>tenacity (max 3 retries)</code></div>
            </div>

            {/* Direct API Key Form */}
            <form onSubmit={handleSaveLushaKey} className="mt-3 pt-2.5 border-t border-slate-200/80">
              <label className="block text-[11px] font-medium text-slate-700 mb-1">
                {configData?.env?.has_lusha_key ? 'Remplacer la clé Lusha :' : 'Renseigner votre clé Lusha :'}
              </label>
              <div className="flex gap-1.5">
                <input
                  type="password"
                  value={lushaInputKey}
                  onChange={(e) => setLushaInputKey(e.target.value)}
                  placeholder="Coller votre clé API Lusha..."
                  className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
                <button
                  type="submit"
                  disabled={isSavingKey || !lushaInputKey.trim()}
                  className="px-2.5 py-1 text-xs font-semibold text-white bg-slate-900 rounded hover:bg-slate-800 active:bg-black transition-colors shrink-0 disabled:opacity-40"
                >
                  {isSavingKey ? '...' : 'Enregistrer'}
                </button>
              </div>
              {keySaveMsg && (
                <div className="mt-1.5 text-[10px] text-emerald-700 font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3 text-emerald-600 shrink-0" />
                  <span>{keySaveMsg}</span>
                </div>
              )}
            </form>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md">
            <div className="font-semibold text-slate-700 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Google Gmail (OAuth 2.0)</span>
            </div>
            <div className="mt-2 space-y-1 text-slate-600">
              <div>Destinataire : <strong className="text-slate-800 font-mono">maildevale2@gmail.com</strong></div>
              <div>Sécurité : <span className="text-emerald-700 font-medium">Zéro mot de passe stocké</span></div>
              <div>Protocole : <span>Google Workspace API (Send)</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

