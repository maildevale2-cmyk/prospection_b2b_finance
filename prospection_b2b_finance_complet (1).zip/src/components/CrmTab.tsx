import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Download, 
  Mail, 
  Phone, 
  ExternalLink, 
  MessageSquare, 
  Copy, 
  Check, 
  Filter, 
  UserX, 
  Trash2, 
  Database,
  Award,
  ChevronDown
} from 'lucide-react';
import { Contact } from '../types';
import { calculateContactScore, ScoringConfig } from '../services/scoring';

interface CrmTabProps {
  contacts: Contact[];
  onOpenMessage: (contact: Contact) => void;
  onUpdateStatus: (id: number, status: Contact['statut']) => void;
  onOptOut: (contact: Contact) => void;
  onDeleteContact: (id: number) => void;
  onClearTestContacts: () => void;
  onClearAllContacts: () => void;
  onExportCsv: () => void;
  isExporting: boolean;
  config?: any;
}

export const CrmTab: React.FC<CrmTabProps> = ({
  contacts,
  onOpenMessage,
  onUpdateStatus,
  onOptOut,
  onDeleteContact,
  onClearTestContacts,
  onClearAllContacts,
  onExportCsv,
  isExporting,
  config
}) => {
  const [search, setSearch] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const scoringConfig: ScoringConfig = useMemo(() => {
    const icp = config?.data?.icp || {};
    return {
      departments: icp.departments || ['33'],
      company_size_min: icp.company_size_min || 50,
      company_size_max: icp.company_size_max || 500,
      sectors: icp.sectors || ['Commerce de gros', 'Industrie', 'Agroalimentaire']
    };
  }, [config]);

  const statuses = [
    { id: 'all', label: 'Tous' },
    { id: 'à contacter', label: 'À contacter' },
    { id: 'contacté', label: 'Contacté' },
    { id: 'relancé', label: 'Relancé' },
    { id: 'répondu', label: 'Répondu' },
    { id: 'refus', label: 'Refus' },
  ];

  // Enrich and sort contacts deterministically by Priority (1, 2, 3) then Score (100 -> 0)
  const scoredContacts = useMemo(() => {
    return contacts.map(c => {
      const res = calculateContactScore({
        poste: c.poste,
        entreprise: c.entreprise,
        ville: c.ville,
        statut_compte: c.statut_compte,
        signal_priorite: c.signal_priorite
      }, scoringConfig);

      const finalScore = c.score !== undefined && c.score !== 0 ? c.score : res.score;
      const finalPriority = finalScore >= 70 ? 1 : finalScore >= 40 ? 2 : 3;

      let badgeClass = 'bg-slate-100 text-slate-700 border-slate-300';
      let dotClass = 'bg-slate-400';
      if (finalPriority === 1) {
        badgeClass = 'bg-emerald-50 text-emerald-800 border-emerald-300';
        dotClass = 'bg-emerald-500';
      } else if (finalPriority === 2) {
        badgeClass = 'bg-amber-50 text-amber-800 border-amber-300';
        dotClass = 'bg-amber-500';
      }

      return {
        ...c,
        computedScore: finalScore,
        computedPriority: finalPriority,
        computedJustification: c.justification || res.justification,
        badgeClass,
        dotClass
      };
    }).sort((a, b) => {
      // Tri par priorité croissante (P1, P2, P3) puis par score décroissant (100 -> 0)
      if (a.computedPriority !== b.computedPriority) {
        return a.computedPriority - b.computedPriority;
      }
      return b.computedScore - a.computedScore;
    });
  }, [contacts, scoringConfig]);

  const filteredContacts = scoredContacts.filter((c) => {
    const s = search.toLowerCase();
    const matchesSearch = 
      !s ||
      c.nom.toLowerCase().includes(s) ||
      c.prenom.toLowerCase().includes(s) ||
      c.entreprise.toLowerCase().includes(s) ||
      c.poste.toLowerCase().includes(s) ||
      c.ville.toLowerCase().includes(s) ||
      c.email.toLowerCase().includes(s);

    const matchesStatus = selectedStatus === 'all' || c.statut === selectedStatus;
    
    let matchesPriority = true;
    if (selectedPriority === '1') {
      matchesPriority = c.computedPriority === 1;
    } else if (selectedPriority === '2') {
      matchesPriority = c.computedPriority === 2;
    } else if (selectedPriority === '3') {
      matchesPriority = c.computedPriority === 3;
    }

    return matchesSearch && matchesStatus && matchesPriority;
  });

  const p1Count = scoredContacts.filter(c => c.computedPriority === 1).length;
  const p2Count = scoredContacts.filter(c => c.computedPriority === 2).length;
  const p3Count = scoredContacts.filter(c => c.computedPriority === 3).length;

  const handleCopyMessage = (contact: Contact, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(contact.message_propose || '');
    setCopiedId(contact.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un DAF, entreprise, ville, email..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white text-slate-900"
          />
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
          {/* Status segmented buttons */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-md border border-slate-200">
            {statuses.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedStatus(item.id)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  selectedStatus === item.id
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Priority filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 font-semibold"
          >
            <option value="all">Toutes priorités ({scoredContacts.length})</option>
            <option value="1">🟢 Priorité 1 (Score ≥ 70) : {p1Count}</option>
            <option value="2">🟠 Priorité 2 (40-69) : {p2Count}</option>
            <option value="3">⚪ Priorité 3 (&lt; 40) : {p3Count}</option>
          </select>

          <button
            onClick={onExportCsv}
            disabled={isExporting}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors shadow-2xs"
            title="Télécharger le fichier de suivi complet au format CSV Excel avec Scores et Justifications"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {contacts.length > 0 && (
            <button
              onClick={onClearAllContacts}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md transition-colors"
              title="Vider tous les contacts de la base locale SQLite"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Vider</span>
            </button>
          )}
        </div>
      </div>

      {/* Database storage explanation banner */}
      <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 gap-3">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>
            <strong>Classement déterministe actif :</strong> tableau trié automatiquement par <strong>Priorité décroissante</strong> puis par <strong>Score /100</strong>.
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onClearTestContacts}
            className="text-[11px] text-slate-500 hover:text-slate-800 underline"
            title="Effacer uniquement les contacts de test pour ne garder que vos vrais prospects"
          >
            Nettoyer les faux contacts de test
          </button>
        </div>
      </div>

      {/* Contacts Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4 w-32">Score & Priorité</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4">Entreprise & Ville</th>
                <th className="py-3 px-4">Coordonnées Révélées</th>
                <th className="py-3 px-4 max-w-xs">Justification du Score (100 pts)</th>
                <th className="py-3 px-4">Message Proposé</th>
                <th className="py-3 px-4">Statut CRM</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {filteredContacts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    Aucun contact ne correspond à votre filtre.
                  </td>
                </tr>
              ) : (
                filteredContacts.map((c) => {
                  return (
                    <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* Score & Priorité */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 ${c.badgeClass}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${c.dotClass}`} />
                            Priorité {c.computedPriority}
                          </span>

                          <div className="flex items-center gap-0.5">
                            <span className="font-mono font-bold text-xs text-slate-900">
                              {c.computedScore}
                            </span>
                            <span className="text-[10px] text-slate-400">/100</span>
                          </div>
                        </div>

                        {/* Mini progress bar */}
                        <div className="w-20 bg-slate-100 h-1.5 rounded-full overflow-hidden mt-1.5">
                          <div 
                            className={`h-full ${
                              c.computedPriority === 1 
                                ? 'bg-emerald-500' 
                                : c.computedPriority === 2 
                                ? 'bg-amber-500' 
                                : 'bg-slate-400'
                            }`}
                            style={{ width: `${Math.min(c.computedScore, 100)}%` }}
                          />
                        </div>
                      </td>

                      {/* Décideur */}
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">
                          {c.prenom} {c.nom}
                        </div>
                        <div className="text-slate-600 text-[11px] font-medium">
                          {c.poste}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                          ID: {c.lusha_contact_id}
                        </div>
                      </td>

                      {/* Entreprise & Ville */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">
                          {c.entreprise}
                        </div>
                        <div className="text-slate-500 text-[11px] flex items-center gap-1.5 flex-wrap">
                          <span>{c.ville || 'France'}</span>
                          {c.siren && (
                            <>
                              <span>·</span>
                              <a
                                href={`https://www.pappers.fr/entreprise/${c.siren}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="font-mono text-indigo-600 hover:text-indigo-800 hover:underline inline-flex items-center gap-0.5"
                                title="Consulter la fiche officielle INSEE / Pappers pour ce SIREN"
                              >
                                SIREN {c.siren}
                                <span className="text-[9px]">↗</span>
                              </a>
                            </>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Compte {c.statut_compte || 'nouveau'}
                        </div>
                      </td>

                      {/* Coordonnées */}
                      <td className="py-3 px-4">
                        {c.email ? (
                          <div className="flex items-center gap-1.5 text-slate-800 font-mono text-[11px]">
                            <Mail className="w-3 h-3 text-slate-400" />
                            <a href={`mailto:${c.email}`} className="hover:underline">
                              {c.email}
                            </a>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Email non renseigné</span>
                        )}

                        {c.telephone && (
                          <div className="flex items-center gap-1.5 text-slate-600 font-mono text-[11px] mt-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{c.telephone}</span>
                          </div>
                        )}

                        {c.linkedin && (
                          <div className="mt-1">
                            <a
                              href={c.linkedin}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-indigo-600 hover:text-indigo-800 inline-flex items-center gap-1"
                            >
                              <span>LinkedIn</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        )}
                      </td>

                      {/* Justification du score */}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="text-slate-700 text-[11px] leading-relaxed">
                          {c.computedJustification}
                        </div>
                      </td>

                      {/* Message Proposé */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onOpenMessage(c)}
                            className="px-2.5 py-1 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded border border-slate-200 inline-flex items-center gap-1.5 transition-colors"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-slate-500" />
                            <span>Voir le message</span>
                          </button>

                          <button
                            type="button"
                            onClick={(e) => handleCopyMessage(c, e)}
                            className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors"
                            title="Copier le texte dans le presse-papier"
                          >
                            {copiedId === c.id ? (
                              <Check className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1">
                          {c.message_propose ? `${c.message_propose.split(' ').length} mots rédigés` : 'En attente'}
                        </div>
                      </td>

                      {/* Statut CRM */}
                      <td className="py-3 px-4">
                        <select
                          value={c.statut}
                          onChange={(e) => onUpdateStatus(c.id, e.target.value as Contact['statut'])}
                          className="px-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900"
                        >
                          <option value="à contacter">À contacter</option>
                          <option value="contacté">Contacté</option>
                          <option value="relancé">Relancé</option>
                          <option value="répondu">Répondu</option>
                          <option value="refus">Refus</option>
                        </select>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => onOptOut(c)}
                            className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                            title="Inscrire sur liste noire RGPD (Opt-out Art. 21)"
                          >
                            <UserX className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteContact(c.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                            title="Supprimer ce contact"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer info count */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between text-xs text-slate-500">
          <div>
            Affichage de <strong>{filteredContacts.length}</strong> sur <strong>{contacts.length}</strong> contacts en base
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 font-medium text-emerald-800">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              {p1Count} Priorité 1 (Score ≥ 70)
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5 font-medium text-amber-800">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              {p2Count} Priorité 2 (40-69)
            </span>
            <span>·</span>
            <span className="flex items-center gap-1.5 text-slate-600">
              <span className="w-2 h-2 rounded-full bg-slate-400"></span>
              {p3Count} Priorité 3 (&lt; 40)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
