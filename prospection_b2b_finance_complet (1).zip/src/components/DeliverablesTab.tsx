import React, { useState, useEffect } from 'react';
import { 
  FolderTree, 
  FileCode, 
  FileText, 
  Copy, 
  Check, 
  Download, 
  CheckCircle,
  FileCheck2,
  Terminal,
  Shield,
  Archive,
  Info
} from 'lucide-react';
import { DeliverableFile } from '../types';

export const DeliverablesTab: React.FC = () => {
  const [files, setFiles] = useState<DeliverableFile[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>('src/orchestrator.py');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  useEffect(() => {
    fetch('/api/deliverables')
      .then(res => res.json())
      .then(data => {
        setFiles(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const selectedFile = files.find(f => f.path === selectedPath) || files[0];

  const handleCopy = () => {
    if (selectedFile?.content) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadFile = () => {
    if (!selectedFile) return;
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.path.split('/').pop() || 'file.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAllZip = () => {
    setIsDownloadingZip(true);
    const link = document.createElement('a');
    link.href = '/api/deliverables/download-zip';
    link.download = 'prospection_b2b_finance_complet.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setIsDownloadingZip(false), 2500);
  };

  const categories = Array.from(new Set(files.map(f => f.category)));

  return (
    <div className="space-y-4">
      {/* Overview Banner */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileCheck2 className="w-4 h-4 text-emerald-600" />
            <span>Dépôt des Livrables Contractuels & Code Source Complet</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            L'ensemble des modules Python, composants React/TypeScript, base SQLite, tests et documentation sont prêts et validés.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1.5 rounded font-medium flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" />
            100% Spécifications Couvertes
          </span>

          {/* SINGLE-CLICK GLOBAL ZIP DOWNLOAD */}
          <button
            onClick={handleDownloadAllZip}
            disabled={isDownloadingZip}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 active:bg-black rounded-md transition-colors shadow-xs"
            title="Télécharger l'intégralité du code et des livrables sans devoir cliquer module par module"
          >
            {isDownloadingZip ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Génération du ZIP en cours...</span>
              </>
            ) : (
              <>
                <Archive className="w-4 h-4 text-emerald-400" />
                <span>Télécharger tout le projet (.ZIP)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Explanatory Info Card */}
      <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-lg flex items-start gap-2.5 text-xs text-indigo-900">
        <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <span className="font-bold">Astuce Téléchargement :</span>
          <p className="text-indigo-800">
            <strong>Vous n'avez pas besoin de cliquer sur chaque fichier un par un !</strong> Cliquez simplement sur le bouton noir ci-dessus <strong>« Télécharger tout le projet (.ZIP) »</strong> pour récupérer instantanément l'intégralité du dépôt (arborescence complète, code source Python, TypeScript, SQLite, documentation et tests unitaires) dans une seule archive compressée.
          </p>
        </div>
      </div>

      {/* Main Dual Panel Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Sidebar File Tree */}
        <div className="lg:col-span-4 bg-white rounded-lg border border-slate-200 shadow-xs p-4 overflow-y-auto max-h-[700px]">
          <div className="flex items-center justify-between mb-3">
            <div className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <FolderTree className="w-3.5 h-3.5 text-slate-400" />
              <span>Arborescence des Fichiers</span>
            </div>
            <button
              onClick={handleDownloadAllZip}
              className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold underline inline-flex items-center gap-0.5"
            >
              <span>Tout en .ZIP</span>
              <Download className="w-2.5 h-2.5" />
            </button>
          </div>

          <div className="space-y-4">
            {categories.map((cat) => (
              <div key={cat} className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider px-1">
                  {cat}
                </div>
                <div className="space-y-0.5">
                  {files.filter(f => f.category === cat).map((file) => {
                    const isSelected = file.path === selectedPath;
                    return (
                      <button
                        key={file.path}
                        onClick={() => setSelectedPath(file.path)}
                        className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between transition-colors ${
                          isSelected
                            ? 'bg-slate-900 text-white font-semibold shadow-2xs'
                            : 'text-slate-700 hover:bg-slate-100 font-medium'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                          <span className="truncate">{file.path}</span>
                        </div>
                        <span className={`text-[10px] ml-2 shrink-0 ${isSelected ? 'text-slate-300' : 'text-slate-400 font-mono'}`}>
                          {(file.size / 1024).toFixed(1)}k
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Code & Content Viewer */}
        <div className="lg:col-span-8 bg-white rounded-lg border border-slate-200 shadow-xs flex flex-col max-h-[700px] overflow-hidden">
          {selectedFile ? (
            <>
              {/* Header */}
              <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-mono text-xs font-bold text-slate-900 truncate">
                    {selectedFile.path}
                  </div>
                  <div className="text-[11px] text-slate-500 truncate">
                    {selectedFile.desc} · {(selectedFile.size / 1024).toFixed(1)} KB
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={handleCopy}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded hover:bg-slate-50 transition-colors"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700">Copié</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copier</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleDownloadFile}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Télécharger ce fichier</span>
                  </button>
                </div>
              </div>

              {/* Code display */}
              <div className="p-4 bg-slate-950 text-slate-200 overflow-auto flex-1 font-mono text-xs leading-relaxed select-text">
                <pre>{selectedFile.content}</pre>
              </div>
            </>
          ) : (
            <div className="p-12 text-center text-slate-400 text-xs">
              Sélectionnez un fichier pour prévisualiser son contenu.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
