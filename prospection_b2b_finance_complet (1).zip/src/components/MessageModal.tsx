import React, { useState } from 'react';
import { Mail, Copy, Check, X, Building, User, Phone, MapPin, Sparkles } from 'lucide-react';
import { Contact } from '../types';

interface MessageModalProps {
  contact: Contact | null;
  onClose: () => void;
  onUpdateStatus?: (id: number, status: Contact['statut']) => void;
}

export const MessageModal: React.FC<MessageModalProps> = ({ contact, onClose, onUpdateStatus }) => {
  const [copied, setCopied] = useState(false);

  if (!contact) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(contact.message_propose || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const wordCount = contact.message_propose ? contact.message_propose.trim().split(/\s+/).length : 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-slate-800 text-slate-200 rounded-md">
              <Mail className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight">
                Message d'approche généré par Gemma 3
              </h3>
              <p className="text-xs text-slate-400">
                Personnalisé selon la fonction DAF, le secteur et le signal de priorisation.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-md">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contact details kicker */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-y-2 text-xs text-slate-600">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-900 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-slate-400" /> {contact.prenom} {contact.nom}
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="text-slate-700">{contact.poste}</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="font-medium text-slate-900 flex items-center gap-1">
              <Building className="w-3.5 h-3.5 text-slate-400" /> {contact.entreprise}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-500">{contact.ville || 'Gironde'}</span>
            {contact.email && (
              <>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="font-mono text-[11px] text-slate-800">{contact.email}</span>
              </>
            )}
          </div>
        </div>

        {/* Signal badge */}
        <div className="px-6 py-2 bg-indigo-50/50 border-b border-indigo-100 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-indigo-950 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Signal pris en compte : <strong>{contact.signal_priorite || 'Approche générale'}</strong></span>
          </div>
          <span className="text-indigo-800 text-[11px]">
            {wordCount} mots (Recommandé : 80 à 120)
          </span>
        </div>

        {/* Message body */}
        <div className="p-6">
          <label className="block text-xs font-semibold text-slate-700 mb-2 uppercase tracking-wider">
            Texte de l'approche B2B :
          </label>
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md font-sans text-xs text-slate-800 leading-relaxed whitespace-pre-line select-all">
            {contact.message_propose || "Aucun message généré pour ce contact."}
          </div>

          <div className="mt-4 p-3 bg-amber-50/60 border border-amber-200 rounded-md text-[11px] text-amber-900 leading-normal">
            <strong>Règle de prospection responsable :</strong> Ce message doit être envoyé manuellement (email ou invitation directe). Aucune action automatisée sur LinkedIn n'est autorisée afin de préserver votre compte et de respecter les CGU.
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Changer statut :</span>
            {(['à contacter', 'contacté', 'relancé', 'répondu', 'refus'] as const).map(s => (
              <button
                key={s}
                onClick={() => onUpdateStatus?.(contact.id, s)}
                className={`px-2 py-0.5 text-[11px] font-medium rounded border transition-colors ${
                  contact.statut === s
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-100 transition-colors"
            >
              Fermer
            </button>
            <button
              onClick={handleCopy}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 active:bg-black transition-colors flex items-center gap-1.5 shadow-xs"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copié dans le presse-papier !</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copier le message</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
