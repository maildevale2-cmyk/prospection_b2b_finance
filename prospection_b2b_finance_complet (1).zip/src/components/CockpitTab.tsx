import React, { useState } from 'react';
import { 
  Play, 
  Search, 
  Sparkles, 
  ShieldCheck, 
  CreditCard, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  MapPin,
  Building,
  Users
} from 'lucide-react';
import { AppStats, RunHistoryItem, Candidate } from '../types';

interface CockpitTabProps {
  stats: AppStats | null;
  runs: RunHistoryItem[];
  onStartModeA: () => void;
  onSelectCandidateDetails: (candidate: any) => void;
  isStartingRun: boolean;
  config?: any;
}

export const CockpitTab: React.FC<CockpitTabProps> = ({
  stats,
  runs,
  onStartModeA,
  isStartingRun,
  config
}) => {
  const p1Count = Object.entries(stats?.priority_counts || {}).reduce((acc, [k, v]) => {
    return k.toLowerCase().includes('récent') || k.includes('1') ? acc + v : acc;
  }, 0);

  const aContacterCount = stats?.status_counts?.['à contacter'] || 0;

  return (
    <div className="space-y-6">
      {/* Top Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Contacts Finance en Base
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <div className="text-2xl font-bold text-slate-900 tracking-tight">
              {stats?.total_contacts ?? 0}
            </div>
            <div className="text-xs text-slate-600 font-medium">
              SQLite Local
            </div>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Dédoublonnage déterministe automatique
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            À Contacter (Prêts)
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <div className="text-2xl font-bold text-indigo-600 tracking-tight">
              {aContacterCount}
            </div>
            <div className="text-xs text-indigo-700 font-medium">
              Messages prêts
            </div>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Coordonnées révélées & validées
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Priorité 1 (Signal Chaud)
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <div className="text-2xl font-bold text-rose-600 tracking-tight">
              {p1Count}
            </div>
            <div className="text-xs text-rose-700 font-medium">
              Prise de poste &lt; 6 mois
            </div>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Moment clé pour renouveler prestataires
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Plafond Crédits Lusha
          </div>
          <div className="mt-1 flex items-baseline justify-between">
            <div className="text-2xl font-bold text-slate-900 tracking-tight">
              20 <span className="text-sm font-normal text-slate-500">/ run</span>
            </div>
            <div className="text-xs text-emerald-700 font-medium">
              Verrouillé strict
            </div>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Validation humaine HITL obligatoire
          </div>
        </div>
      </div>

      {/* Hero Execution & ICP Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Mode A Launcher & Stepper */}
        <div className="lg:col-span-2 bg-white rounded-lg border border-slate-200 shadow-xs p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <span>Mode A — Recherche Autonome Hebdomadaire</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Balayage complet de la Gironde (33) selon l'ICP DAF/CFO, tri par Gemma 3, validation HITL et génération des messages.
                </p>
              </div>

              <span className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Planifié : Lundi 09:00</span>
              </span>
            </div>

            {/* Stepper overview */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">1</span>
                  <span>Filtres ICP</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Recherche Lusha 100-1000 sal. Gironde (Commerce & Industrie).
                </p>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">2</span>
                  <span>Priorisation G3</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  P1: poste &lt; 6 mois · P2: recrutement Finance · P3: autres.
                </p>
              </div>

              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-md">
                <div className="text-xs font-semibold text-amber-950 flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-amber-600 text-white text-[10px] flex items-center justify-center font-bold">3</span>
                  <span>Validation HITL</span>
                </div>
                <p className="text-[11px] text-amber-900 mt-1">
                  Validation manuelle stricte avant consommation (max 20).
                </p>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md">
                <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded-full bg-slate-900 text-white text-[10px] flex items-center justify-center font-bold">4</span>
                  <span>Approche & CSV</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Génération message 80-120 mots et export Excel UTF-8 BOM.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-slate-600">
              Durée estimée : <strong>&lt; 30 secondes</strong> (hors lecture humaine). Dédoublonnage 100% garanti.
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onStartModeA}
                disabled={isStartingRun}
                className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold text-white bg-slate-900 rounded-md hover:bg-slate-800 active:bg-black transition-colors flex items-center justify-center gap-2 shadow-xs disabled:opacity-50"
              >
                {isStartingRun ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Analyse en cours...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Démarrer la prospection Mode A</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: ICP Reference */}
        <div className="bg-slate-900 text-white rounded-lg p-6 flex flex-col justify-between shadow-xs">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Profil de Client Idéal (ICP)
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono">
                ACTIF
              </span>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <div className="text-slate-400 text-[11px]">Fonctions cibles :</div>
                <div className="text-slate-200 font-medium mt-0.5">
                  DAF, CFO, Credit Manager, Responsable Recouvrement, Responsable Comptable
                </div>
              </div>

              <div>
                <div className="text-slate-400 text-[11px]">Taille & Secteurs :</div>
                <div className="text-slate-200 font-medium mt-0.5">
                  {config?.data?.icp?.company_size_min || 50} à {config?.data?.icp?.company_size_max || 500} salariés · {((config?.data?.icp?.sectors || ['Commerce de gros', 'Industrie', 'Agroalimentaire']) as string[]).join(', ')}
                </div>
              </div>

              <div>
                <div className="text-slate-400 text-[11px]">Périmètre géographique :</div>
                <div className="text-slate-200 font-medium mt-0.5">
                  Département(s) : {((config?.data?.icp?.departments || ['33']) as string[]).join(', ')}
                </div>
              </div>

              <div>
                <div className="text-slate-400 text-[11px]">Contraintes non négociables :</div>
                <div className="text-amber-400 font-medium mt-0.5 text-[11px] leading-relaxed">
                  · Zéro action automatisée LinkedIn (anti-ban)<br/>
                  · {config?.data?.limits?.max_reveals_per_run || 20} révélations max par session (modifiable)<br/>
                  · Aucune coordonnée inventée
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Raisonnement : Gemma 3 (27B)</span>
            <span>Localisation : France</span>
          </div>
        </div>
      </div>

      {/* Runs History Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight">
              Journal des Runs de Prospection
            </h3>
            <p className="text-xs text-slate-500">
              Traçabilité 100% des exécutions enregistrées dans la base SQLite locale.
            </p>
          </div>
          <span className="text-xs text-slate-500">
            {runs.length} runs répertoriés
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-4">Run #</th>
                <th className="py-2.5 px-4">Mode</th>
                <th className="py-2.5 px-4">Date & Heure</th>
                <th className="py-2.5 px-4 text-center">Prospects Trouvés</th>
                <th className="py-2.5 px-4 text-center">Révélés & Enrichis</th>
                <th className="py-2.5 px-4 text-center">Crédits Lusha</th>
                <th className="py-2.5 px-4">Résumé</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {runs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    Aucun run enregistré pour le moment. Cliquez sur "Démarrer la prospection Mode A" pour exécuter votre première recherche.
                  </td>
                </tr>
              ) : (
                runs.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-900">
                      #{r.id}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-800">
                      Mode {r.mode}
                    </td>
                    <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                      {r.date_debut}
                    </td>
                    <td className="py-3 px-4 text-center text-slate-700 font-medium">
                      {r.nb_prospects_trouves}
                    </td>
                    <td className="py-3 px-4 text-center text-emerald-700 font-semibold">
                      {r.nb_prospects_reveles}
                    </td>
                    <td className="py-3 px-4 text-center text-slate-800 font-mono">
                      {r.nb_credits_lusha}
                    </td>
                    <td className="py-3 px-4 text-slate-600 truncate max-w-md" title={r.resume}>
                      {r.resume}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
