import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Upload, 
  ArrowRight, 
  AlertTriangle, 
  CheckCircle, 
  Search, 
  Building2, 
  Sparkles,
  Play
} from 'lucide-react';
import { SIRENAnomaly } from '../types';

interface ModeBTabProps {
  onStartModeBRun: (accountsCsv: string, knownCsv: string) => void;
  isStartingRun: boolean;
}

export const ModeBTab: React.FC<ModeBTabProps> = ({ onStartModeBRun, isStartingRun }) => {
  const [accountsFile, setAccountsFile] = useState('data/comptes_exemples.csv');
  const [knownFile, setKnownFile] = useState('data/connus_exemples.csv');
  const [matchingResult, setMatchingResult] = useState<any | null>(null);
  const [isMatching, setIsMatching] = useState(false);

  const handleRunMatch = async () => {
    setIsMatching(true);
    try {
      const res = await fetch('/api/runs/mode-b/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accounts_csv: accountsFile, known_csv: knownFile })
      });
      const data = await res.json();
      setMatchingResult(data);
    } catch (err: any) {
      alert(`Erreur de rapprochement SIREN : ${err.message}`);
    } finally {
      setIsMatching(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
        <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
          <span>Mode B — Rapprochement de Fichier de Comptes & Décideurs Finance</span>
        </h2>
        <p className="text-xs text-slate-600 mt-1 max-w-3xl leading-relaxed">
          Traitez un fichier d'entreprises cibles (ex: salon, prospection manuelle). L'agent normalise les SIREN, identifie les comptes déjà connus vs nouveaux, audite les anomalies, puis recherche les décideurs Finance (DAF, CFO, Credit Managers) avant validation humaine.
        </p>

        {/* Input files configuration */}
        <div className="mt-4 p-3 bg-amber-50/70 border border-amber-200/80 rounded-md text-xs text-amber-900">
          <div className="font-semibold flex items-center gap-1.5 text-amber-950 mb-1">
            <span>ℹ️ Format recommandé pour votre fichier CSV :</span>
          </div>
          <p className="text-[11px] leading-relaxed text-amber-900/90">
            • <strong>Un seul onglet</strong> : Le format CSV est un fichier texte plat (il ne contient par définition qu'une seule feuille, contrairement à un classeur multi-onglets .xlsx).<br/>
            • <strong>Ordre des colonnes</strong> : N'importe quel ordre ! L'agent détecte automatiquement les colonnes quel que soit leur emplacement.<br/>
            • <strong>Noms des colonnes acceptés</strong> : <code>nom</code> (ou <em>societe</em>, <em>entreprise</em>, <em>raison sociale</em>) et <code>siren</code> (ou <em>siret</em>, <em>num_siren</em>). Si vous avez des colonnes supplémentaires (ville, secteur, effectif), elles sont conservées.
          </p>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                1. Fichier des comptes cibles (nom;siren)
              </label>
              <label className="cursor-pointer inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded transition-colors shadow-2xs">
                <Upload className="w-3.5 h-3.5" />
                <span>Importer CSV</span>
                <input
                  type="file"
                  accept=".csv,.txt"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const text = await file.text();
                    try {
                      const res = await fetch('/api/upload-csv', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ filename: file.name, content: text, type: 'accounts' })
                      });
                      const data = await res.json();
                      if (data.path) {
                        setAccountsFile(data.path);
                      }
                    } catch (err: any) {
                      alert(`Erreur d'import du fichier : ${err.message}`);
                    }
                  }}
                />
              </label>
            </div>
            <input
              type="text"
              value={accountsFile}
              onChange={(e) => setAccountsFile(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              placeholder="data/vos_comptes.csv"
            />
            <p className="text-[11px] text-slate-500 mt-1.5 flex items-center justify-between">
              <span>Format : <code>nom;siren</code> ou <code>societe,siren</code></span>
              <button 
                type="button" 
                onClick={() => setAccountsFile('data/comptes_exemples.csv')}
                className="text-indigo-600 hover:underline"
              >
                Utiliser exemple (9 entreprises 33)
              </button>
            </p>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-200 rounded-md">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider">
                2. Fichier des comptes déjà connus (exclusion)
              </label>
              <label className="cursor-pointer inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded transition-colors shadow-2xs">
                <Upload className="w-3.5 h-3.5 text-slate-500" />
                <span>Importer CSV</span>
                <input
                  type="file"
                  accept=".csv,.txt"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const text = await file.text();
                    try {
                      const res = await fetch('/api/upload-csv', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ filename: file.name, content: text, type: 'known' })
                      });
                      const data = await res.json();
                      if (data.path) {
                        setKnownFile(data.path);
                      }
                    } catch (err: any) {
                      alert(`Erreur d'import du fichier : ${err.message}`);
                    }
                  }}
                />
              </label>
            </div>
            <input
              type="text"
              value={knownFile}
              onChange={(e) => setKnownFile(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              placeholder="data/vos_connus.csv"
            />
            <p className="text-[11px] text-slate-500 mt-1.5 flex items-center justify-between">
              <span>Clients / contacts actuels à exclure</span>
              <button 
                type="button" 
                onClick={() => setKnownFile('data/connus_exemples.csv')}
                className="text-slate-600 hover:underline"
              >
                Utiliser exemple (Castel Frères...)
              </button>
            </p>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <button
            type="button"
            onClick={handleRunMatch}
            disabled={isMatching}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 active:bg-slate-100 transition-colors flex items-center gap-1.5"
          >
            {isMatching ? 'Rapprochement en cours...' : '1. Auditer & Rapprocher par SIREN'}
          </button>

          <button
            type="button"
            onClick={() => onStartModeBRun(accountsFile, knownFile)}
            disabled={isStartingRun}
            className="px-5 py-2 text-xs font-bold text-white bg-slate-900 rounded-md hover:bg-slate-800 active:bg-black transition-colors flex items-center gap-2 shadow-xs disabled:opacity-50"
          >
            {isStartingRun ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                <span>Traitement Mode B en cours...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>2. Lancer la prospection Mode B (HITL)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Matching Results Preview */}
      {matchingResult && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Nouveaux Comptes */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-emerald-50 border-b border-emerald-200 flex items-center justify-between text-xs">
              <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Nouveaux Comptes ({matchingResult.comptes_nouveaux?.length || 0})</span>
              </span>
              <span className="text-emerald-800 font-medium">À prospecter</span>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
              {matchingResult.comptes_nouveaux?.map((c: any, i: number) => (
                <div key={i} className="py-2 first:pt-0 last:pb-0">
                  <div className="font-semibold text-slate-900">{c.nom}</div>
                  <div className="text-slate-500 font-mono text-[11px]">SIREN: {c.siren}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Comptes Connus */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-slate-500" />
                <span>Comptes Connus ({matchingResult.comptes_connus?.length || 0})</span>
              </span>
              <span className="text-slate-600 font-medium">Déjà en CRM</span>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
              {matchingResult.comptes_connus?.map((c: any, i: number) => (
                <div key={i} className="py-2 first:pt-0 last:pb-0">
                  <div className="font-semibold text-slate-900">{c.nom}</div>
                  <div className="text-slate-500 font-mono text-[11px]">SIREN: {c.siren}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Anomalies Détectées */}
          <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-amber-50 border-b border-amber-200 flex items-center justify-between text-xs">
              <span className="font-bold text-amber-950 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Anomalies Auditées ({matchingResult.anomalies?.length || 0})</span>
              </span>
              <span className="text-amber-800 font-medium">Ignorées / Signalées</span>
            </div>
            <div className="p-4 max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
              {matchingResult.anomalies?.length === 0 ? (
                <div className="text-slate-500 text-center py-4">Aucune anomalie détectée</div>
              ) : (
                matchingResult.anomalies?.map((a: SIRENAnomaly, i: number) => (
                  <div key={i} className="py-2 first:pt-0 last:pb-0 text-amber-950">
                    <div className="font-semibold text-[11px] text-rose-700">{a.type}</div>
                    <div className="text-slate-700 text-[11px] mt-0.5">{a.detail}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
