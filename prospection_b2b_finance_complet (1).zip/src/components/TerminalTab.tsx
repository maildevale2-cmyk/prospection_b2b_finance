import React, { useState } from 'react';
import { Terminal as TerminalIcon, Play, RefreshCw, CheckCircle, AlertCircle, Copy, Check } from 'lucide-react';

export const TerminalTab: React.FC = () => {
  const [command, setCommand] = useState('python3 src/main.py --mode A --dry-run --auto-approve');
  const [output, setOutput] = useState<string>('');
  const [exitCode, setExitCode] = useState<number | null>(null);
  const [durationMs, setDurationMs] = useState<number | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  const presets = [
    { label: 'Mode A (Simulation Dry-Run)', cmd: 'python3 src/main.py --mode A --dry-run --auto-approve' },
    { label: 'Mode B (Comptes CSV)', cmd: 'python3 src/main.py --mode B --accounts data/comptes_exemples.csv --known data/connus_exemples.csv --dry-run --auto-approve' },
    { label: 'Suite de Tests Unitaires (9 tests)', cmd: 'python3 -m unittest discover -s tests -p "test_*.py"' },
    { label: 'Test Opt-out RGPD', cmd: 'python3 optout.py --email daf.test@castel-freres.fr' },
    { label: 'Test Purge Triennale (3 ans)', cmd: 'python3 purge.py --years 3' },
    { label: 'Générer Commande Planificateur', cmd: 'python3 install_scheduler.py' }
  ];

  const handleRun = async (cmdToRun?: string) => {
    const cmd = cmdToRun || command;
    setIsRunning(true);
    setOutput('Exécution de la commande en cours...\n');
    setExitCode(null);
    setDurationMs(null);

    try {
      const res = await fetch('/api/terminal/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd })
      });
      const data = await res.json();
      if (data.error) {
        setOutput(`Erreur : ${data.error}`);
        setExitCode(1);
      } else {
        const fullOutput = (data.stdout || '') + (data.stderr ? `\n--- STDERR ---\n${data.stderr}` : '');
        setOutput(fullOutput || '[Exécution terminée sans sortie console]');
        setExitCode(data.exitCode);
        setDurationMs(data.durationMs);
      }
    } catch (err: any) {
      setOutput(`Erreur réseau : ${err.message}`);
      setExitCode(1);
    } finally {
      setIsRunning(false);
    }
  };

  const copyOutput = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Top Presets Bar */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
        <div className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
          Raccourcis de commandes CLI du Cahier des Charges
        </div>
        <div className="flex flex-wrap gap-2">
          {presets.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setCommand(p.cmd);
                handleRun(p.cmd);
              }}
              disabled={isRunning}
              className="px-2.5 py-1.5 text-xs font-medium bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded transition-colors"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Input command box */}
        <div className="mt-4 flex items-center gap-2">
          <div className="relative flex-1">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono text-slate-400 text-xs">$</span>
            <input
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              disabled={isRunning}
              className="w-full pl-7 pr-4 py-2 font-mono text-xs bg-slate-900 text-slate-100 rounded-md border border-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-400"
            />
          </div>

          <button
            type="button"
            onClick={() => handleRun()}
            disabled={isRunning}
            className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 active:bg-black rounded-md transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            {isRunning ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Exécution...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Exécuter</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Terminal Output Screen */}
      <div className="bg-slate-950 text-slate-100 rounded-lg border border-slate-800 shadow-lg overflow-hidden flex flex-col font-mono text-xs">
        {/* Terminal Header */}
        <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-slate-400 text-[11px]">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
            </div>
            <span className="font-semibold text-slate-300 ml-2">Console Python 3 & Orchestrateur</span>
          </div>

          <div className="flex items-center gap-4">
            {durationMs !== null && (
              <span>Durée : {durationMs} ms</span>
            )}
            {exitCode !== null && (
              <span className={exitCode === 0 ? 'text-emerald-400 flex items-center gap-1' : 'text-rose-400 flex items-center gap-1'}>
                {exitCode === 0 ? <CheckCircle className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                Exit: {exitCode}
              </span>
            )}
            <button
              onClick={copyOutput}
              className="text-slate-400 hover:text-white p-1 rounded"
              title="Copier la sortie"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Terminal Content */}
        <pre className="p-4 overflow-x-auto min-h-[360px] max-h-[550px] leading-relaxed whitespace-pre-wrap select-text text-slate-200">
          {output || 'Prêt pour l\'exécution. Cliquez sur un raccourci ci-dessus ou tapez une commande python.'}
        </pre>
      </div>
    </div>
  );
};
