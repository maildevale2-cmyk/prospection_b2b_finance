#!/usr/bin/env python3
"""Script de purge automatique RGPD (rétention max 3 ans) per section 10.2."""
import argparse
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from src.tools.state import StateManager

def main():
    parser = argparse.ArgumentParser(description="Purge automatique des contacts inactifs depuis plus de 3 ans")
    parser.add_argument("--years", type=int, default=3, help="Durée de conservation maximale en années (défaut : 3)")
    parser.add_argument("--db", default="data/prospection.db", help="Chemin de la base de données")
    args = parser.parse_args()

    state = StateManager(db_path=args.db)
    deleted = state.purge_older_than(years=args.years)
    print(f"🧹 Purge terminée : {deleted} contacts sans interaction depuis plus de {args.years} ans ont été supprimés.")

if __name__ == "__main__":
    main()
