#!/usr/bin/env python3
"""Script de gestion des demandes d'opposition RGPD (Opt-out) per section 10.2."""
import argparse
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from src.tools.state import StateManager

def main():
    parser = argparse.ArgumentParser(description="Enregistre une opposition RGPD (Droit d'opposition / Opt-out)")
    parser.add_argument("--email", required=True, help="Adresse email professionnelle à inscrire sur liste noire")
    parser.add_argument("--motif", default="Opposition prospection B2B", help="Motif de l'opposition")
    parser.add_argument("--db", default="data/prospection.db", help="Chemin de la base de données")
    args = parser.parse_args()

    state = StateManager(db_path=args.db)
    success = state.add_optout(args.email, args.motif)
    if success:
        print(f"✅ Opt-out enregistré avec succès pour {args.email}.")
        print("L'adresse est désormais inscrite sur liste noire permanente et a été purgée des contacts actifs.")
    else:
        print(f"❌ Échec de l'enregistrement pour {args.email}.")
        sys.exit(1)

if __name__ == "__main__":
    main()
